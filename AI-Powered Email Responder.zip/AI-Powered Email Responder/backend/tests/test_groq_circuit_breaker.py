"""Tests for Groq circuit breaker (closed/open/half-open), 429 retry, 413 handling,
and rule-based fallback in the explicit generate-reply endpoint."""

import time
from unittest.mock import patch, MagicMock, PropertyMock

import pytest

from app.core.config import settings
from app.services.groq_service import (
    _circuit_breaker_allow,
    _circuit_breaker_record_success,
    _circuit_breaker_record_failure,
    _last_request_time,
    get_circuit_breaker_state,
    reset_rate_limiter,
    reset_circuit_breaker,
    create_chat_completion,
    get_groq_diagnostics,
    GroqPayloadTooLarge,
    GroqRateLimited,
    GroqServiceUnavailable,
    CIRCUIT_CLOSED,
    CIRCUIT_OPEN,
    CIRCUIT_HALF_OPEN,
)
from app.services.email_analysis_service import generate_reply, generate_reply_rule, validate_generated_reply


# ─── Fixtures ───────────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def reset_globals():
    reset_rate_limiter()
    reset_circuit_breaker()
    yield


# ─── Circuit Breaker: State Machine ─────────────────────────────────────────

class TestCircuitBreakerStateMachine:
    def test_starts_closed(self):
        state = get_circuit_breaker_state()
        assert state["state"] == CIRCUIT_CLOSED
        assert _circuit_breaker_allow() is True

    def test_opens_after_threshold_failures(self):
        threshold = settings.circuit_breaker_threshold
        for _ in range(threshold):
            _circuit_breaker_record_failure()
        state = get_circuit_breaker_state()
        assert state["state"] == CIRCUIT_OPEN
        assert _circuit_breaker_allow() is False

    def test_allows_requests_below_threshold(self):
        for _ in range(settings.circuit_breaker_threshold - 1):
            _circuit_breaker_record_failure()
        assert _circuit_breaker_allow() is True

    def test_success_resets_to_closed(self):
        for _ in range(settings.circuit_breaker_threshold):
            _circuit_breaker_record_failure()
        assert get_circuit_breaker_state()["state"] == CIRCUIT_OPEN
        _circuit_breaker_record_success()
        state = get_circuit_breaker_state()
        assert state["state"] == CIRCUIT_CLOSED
        assert state["failure_count"] == 0

    def test_transitions_to_half_open_after_cooldown(self):
        old_reset = settings.circuit_breaker_reset_seconds
        settings.circuit_breaker_reset_seconds = 0.01
        try:
            for _ in range(settings.circuit_breaker_threshold):
                _circuit_breaker_record_failure()
            assert get_circuit_breaker_state()["state"] == CIRCUIT_OPEN
            time.sleep(0.02)
            assert _circuit_breaker_allow() is True
            state = get_circuit_breaker_state()
            assert state["state"] == CIRCUIT_HALF_OPEN
        finally:
            settings.circuit_breaker_reset_seconds = old_reset

    def test_half_open_allows_exactly_one_request(self):
        old_reset = settings.circuit_breaker_reset_seconds
        settings.circuit_breaker_reset_seconds = 0.01
        try:
            for _ in range(settings.circuit_breaker_threshold):
                _circuit_breaker_record_failure()
            time.sleep(0.02)
            assert _circuit_breaker_allow() is True
            assert _circuit_breaker_allow() is False
        finally:
            settings.circuit_breaker_reset_seconds = old_reset

    def test_half_open_success_transitions_to_closed(self):
        old_reset = settings.circuit_breaker_reset_seconds
        settings.circuit_breaker_reset_seconds = 0.01
        try:
            for _ in range(settings.circuit_breaker_threshold):
                _circuit_breaker_record_failure()
            time.sleep(0.02)
            _circuit_breaker_allow()
            _circuit_breaker_record_success()
            assert get_circuit_breaker_state()["state"] == CIRCUIT_CLOSED
        finally:
            settings.circuit_breaker_reset_seconds = old_reset

    def test_half_open_failure_reopens(self):
        old_reset = settings.circuit_breaker_reset_seconds
        settings.circuit_breaker_reset_seconds = 0.1
        try:
            for _ in range(settings.circuit_breaker_threshold):
                _circuit_breaker_record_failure()
            time.sleep(0.12)
            _circuit_breaker_allow()
            _circuit_breaker_record_failure()
            state = get_circuit_breaker_state()
            assert state["state"] == CIRCUIT_OPEN
        finally:
            settings.circuit_breaker_reset_seconds = old_reset


# ─── Circuit Breaker: Error Classification ──────────────────────────────────

class Test413Handling:
    @patch("app.services.groq_service._client")
    def test_413_not_counted_as_circuit_failure(self, mock_client):
        from app.services.groq_service import _make_groq_call
        from groq import BadRequestError

        mock_response = MagicMock()
        type(mock_response).status_code = PropertyMock(return_value=413)
        mock_client.chat.completions.create.side_effect = BadRequestError(
            "Request too large", response=mock_response, body={}
        )

        reset_circuit_breaker()
        with patch("app.services.groq_service.is_available", return_value=True):
            with pytest.raises(GroqPayloadTooLarge):
                _make_groq_call({"model": "test", "messages": []})

        state = get_circuit_breaker_state()
        assert state["state"] == CIRCUIT_CLOSED
        assert state["failure_count"] == 0

    @patch("app.services.groq_service._client")
    def test_413_via_api_status_error(self, mock_client):
        from app.services.groq_service import _make_groq_call
        from groq import APIStatusError

        mock_response = MagicMock()
        type(mock_response).status_code = PropertyMock(return_value=413)
        mock_client.chat.completions.create.side_effect = APIStatusError(
            "Request too large", response=mock_response, body={}
        )

        reset_circuit_breaker()
        with patch("app.services.groq_service.is_available", return_value=True):
            with pytest.raises(GroqPayloadTooLarge):
                _make_groq_call({"model": "test", "messages": []})

        state = get_circuit_breaker_state()
        assert state["state"] == CIRCUIT_CLOSED


class Test429Handling:
    @patch("app.services.groq_service._client")
    def test_429_retries_with_retry_after(self, mock_client):
        from app.services.groq_service import _make_groq_call
        from groq import RateLimitError

        mock_response = MagicMock()
        type(mock_response).status_code = PropertyMock(return_value=429)
        mock_response.headers = {"retry-after": "0.01"}
        mock_response.request = MagicMock()

        mock_client.chat.completions.create.side_effect = [
            RateLimitError("rate limited", response=mock_response, body={}),
            MagicMock(
                choices=[MagicMock(message=MagicMock(content="Retry succeeded"))]
            ),
        ]

        reset_circuit_breaker()
        with patch("app.services.groq_service.is_available", return_value=True):
            result = _make_groq_call({"model": "test", "messages": []})

        assert result == "Retry succeeded"
        assert mock_client.chat.completions.create.call_count == 2

    @patch("app.services.groq_service._client")
    def test_429_retries_rejected_still_fails(self, mock_client):
        from app.services.groq_service import _make_groq_call
        from groq import RateLimitError

        mock_response = MagicMock()
        type(mock_response).status_code = PropertyMock(return_value=429)
        mock_response.headers = {"retry-after": "0.01"}
        mock_response.request = MagicMock()

        mock_client.chat.completions.create.side_effect = [
            RateLimitError("rate limit 1", response=mock_response, body={}),
            RateLimitError("rate limit 2", response=mock_response, body={}),
            RateLimitError("rate limit 3", response=mock_response, body={}),
        ]

        reset_circuit_breaker()
        with patch("app.services.groq_service.is_available", return_value=True):
            with pytest.raises(GroqRateLimited):
                _make_groq_call({"model": "test", "messages": []})

        assert mock_client.chat.completions.create.call_count == 3

    def test_429_counts_as_circuit_failure(self):
        from app.services.groq_service import _classify_groq_error
        from groq import RateLimitError

        mock_response = MagicMock()
        type(mock_response).status_code = PropertyMock(return_value=429)
        mock_response.headers = {}
        mock_response.request = MagicMock()

        reset_circuit_breaker()
        _classify_groq_error(RateLimitError("limit", response=mock_response, body={}))

        state = get_circuit_breaker_state()
        assert state["failure_count"] == 1


class TestAuthErrors:
    @patch("app.services.groq_service._client")
    def test_auth_error_no_retry(self, mock_client):
        from app.services.groq_service import create_chat_completion
        from groq import AuthenticationError

        mock_response = MagicMock()
        type(mock_response).status_code = PropertyMock(return_value=401)
        mock_response.request = MagicMock()

        mock_client.chat.completions.create.side_effect = AuthenticationError(
            "auth failed", response=mock_response, body={}
        )

        reset_circuit_breaker()
        with patch("app.services.groq_service.is_available", return_value=True):
            with pytest.raises(RuntimeError, match="authentication failed"):
                create_chat_completion(messages=[{"role": "user", "content": "hi"}])

        assert mock_client.chat.completions.create.call_count == 1


# ─── Diagnostics ────────────────────────────────────────────────────────────

class TestDiagnostics:
    def test_get_groq_diagnostics_includes_all_fields(self):
        diag = get_groq_diagnostics()
        assert "configured" in diag
        assert "model" in diag
        assert "circuit_breaker" in diag
        assert "last_error_code" in diag

    def test_diagnostics_reflects_circuit_breaker_state(self):
        for _ in range(settings.circuit_breaker_threshold):
            _circuit_breaker_record_failure()
        diag = get_groq_diagnostics()
        assert diag["circuit_breaker"]["state"] == CIRCUIT_OPEN
        assert diag["circuit_breaker"]["failure_count"] >= settings.circuit_breaker_threshold
        assert diag["circuit_breaker"]["cooldown_remaining"] > 0

    def test_diagnostics_does_not_expose_api_key(self):
        diag = get_groq_diagnostics()
        text = str(diag)
        assert "gsk_" not in text

    def test_get_circuit_breaker_state(self):
        state = get_circuit_breaker_state()
        assert "state" in state
        assert "failure_count" in state
        assert "threshold" in state
        assert "cooldown_remaining" in state
        assert "half_open_used" in state


# ─── Groq Success Path ──────────────────────────────────────────────────────

class TestGroqSuccess:
    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_chat_completion")
    def test_returns_groq_source_on_success(self, mock_create, mock_avail):
        mock_create.return_value = "Hello,\n\nThank you for your inquiry.\n\nBest regards"
        reply, source = generate_reply(
            sender_name="Test",
            sender_email="test@test.com",
            subject="Question",
            email_body="I have a question",
            intent="Inquiry",
            urgency="Low",
            tone="Professional",
        )
        assert source == "groq"
        assert "Thank you" in reply


# ─── 413 Shortening in Reply Generation ─────────────────────────────────────

class Test413ReplyShortening:
    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_chat_completion")
    def test_retries_with_shorter_body_on_413(self, mock_create, mock_avail):
        mock_create.side_effect = [
            GroqPayloadTooLarge("Payload too large"),
            "Shortened reply text.",
        ]
        reply, source = generate_reply(
            sender_name="Test",
            sender_email="test@test.com",
            subject="Long email",
            email_body="x" * 20000,
            intent="Inquiry",
            urgency="Low",
            tone="Professional",
        )
        assert reply == "Shortened reply text."
        assert source == "groq"

    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_chat_completion")
    def test_413_retry_fails_returns_groq_unavailable(self, mock_create, mock_avail):
        mock_create.side_effect = [
            GroqPayloadTooLarge("Payload too large"),
            RuntimeError("Still fails"),
        ]
        reply, source = generate_reply(
            sender_name="Test",
            sender_email="test@test.com",
            subject="Long email",
            email_body="x" * 20000,
            intent="Inquiry",
            urgency="Low",
            tone="Professional",
        )
        assert reply == ""
        assert source == "groq_unavailable"


# ─── Open Circuit Breaker ───────────────────────────────────────────────────

class TestOpenCircuitBreaker:
    @patch("app.services.groq_service.is_available", return_value=True)
    @patch("app.services.groq_service._client")
    def test_open_circuit_returns_unavailable(self, mock_client, mock_avail):
        for _ in range(settings.circuit_breaker_threshold):
            _circuit_breaker_record_failure()

        reply, source = generate_reply(
            sender_name="Test",
            sender_email="test@test.com",
            subject="Test",
            email_body="Body",
            intent="Inquiry",
            urgency="Low",
            tone="Professional",
        )
        assert reply == ""
        assert source == "groq_unavailable"

    @patch("app.services.groq_service.is_available", return_value=True)
    @patch("app.services.groq_service._client")
    def test_half_open_success_recovery(self, mock_client, mock_avail):
        old_reset = settings.circuit_breaker_reset_seconds
        settings.circuit_breaker_reset_seconds = 0.01
        try:
            mock_client.chat.completions.create.return_value = MagicMock(
                choices=[MagicMock(message=MagicMock(content="Recovered reply."))]
            )

            for _ in range(settings.circuit_breaker_threshold):
                _circuit_breaker_record_failure()

            time.sleep(0.02)
            reply, source = generate_reply(
                sender_name="Test",
                sender_email="test@test.com",
                subject="Test",
                email_body="Body",
                intent="Inquiry",
                urgency="Low",
                tone="Professional",
            )
            assert reply == "Recovered reply."
            assert source == "groq"
            assert get_circuit_breaker_state()["state"] == CIRCUIT_CLOSED
        finally:
            settings.circuit_breaker_reset_seconds = old_reset


# ─── Rule-Based Fallback Validation ─────────────────────────────────────────

class TestRuleFallbackValidation:
    def test_rule_reply_passes_validation(self):
        reply = generate_reply_rule(
            sender_name="Alice",
            sender_email="alice@test.com",
            subject="Question about pricing",
            email_body="How much does it cost?",
            tone="Professional",
            intent="Inquiry",
            urgency="Low",
        )
        assert reply
        validation = validate_generated_reply(reply)
        assert validation.valid, f"Rule reply failed validation: {validation.message}"
        assert "[" not in reply
        assert "<" not in reply

    def test_rule_reply_no_html(self):
        reply = generate_reply_rule(
            sender_name="Bob",
            sender_email="bob@test.com",
            subject="Issue with login",
            email_body="I can't log in",
            tone="Professional",
            intent="Support",
            urgency="High",
        )
        assert "<html" not in reply.lower()
        assert "<a " not in reply.lower()

    def test_rule_reply_spam_intent_empty(self):
        reply = generate_reply_rule(
            sender_name="Spammer",
            sender_email="spam@test.com",
            subject="Buy now",
            email_body="Limited offer",
            tone="Professional",
            intent="Spam",
            urgency="Low",
        )
        assert reply == ""

    def test_rule_reply_one_greeting_one_closing(self):
        reply = generate_reply_rule(
            sender_name="Charlie",
            sender_email="charlie@test.com",
            subject="Meeting request",
            email_body="Can we meet?",
            tone="Professional",
            intent="Request",
            urgency="Medium",
        )
        greetings = [p for p in ["Hello", "Dear"] if p in reply]
        assert len(greetings) == 1
        assert reply.count("Best regards") == 1


# ─── Explicit Generate Reply Route Logic ────────────────────────────────────

class TestExplicitGenerateReplyFallback:
    def test_generate_reply_returns_groq_unavailable(self):
        reply, source = generate_reply(
            sender_name="Test",
            sender_email="test@test.com",
            subject="Test subject",
            email_body="Test body",
            intent="Inquiry",
            urgency="Low",
            tone="Professional",
        )
        assert source == "groq_unavailable"
        assert reply == ""

    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_chat_completion")
    def test_groq_failure_source_is_groq_unavailable(self, mock_create, mock_avail):
        mock_create.side_effect = RuntimeError("Groq is down")
        reply, source = generate_reply(
            sender_name="Test",
            sender_email="test@test.com",
            subject="Test",
            email_body="Body",
            intent="Inquiry",
            urgency="Low",
            tone="Professional",
        )
        assert reply == ""
        assert source == "groq_unavailable"

    def test_rule_fallback_is_available_independently(self):
        reply = generate_reply_rule(
            sender_name="Dave",
            sender_email="dave@test.com",
            subject="Pricing question",
            email_body="How much?",
            tone="Professional",
            intent="Inquiry",
            urgency="Low",
        )
        assert reply
        assert "Dear" in reply or "Hello" in reply
        assert "Best regards" in reply

    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_chat_completion")
    def test_rule_fallback_no_reply_for_promotion(self, mock_create, mock_avail):
        mock_create.side_effect = RuntimeError("Groq is down")
        reply, source = generate_reply(
            sender_name="Marketing",
            sender_email="promo@test.com",
            subject="Big sale",
            email_body="Buy now!",
            intent="Other",
            urgency="Low",
            tone="Professional",
        )
        assert source == "groq_unavailable"
        assert reply == ""

    def test_rule_fallback_no_reply_for_no_reply_sender(self):
        reply = generate_reply_rule(
            sender_name="",
            sender_email="no-reply@example.com",
            subject="Update",
            email_body="System update",
            tone="Professional",
            intent="Other",
            urgency="Low",
        )
        assert reply


# ─── Reply Validation ───────────────────────────────────────────────────────

class TestReplyValidationIntegration:
    def test_rule_reply_passes_all_validation_checks(self):
        reply = generate_reply_rule(
            sender_name="Eve",
            sender_email="eve@test.com",
            subject="Support ticket",
            email_body="I need help",
            tone="Professional",
            intent="Support",
            urgency="Medium",
        )
        assert reply
        valid = validate_generated_reply(reply)
        assert valid.valid
        assert not valid.error_code

    def test_empty_reply_fails_validation(self):
        valid = validate_generated_reply("")
        assert not valid.valid
        assert valid.error_code == "EMPTY_REPLY"

    def test_html_reply_fails_validation(self):
        valid = validate_generated_reply("<p>Hello</p>")
        assert not valid.valid
        assert valid.error_code == "CONTAINS_HTML"


# ─── Diagnostics Endpoint Integration ───────────────────────────────────────

class TestDiagnosticsEndpoint:
    def test_health_endpoint_returns_circuit_breaker_state(self, client, auth_headers):
        response = client.get("/api/groq/diagnostics", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert "circuit_breaker" in data
        assert "configured" in data
        assert "last_error_code" in data

    def test_diagnostics_endpoint_no_auth_required(self, client):
        response = client.get("/api/groq/diagnostics")
        assert response.status_code == 200
