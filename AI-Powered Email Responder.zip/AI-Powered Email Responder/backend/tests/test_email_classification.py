"""Tests for email classification: no-reply rules, reply validation, promotional categorization."""

from unittest.mock import patch

import pytest

from app.services.email_analysis_service import (
    check_no_reply_rules,
    check_no_reply_headers,
    validate_generated_reply,
    process_email,
    analyze_email_llm,
)


class TestNoReplyRules:
    def test_promotion_category_blocks_reply(self):
        result = check_no_reply_rules(category="promotion", requires_reply=True)
        assert result["block_reply"] is True
        assert result["requires_reply"] is False

    def test_newsletter_category_blocks_reply(self):
        result = check_no_reply_rules(category="newsletter")
        assert result["block_reply"] is True

    def test_spam_category_blocks_reply(self):
        result = check_no_reply_rules(category="spam")
        assert result["block_reply"] is True

    def test_social_notification_blocks_reply(self):
        result = check_no_reply_rules(category="social_notification")
        assert result["block_reply"] is True

    def test_bulk_marketing_sender_blocks_reply(self):
        result = check_no_reply_rules(sender_type="bulk_marketing")
        assert result["block_reply"] is True

    def test_no_reply_sender_type_blocks_reply(self):
        result = check_no_reply_rules(sender_type="no_reply")
        assert result["block_reply"] is True

    def test_automated_sender_type_blocks_reply(self):
        result = check_no_reply_rules(sender_type="automated")
        assert result["block_reply"] is True

    def test_personal_category_allows_reply(self):
        result = check_no_reply_rules(category="personal", requires_reply=True)
        assert result["block_reply"] is False
        assert result["requires_reply"] is True

    def test_inquiry_category_allows_reply(self):
        result = check_no_reply_rules(category="inquiry", requires_reply=True)
        assert result["block_reply"] is False

    def test_support_category_allows_reply(self):
        result = check_no_reply_rules(category="support", requires_reply=True)
        assert result["block_reply"] is False


class TestNoReplyHeaders:
    def test_no_reply_sender_detected(self):
        result = check_no_reply_headers(sender_email="no-reply@example.com")
        assert result["block_reply"] is True

    def test_noreply_sender_detected(self):
        result = check_no_reply_headers(sender_email="noreply@company.com")
        assert result["block_reply"] is True

    def test_normal_sender_allowed(self):
        result = check_no_reply_headers(sender_email="john@example.com")
        assert result["block_reply"] is False


class TestReplyValidation:
    def test_valid_reply_passes(self):
        result = validate_generated_reply("Hello,\n\nThank you for your inquiry.\n\nBest regards,\nJohn")
        assert result.valid is True

    def test_raw_html_is_rejected(self):
        result = validate_generated_reply("Hello,\n\n<p>Some HTML</p>\n\nBest regards")
        assert result.valid is False
        assert result.error_code == "CONTAINS_HTML"

    def test_tracking_url_is_rejected(self):
        result = validate_generated_reply("Hello,\n\nCheck http://mmstat.com/track\n\nBest regards")
        assert result.valid is False
        assert result.error_code == "CONTAINS_TRACKING_URL"

    def test_placeholder_brackets_rejected(self):
        result = validate_generated_reply("Hello,\n\n[Please provide details]\n\nBest regards")
        assert result.valid is False
        assert result.error_code == "CONTAINS_PLACEHOLDER"

    def test_lorem_ipsum_rejected(self):
        result = validate_generated_reply("Hello,\n\nLorem ipsum dolor sit amet.\n\nBest regards")
        assert result.valid is False
        assert result.error_code == "CONTAINS_PLACEHOLDER"

    def test_duplicate_best_regards_rejected(self):
        result = validate_generated_reply("Hello,\n\nText\n\nSincerely\n\nSincerely\n\nBest regards")
        assert result.valid is False
        assert result.error_code == "DUPLICATE_CLOSING"

    def test_empty_reply_rejected(self):
        result = validate_generated_reply("")
        assert result.valid is False
        assert result.error_code == "EMPTY_REPLY"

    def test_too_long_reply_rejected(self):
        long_reply = "Line\n" * 60
        result = validate_generated_reply(long_reply)
        assert result.valid is False
        assert result.error_code == "TOO_LONG"


class TestPromotionalEmailClassification:
    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_aliExpress_promotion_classified_as_promotion(self, mock_create, mock_avail):
        mock_create.return_value = {
            "category": "promotion",
            "intent": "Other",
            "urgency": "Low",
            "spam": False,
            "sender_type": "bulk_marketing",
            "requires_reply": False,
            "summary": "Promotional email advertising a microphone privacy accessory.",
            "reason": "Bulk promotional content with tracking links and no direct question.",
        }
        result = process_email(
            sender="aliexpress@mail.aliexpress.com",
            subject="Check out our new microphone privacy cover!",
            body="Dear Customer, check out our new product! Shop now at aliexpress.com",
            tone="Professional",
        )
        assert result["category"] == "promotion"
        assert result["requires_reply"] is False
        assert result["reply"] == ""
        assert result["reply_generated"] is False

    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_promotional_email_requires_reply_false(self, mock_create, mock_avail):
        mock_create.return_value = {
            "category": "promotion",
            "intent": "Other",
            "urgency": "Low",
            "spam": False,
            "sender_type": "bulk_marketing",
            "requires_reply": False,
            "summary": "Marketing email.",
            "reason": "Promotional content.",
        }
        result = process_email(
            sender="marketing@store.com",
            subject="Big sale today!",
            body="Limited time offer. Buy now!",
            tone="Professional",
        )
        assert result["requires_reply"] is False
        assert result["reply"] == ""

    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_no_reply_sender_does_not_generate_reply(self, mock_create, mock_avail):
        mock_create.return_value = {
            "category": "other",
            "intent": "Other",
            "urgency": "Low",
            "spam": False,
            "sender_type": "no_reply",
            "requires_reply": False,
            "summary": "Automated notification.",
            "reason": "No-reply sender.",
        }
        result = process_email(
            sender="no-reply@company.com",
            subject="Your account statement",
            body="Your monthly statement is ready.",
            tone="Professional",
        )
        assert result["requires_reply"] is False
        assert result["reply"] == ""


class TestGroqFailureBehavior:
    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_groq_failure_does_not_create_fake_draft(self, mock_create, mock_avail):
        mock_create.side_effect = RuntimeError("Groq API error")
        result = process_email(
            sender="user@test.com",
            subject="Hello",
            body="Just checking in",
            tone="Professional",
        )
        assert "reply" in result
        assert result["provider"] if "provider" in result else True


class TestPlaceholderRejection:
    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.generate_reply_groq")
    def test_placeholder_text_not_in_final_output(self, mock_groq, mock_avail):
        mock_groq.return_value = "Hello,\n\n[Please provide the requested details here]\n\nBest regards"
        from app.services.email_analysis_service import generate_reply
        result, source = generate_reply(
            sender_name="",
            sender_email="user@test.com",
            subject="Test",
            email_body="Test body",
            intent="Inquiry",
            urgency="Low",
            tone="Professional",
        )
        assert "[Please provide" not in result


class TestValidPersonalInquiry:
    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    @patch("app.services.email_analysis_service.generate_reply_groq")
    def test_generates_one_clean_reply(self, mock_groq, mock_create, mock_avail):
        mock_create.return_value = {
            "category": "inquiry",
            "intent": "Inquiry",
            "urgency": "Low",
            "spam": False,
            "sender_type": "human",
            "requires_reply": True,
            "summary": "Customer asking about product pricing.",
            "reason": "Direct question from a potential customer.",
        }
        mock_groq.return_value = "Hello,\n\nThank you for reaching out. Our pricing starts at $19.99 per month.\n\nBest regards,\nSupport"
        result = process_email(
            sender="customer@test.com",
            subject="How much does it cost?",
            body="I would like to know your pricing for the premium plan.",
            tone="Professional",
        )
        assert result["intent"] == "Inquiry"
        assert result["requires_reply"] is True
        assert result["reply_generated"] is True
        assert len(result["reply"]) > 0
        assert "Hello," in result["reply"]
        assert "Best regards" in result["reply"]
        assert "[Please" not in result["reply"]
        assert "<" not in result["reply"]
