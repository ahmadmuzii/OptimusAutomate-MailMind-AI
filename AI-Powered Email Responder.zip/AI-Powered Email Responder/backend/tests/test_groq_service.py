"""Tests for the centralized Groq service."""

from unittest.mock import patch, MagicMock

import pytest

from app.services.groq_service import (
    is_available, create_chat_completion, create_structured_analysis,
)


def test_groq_not_available_by_default():
    assert not is_available()


def test_reply_generation_returns_empty_when_groq_unavailable():
    from app.services.email_analysis_service import generate_reply
    reply, source = generate_reply(
        sender_name="Test",
        sender_email="test@test.com",
        subject="Test subject",
        email_body="Test body",
        intent="Inquiry",
        urgency="Low",
        tone="Professional",
    )
    assert source == "groq_unavailable"
    assert reply == ""


@patch("app.services.groq_service._client")
def test_create_chat_completion_failure_returns_fallback(mock_client):
    mock_client.chat.completions.create.side_effect = Exception("API error")

    with patch("app.services.groq_service.is_available", return_value=True):
        with pytest.raises(RuntimeError, match="Groq API error"):
            create_chat_completion(
                messages=[{"role": "user", "content": "Hello"}],
            )


def test_ai_health_endpoint(client, auth_headers):
    response = client.get("/api/health/ai", headers=auth_headers)
    assert response.status_code == 200
    data = response.json()
    assert data["configured"] == False
    assert data["provider"] == "groq"
    assert "message" in data


from app.core.config import settings


def test_api_key_not_exposed(client, auth_headers):
    response = client.get("/api/health", headers=auth_headers)
    data = response.json()
    assert "groq_api_configured" in data
    assert "gsk_" not in str(data)


@patch("app.services.email_analysis_service.create_chat_completion")
@patch("app.services.email_analysis_service.is_available", return_value=True)
def test_regeneration_includes_previous_reply(mock_available, mock_create):
    from app.services.email_analysis_service import generate_reply_groq

    mock_create.return_value = "Revised reply text"

    result = generate_reply_groq(
        sender_name="Test",
        sender_email="test@test.com",
        subject="Test",
        email_body="Body",
        tone="Professional",
        intent="Inquiry",
        urgency="Low",
        previous_reply="Previous version",
    )
    assert result == "Revised reply text"
    assert mock_create.called


def test_groq_failure_returns_error_source():
    from app.services.email_analysis_service import generate_reply
    reply, source = generate_reply(
        sender_name="",
        sender_email="fail@test.com",
        subject="Fallback test",
        email_body="Test when groq is not available",
        intent="Inquiry",
        urgency="Low",
        tone="Professional",
    )
    assert source == "groq_unavailable"
    assert reply == ""
