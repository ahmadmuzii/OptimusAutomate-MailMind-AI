"""Tests for email cleaner: hidden elements, tracking pixels, CSS, quoted history, AliExpress fixture."""

from app.services.email_cleaner import clean_email_content, _html_to_text


ALIEXPRESS_HTML = """<div style="display:none">
<img src="http://ae.mmstat.com/..." width="1" height="1">
</div>
<div>
<p>Dear Customer,</p>
<p>Check out our new microphone privacy cover!</p>
<img src="http://ae.mmstat.com/track?pid=123" width="1" height="1">
<a href="https://www.aliexpress.com/item/123">Shop Now</a>
<p style="font-size:10px;color:gray;">You received this email because you subscribed to promotions.</p>
<p><a href="#">Unsubscribe</a></p>
</div>
<!-- tracking pixel -->
<img src="https://www.aliexpress.com/pixel.png" width="1" height="1">
<script>console.log('tracking');</script>
<style>.promo{color:red;}</style>
"""


def test_hidden_html_elements_removed():
    result = clean_email_content(html_body="<div style='display:none'>HIDDEN</div><p>VISIBLE</p>")
    assert "HIDDEN" not in result
    assert "VISIBLE" in result


def test_tracking_pixels_removed():
    result = clean_email_content(html_body="<p>Hello</p><img src='http://tracker.com/pixel.png' width='1' height='1'>")
    assert "tracker" not in result.lower()


def test_css_removed():
    result = clean_email_content(html_body="<style>body{color:red}</style><p>Text</p>")
    assert "color:red" not in result
    assert "Text" in result


def test_scripts_removed():
    result = clean_email_content(html_body="<script>alert('xss')</script><p>Safe</p>")
    assert "alert" not in result
    assert "Safe" in result


def test_html_comments_removed():
    result = clean_email_content(html_body="<p>Text</p><!-- tracking pixel --><p>More</p>")
    assert "tracking pixel" not in result


def test_tracking_domains_scrubbed():
    result = clean_email_content(html_body="Click http://ae.mmstat.com/abc123")
    assert "mmstat" not in result


def test_aliExpress_promotional_email_fixture():
    result = clean_email_content(html_body=ALIEXPRESS_HTML)
    assert "display:none" not in result
    assert "mmstat" not in result.lower()
    assert "Dear Customer" in result or "Customer" in result
    assert "microphone privacy cover" in result.lower()
    assert "Shop Now" in result or "aliexpress" in result.lower()
    assert "pixel.png" not in result
    assert "console.log" not in result
    assert "color:red" not in result


def test_plain_text_body_preferred():
    plain = "Hello, this is a real message."
    html = "<html><body><div style='display:none'>HIDDEN</div><p>HTML version</p></body></html>"
    result = clean_email_content(html_body=html, plain_body=plain)
    assert result == plain


def test_empty_plain_text_falls_back_to_html():
    result = clean_email_content(html_body="<p>HTML only</p>", plain_body="")
    assert "HTML only" in result


def test_no_input_returns_empty():
    assert clean_email_content() == ""
    assert clean_email_content(html_body="") == ""
    assert clean_email_content(plain_body=None, html_body=None) == ""


def test_hidden_unicode_removed():
    text = "Hello\u200bWorld"
    result = clean_email_content(plain_body=text)
    assert result == "HelloWorld"


def test_base64_lines_removed():
    text = "Some text\nSGVsbG8gV29ybGQhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISAg\nMore text"
    result = clean_email_content(plain_body=text)
    assert "SGVsbG8g" not in result
    assert "Some text" in result
    assert "More text" in result


def test_quoted_reply_removed():
    text = "My reply\n\nOn Mon, Jan 1, 2024 at 10:00 AM John <john@test.com> wrote:\n> Quoted text\n> More quoted"
    result = clean_email_content(plain_body=text)
    assert "My reply" in result
    assert "On Mon" not in result
    assert "Quoted text" not in result


def test_signature_removed():
    text = "Message body\n\n--\nJohn Doe\nCEO\nPhone: 555-1234"
    result = clean_email_content(plain_body=text)
    assert "Message body" in result
    assert "John Doe" not in result
    assert "Phone:" not in result


def test_disclaimer_removed():
    text = "Here is my message.\n\nThis email is confidential and intended solely for the addressee.\n\nRegards,\nJohn"
    result = clean_email_content(plain_body=text)
    assert "Here is my message" in result
    assert "confidential" not in result


def test_unsubscribe_removed():
    text = "Great offer!\n\nTo unsubscribe click here.\n\nBest regards"
    result = clean_email_content(plain_body=text)
    assert "unsubscribe" not in result.lower()
