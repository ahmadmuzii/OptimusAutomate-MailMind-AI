from app.services.email_analysis_service import (
    detect_intent_rule,
    detect_sender_type,
    detect_category_rule,
    check_no_reply_rules,
    summarize_rule,
)


HUMAN_EMAIL = "So I have been concerned about my MailMind AI - for this automation system lets see how it turns out to be!"


def test_human_personal_email_classified_as_human():
    result = detect_sender_type("john@gmail.com", "John Doe")
    assert result == "human"


def test_human_email_without_name():
    result = detect_sender_type("user@outlook.com")
    assert result == "human"


def test_project_discussion_requires_reply():
    intent = detect_intent_rule("MailMind project", HUMAN_EMAIL)
    assert intent in ("Project_Discussion", "Feedback", "Information")
    category = detect_category_rule(intent, HUMAN_EMAIL)
    assert category == "personal"
    no_reply = check_no_reply_rules(
        category=category,
        sender_type="human",
        sender_email="john@gmail.com",
        requires_reply=True,
    )
    assert no_reply["block_reply"] is False


def test_no_reply_still_blocks_promotion():
    no_reply = check_no_reply_rules(
        category="promotion",
        sender_type="bulk_marketing",
        sender_email="marketing@mailchimp.com",
        requires_reply=False,
    )
    assert no_reply["block_reply"] is True


def test_no_reply_still_blocks_newsletter():
    no_reply = check_no_reply_rules(
        category="newsletter",
        sender_type="automated",
        sender_email="newsletter@substack.com",
        requires_reply=False,
    )
    assert no_reply["block_reply"] is True


def test_no_reply_still_blocks_no_reply_sender():
    no_reply = check_no_reply_rules(
        category="other",
        sender_type="no_reply",
        sender_email="no-reply@company.com",
        requires_reply=True,
    )
    assert no_reply["block_reply"] is True


def test_category_other_does_not_auto_block():
    no_reply = check_no_reply_rules(
        category="other",
        sender_type="human",
        sender_email="user@gmail.com",
        requires_reply=True,
    )
    assert no_reply["block_reply"] is False


def test_unknown_sender_does_not_auto_block():
    no_reply = check_no_reply_rules(
        category="personal",
        sender_type="unknown",
        sender_email="somebody@customdomain.com",
        requires_reply=True,
    )
    assert no_reply["block_reply"] is False


def test_summary_does_not_contain_bracket_prefix():
    result = summarize_rule("Test subject", HUMAN_EMAIL, "Feedback")
    assert "[" not in result["summary"]


def test_analysis_provider_label_is_local_rules():
    assert "local_rules" == "local_rules"


def test_detect_category_rule_maps_intent():
    assert detect_category_rule("Feedback", HUMAN_EMAIL) == "personal"
    assert detect_category_rule("Project_Discussion", HUMAN_EMAIL) == "personal"
    assert detect_category_rule("Question", HUMAN_EMAIL) == "personal"
    assert detect_category_rule("Support", HUMAN_EMAIL) == "support"
    assert detect_category_rule("Inquiry", HUMAN_EMAIL) == "inquiry"
    assert detect_category_rule("Spam", HUMAN_EMAIL) == "spam"


def test_no_reply_sender_detected():
    assert detect_sender_type("no-reply@company.com") == "no_reply"
    assert detect_sender_type("noreply@service.com") == "no_reply"
    assert detect_sender_type("notifications@no_reply.io") == "no_reply"


def test_human_email_has_conversational_keywords():
    intent = detect_intent_rule("MailMind AI concerns", HUMAN_EMAIL)
    assert intent != "Other"


def test_no_reply_blocks_list_unsubscribe():
    no_reply = check_no_reply_rules(
        category="personal",
        sender_type="human",
        sender_email="newsletter@substack.com",
        requires_reply=True,
        headers={"List-Unsubscribe": "<mailto:unsub@substack.com>"},
    )
    assert no_reply["block_reply"] is True


def test_no_reply_blocks_auto_submitted():
    no_reply = check_no_reply_rules(
        category="personal",
        sender_type="human",
        sender_email="auto@system.com",
        requires_reply=True,
        headers={"Auto-Submitted": "auto-replied"},
    )
    assert no_reply["block_reply"] is True


def test_no_reply_blocks_precedence_bulk():
    no_reply = check_no_reply_rules(
        category="personal",
        sender_type="human",
        sender_email="bulk@mailer.com",
        requires_reply=True,
        headers={"Precedence": "bulk"},
    )
    assert no_reply["block_reply"] is True
