from app.services.intent_service import detect_intent


def test_detect_complaint():
    result = detect_intent("Refund request", "I want my money back, this product is defective")
    assert result == "Complaint"


def test_detect_inquiry():
    result = detect_intent("Question about pricing", "How much does your premium plan cost?")
    assert result == "Inquiry"


def test_detect_support():
    result = detect_intent("Need help", "I cannot install the software, it keeps crashing")
    assert result == "Support"


def test_detect_other():
    result = detect_intent("Hello", "Just saying hi, how are you?")
    assert result == "Other"
