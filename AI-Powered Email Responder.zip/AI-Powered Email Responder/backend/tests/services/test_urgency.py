from app.services.urgency_service import analyze_urgency


def test_high_urgency():
    result = analyze_urgency("URGENT: Legal matter", "This is an emergency, I need help ASAP", "Complaint")
    assert result == "High"


def test_low_urgency():
    result = analyze_urgency("Just wondering", "Take your time, no rush at all", "Inquiry")
    assert result == "Low"
