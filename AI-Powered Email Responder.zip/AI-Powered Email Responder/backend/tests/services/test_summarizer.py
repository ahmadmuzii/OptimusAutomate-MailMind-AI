from app.services.summarizer_service import summarize_email


def test_summarizer_fallback():
    result = summarize_email("Test Subject", "This is a short test email body", "Inquiry")
    assert "summary" in result
    assert "suggested_subject" in result
    assert result["suggested_subject"] == "Re: Test Subject"
