from app.services.reply_service import generate_reply


def test_reply_fallback_professional():
    reply = generate_reply(
        sender="test@test.com",
        subject="Test",
        email_body="Test body",
        intent="Inquiry",
        urgency="Low",
        tone="Professional",
        summary="Test summary",
    )
    assert "Dear Customer" in reply
    assert "Customer Support Team" in reply


def test_reply_fallback_apologetic():
    reply = generate_reply(
        sender="test@test.com",
        subject="Complaint",
        email_body="I am very unhappy",
        intent="Complaint",
        urgency="High",
        tone="Apologetic",
        summary="Customer unhappy",
    )
    assert "sincerely apologize" in reply
