"""Tests for persistent password reset flow."""

import hashlib
from datetime import datetime, timezone, timedelta


def test_forgot_password_returns_generic_response(client):
    """Forgot password should never reveal account existence."""
    response = client.post("/api/auth/forgot-password", json={
        "email": "nonexistent@example.com"
    })
    assert response.status_code == 200
    data = response.json()
    assert "If an account exists" in data["message"]


def test_forgot_password_existing_user(client):
    """Forgot password for existing user returns same generic message."""
    client.post("/api/auth/signup", json={
        "full_name": "Reset User",
        "email": "reset@example.com",
        "password": "password123",
        "confirm_password": "password123",
    })
    response = client.post("/api/auth/forgot-password", json={
        "email": "reset@example.com"
    })
    assert response.status_code == 200
    data = response.json()
    assert "If an account exists" in data["message"]


def test_reset_password_with_invalid_token(client):
    """Reset password with invalid token should fail."""
    response = client.post("/api/auth/reset-password", json={
        "token": "invalid-token",
        "new_password": "newpassword123",
        "confirm_password": "newpassword123",
    })
    assert response.status_code == 400
    assert "Invalid or expired" in response.json()["detail"]


def test_reset_password_password_mismatch(client):
    """Reset password with mismatched passwords should fail."""
    response = client.post("/api/auth/reset-password", json={
        "token": "some-token",
        "new_password": "newpassword123",
        "confirm_password": "different123",
    })
    assert response.status_code == 400
    assert "do not match" in response.json()["detail"].lower()


def test_reset_password_too_short(client):
    """Reset password with short password should fail (Pydantic validation)."""
    response = client.post("/api/auth/reset-password", json={
        "token": "some-token",
        "new_password": "short",
        "confirm_password": "short",
    })
    assert response.status_code in [400, 422]


def test_password_reset_token_not_in_db_raw(client):
    """Verify raw token is not stored in the database."""
    from app.database.base import Base
    from app.database.session import SessionLocal, engine
    from app.models.password_reset import PasswordResetToken

    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        tokens = db.query(PasswordResetToken).all()
        for t in tokens:
            assert "@" not in t.token_hash
            assert len(t.token_hash) == 64  # SHA-256 hex digest
    finally:
        db.close()


def test_password_reset_development_url(client):
    """In development mode, the reset URL may be returned."""
    client.post("/api/auth/signup", json={
        "full_name": "Dev User",
        "email": "dev@example.com",
        "password": "password123",
        "confirm_password": "password123",
    })
    response = client.post("/api/auth/forgot-password", json={
        "email": "dev@example.com"
    })
    assert response.status_code == 200
    data = response.json()
    assert "development_reset_url" in data
