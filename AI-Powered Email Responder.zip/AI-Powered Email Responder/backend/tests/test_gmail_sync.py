"""Tests for Gmail sync functionality."""

from unittest.mock import patch, MagicMock, PropertyMock
from datetime import datetime, timezone

import pytest
from sqlalchemy.orm import Session

from app.exceptions import GmailReauthRequired
from app.models.gmail_connection import GmailConnection
from app.models.sync_log import GmailSyncLog


def test_manual_sync_endpoint_no_connection(client, auth_headers):
    """Manual sync should return 409 GMAIL_REAUTH_REQUIRED when Gmail never connected."""
    response = client.post("/api/gmail/sync", headers=auth_headers)
    assert response.status_code == 409
    data = response.json()
    assert data["success"] is False
    assert data["error"]["code"] == "GMAIL_REAUTH_REQUIRED"
    assert "not connected" in data["error"]["message"].lower()


def test_manual_sync_endpoint_reauth_required(client, auth_headers, db_session):
    """Manual sync should return 409 GMAIL_REAUTH_REQUIRED when token expired."""
    from app.models.user import User
    user = db_session.query(User).first()
    conn = GmailConnection(
        user_id=user.id,
        gmail_email="test@gmail.com",
        access_token="expired_token",
        refresh_token="expired_refresh",
        token_expiry=datetime(2020, 1, 1, tzinfo=timezone.utc),
        is_connected=True,
        status="reauth_required",
        last_error_code="GMAIL_REAUTH_REQUIRED",
        last_error_message="The Gmail authorization has expired or was revoked.",
        scopes="https://www.googleapis.com/auth/gmail.readonly",
    )
    db_session.add(conn)
    db_session.commit()

    response = client.post("/api/gmail/sync", headers=auth_headers)
    assert response.status_code == 409
    data = response.json()
    assert data["success"] is False
    assert data["error"]["code"] == "GMAIL_REAUTH_REQUIRED"


def test_sync_does_not_return_app_401(client, auth_headers, db_session):
    """Gmail refresh failure must never return application 401."""
    from app.models.user import User
    user = db_session.query(User).first()
    conn = GmailConnection(
        user_id=user.id,
        gmail_email="test@gmail.com",
        access_token="expired_token",
        refresh_token="expired_refresh",
        token_expiry=datetime(2020, 1, 1, tzinfo=timezone.utc),
        is_connected=True,
        status="reauth_required",
        last_error_code="GMAIL_REAUTH_REQUIRED",
        last_error_message="The Gmail authorization has expired or was revoked.",
        scopes="https://www.googleapis.com/auth/gmail.readonly",
    )
    db_session.add(conn)
    db_session.commit()

    response = client.post("/api/gmail/sync", headers=auth_headers)
    assert response.status_code != 401
    assert response.status_code == 409


def test_gmail_status_reauth_required(client, auth_headers, db_session):
    """Status endpoint should report reauth_required."""
    from app.models.user import User
    user = db_session.query(User).first()
    conn = GmailConnection(
        user_id=user.id,
        gmail_email="test@gmail.com",
        access_token="expired",
        refresh_token="expired",
        token_expiry=datetime(2020, 1, 1, tzinfo=timezone.utc),
        is_connected=True,
        status="reauth_required",
        last_error_code="GMAIL_REAUTH_REQUIRED",
        last_error_message="Reconnect Gmail to continue syncing.",
        scopes="https://www.googleapis.com/auth/gmail.readonly",
    )
    db_session.add(conn)
    db_session.commit()

    response = client.get("/api/gmail/status", headers=auth_headers)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "reauth_required"
    assert data["is_connected"] is False
    assert data["last_error_code"] == "GMAIL_REAUTH_REQUIRED"
    assert data["last_error_message"] is not None


def test_gmail_status_connected(client, auth_headers, db_session):
    """Status endpoint should report connected when token is valid."""
    from app.models.user import User
    user = db_session.query(User).first()
    conn = GmailConnection(
        user_id=user.id,
        gmail_email="test@gmail.com",
        access_token="valid_token",
        refresh_token="valid_refresh",
        token_expiry=datetime(2030, 1, 1, tzinfo=timezone.utc),
        is_connected=True,
        status="connected",
        scopes="https://www.googleapis.com/auth/gmail.readonly",
    )
    db_session.add(conn)
    db_session.commit()

    response = client.get("/api/gmail/status", headers=auth_headers)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "connected"
    assert data["is_connected"] is True
    assert data["gmail_email"] == "test@gmail.com"


def test_gmail_status_disconnected(client, auth_headers):
    """Status endpoint should report disconnected when no connection exists."""
    response = client.get("/api/gmail/status", headers=auth_headers)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "disconnected"
    assert data["is_connected"] is False


def test_sync_marks_integration_reauth_on_refresh_error(client, auth_headers, db_session):
    """Sync should mark integration as reauth_required on token refresh failure."""
    from google.auth.exceptions import RefreshError
    from app.models.user import User
    user = db_session.query(User).first()
    conn = GmailConnection(
        user_id=user.id,
        gmail_email="test@gmail.com",
        access_token="expired_token",
        refresh_token="expired_refresh",
        token_expiry=datetime(2020, 1, 1, tzinfo=timezone.utc),
        is_connected=True,
        status="connected",
        scopes="https://www.googleapis.com/auth/gmail.readonly",
    )
    db_session.add(conn)
    db_session.commit()

    mock_creds = MagicMock()
    mock_creds.expired = True
    mock_creds.refresh_token = "expired_refresh"
    mock_creds.token = "expired_token"
    mock_creds.refresh.side_effect = RefreshError(
        "invalid_grant: Token has been expired or revoked."
    )
    mock_creds_class = MagicMock(return_value=mock_creds)

    with patch("app.services.gmail_service._get_google_credentials", return_value=mock_creds_class):
        from app.services.gmail_service import GmailService
        svc = GmailService(user.id, db_session)
        result = svc._get_credentials()

    assert result is None

    db_session.refresh(conn)
    assert conn.status == "reauth_required"
    assert conn.last_error_code == "GMAIL_REAUTH_REQUIRED"
    assert conn.last_error_message is not None
    assert conn.is_connected is False


def test_gmail_reauth_exception_not_app_auth():
    """GmailReauthRequired must not be APP_AUTH_REQUIRED."""
    exc = GmailReauthRequired("test")
    assert "APP_AUTH_REQUIRED" not in str(exc)
    assert str(exc) == "test"


def test_oauth_auth_url_requests_offline_access(client, auth_headers):
    """OAuth authorization URL should request offline access and consent."""
    with patch("app.services.gmail_service._get_google_flow") as mock_get_flow, \
         patch("app.services.gmail_service.GmailService.is_configured", return_value=True):
        mock_flow_cls = MagicMock()
        mock_flow = MagicMock()
        mock_flow.authorization_url.return_value = ("http://example.com/auth", "state")
        mock_flow_cls.from_client_secrets_file.return_value = mock_flow
        mock_get_flow.return_value = mock_flow_cls

        response = client.get("/api/gmail/connect", headers=auth_headers)
        assert response.status_code == 200

        _, kwargs = mock_flow.authorization_url.call_args
        assert kwargs.get("access_type") == "offline"
        assert kwargs.get("prompt") == "consent"
        assert kwargs.get("include_granted_scopes") == "true"


def test_scheduled_sync_survives_reauth(client, auth_headers, db_session):
    """Scheduled sync should handle GmailReauthRequired gracefully without crashing."""
    from app.services.gmail_service import GmailService
    from app.models.user import User
    user = db_session.query(User).first()
    conn = GmailConnection(
        user_id=user.id,
        gmail_email="test@gmail.com",
        access_token="expired",
        refresh_token="expired",
        token_expiry=datetime(2020, 1, 1, tzinfo=timezone.utc),
        is_connected=True,
        status="reauth_required",
        last_error_code="GMAIL_REAUTH_REQUIRED",
        last_error_message="Reconnect Gmail.",
        scopes="https://www.googleapis.com/auth/gmail.readonly",
    )
    db_session.add(conn)
    db_session.commit()

    svc = GmailService(user.id, db_session)
    try:
        svc.sync_emails(max_results=50)
        assert False, "Expected GmailReauthRequired"
    except GmailReauthRequired:
        pass

    logs = db_session.query(GmailSyncLog).all()
    for log in logs:
        db_session.delete(log)
    db_session.commit()


def test_send_email_without_gmail(client, auth_headers):
    """Send endpoint should fail gracefully when Gmail not connected."""
    response = client.post("/api/gmail/send", json={"draft_id": 999}, headers=auth_headers)
    assert response.status_code == 404  # Draft not found


def test_sync_history_endpoint(client, auth_headers):
    """Sync history should return empty list for user with no syncs."""
    response = client.get("/api/gmail/sync-history", headers=auth_headers)
    assert response.status_code == 200
    assert response.json() == []


def test_gmail_status_endpoint_not_connected(client, auth_headers):
    """Gmail status should return not connected by default."""
    response = client.get("/api/gmail/status", headers=auth_headers)
    assert response.status_code == 200
    data = response.json()
    assert data["is_connected"] is False
    assert data["status"] == "disconnected"


def test_create_draft_and_send_flow(client, auth_headers):
    """Create a local draft, verify it exists, then verify send checks ownership."""
    create_resp = client.post("/api/drafts", json={
        "recipient": "test@example.com",
        "subject": "Test Draft",
        "body": "This is a test draft body.",
        "tone": "Professional",
    }, headers=auth_headers)
    assert create_resp.status_code == 201
    draft_id = create_resp.json()["id"]

    get_resp = client.get(f"/api/drafts/{draft_id}", headers=auth_headers)
    assert get_resp.status_code == 200
    assert get_resp.json()["status"] == "Local"

    send_resp = client.post("/api/gmail/send", json={"draft_id": draft_id}, headers=auth_headers)
    assert send_resp.status_code == 401
    assert "Gmail not connected" in str(send_resp.json()["detail"])
