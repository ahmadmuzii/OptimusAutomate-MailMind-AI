"""Tests for Groq pipeline: content cleaning, combined analysis, rate limiter, circuit breaker, 413 retry, batch limit."""

import time
from unittest.mock import patch, MagicMock, call

import pytest

from app.core.config import settings
from app.services.email_analysis_service import (
    clean_email_body,
    analyze_email_llm,
    process_email,
    COMBINED_ANALYSIS_PROMPT,
)
from app.services.groq_service import (
    _enforce_rate_limit,
    _circuit_breaker_allow,
    _circuit_breaker_record_success,
    _circuit_breaker_record_failure,
    _consecutive_failures,
    _circuit_open_until,
    _last_request_time,
    GroqPayloadTooLarge,
    GroqRateLimited,
    GroqServiceUnavailable,
    reset_rate_limiter,
    reset_circuit_breaker,
    create_structured_analysis,
)


# ─── Fixtures ───────────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def reset_globals():
    reset_rate_limiter()
    reset_circuit_breaker()
    yield


# ─── Content Cleaning ───────────────────────────────────────────────────────

class TestCleanEmailBody:
    def test_strips_html_tags(self):
        raw = "<html><body><p>Hello</p></body></html>"
        assert clean_email_body(raw) == "Hello"

    def test_strips_quote_lines(self):
        raw = "My reply\n> Quoted text\n> More quoted\nOriginal line"
        assert clean_email_body(raw) == "My reply\n\nOriginal line"

    def test_strips_signature(self):
        raw = "Message body\n\n--\nJohn Doe\nCEO\nPhone: 555-1234"
        assert clean_email_body(raw) == "Message body"

    def test_strips_mime_attachments(self):
        raw = "Body text\n--boundary_123\nContent-Type: text/plain"
        result = clean_email_body(raw)
        assert "Content-Type" not in result
        assert "boundary_123" not in result
        assert "Body text" in result

    def test_collapses_excess_newlines(self):
        raw = "Line1\n\n\n\n\nLine2"
        result = clean_email_body(raw)
        assert "Line1\n\nLine2" == result

    def test_truncates_to_max_chars(self):
        long_body = "x" * (settings.groq_max_email_chars + 1000)
        result = clean_email_body(long_body)
        assert len(result) <= settings.groq_max_email_chars

    def test_returns_empty_for_none(self):
        assert clean_email_body(None) == ""
        assert clean_email_body("") == ""


# ─── Combined Analysis Parsing ──────────────────────────────────────────────

class TestAnalyzeEmailLlm:
    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_parses_valid_response(self, mock_create, mock_avail):
        mock_create.return_value = {
            "category": "inquiry",
            "spam": False,
            "intent": "Inquiry",
            "urgency": "Low",
            "sender_type": "human",
            "summary": "Customer asking about pricing.",
            "requires_reply": True,
            "reason": "Direct question.",
        }
        result = analyze_email_llm("Pricing question", "How much does it cost?")
        assert result is not None
        assert result["is_spam"] is False
        assert result["intent"] == "Inquiry"
        assert result["urgency"] == "Low"
        assert "pricing" in result["summary"].lower()
        assert result["requires_reply"] is True
        assert result["category"] == "inquiry"

    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_handles_spam_email(self, mock_create, mock_avail):
        mock_create.return_value = {
            "category": "spam",
            "spam": True,
            "intent": "Spam",
            "urgency": "Low",
            "sender_type": "bulk_marketing",
            "summary": "Unsolicited promotional email.",
            "requires_reply": False,
            "reason": "Bulk unsolicited content.",
        }
        result = analyze_email_llm("Buy now!", "Limited offer act now")
        assert result is not None
        assert result["is_spam"] is True
        assert result["requires_reply"] is False

    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_falls_back_when_intent_invalid(self, mock_create, mock_avail):
        mock_create.return_value = {
            "category": "other",
            "spam": False,
            "intent": "InvalidIntent",
            "urgency": "Medium",
            "sender_type": "unknown",
            "summary": "Test",
            "requires_reply": True,
            "reason": "Test.",
        }
        result = analyze_email_llm("Test", "Test body")
        assert result is not None
        assert result["intent"] == "Other"

    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_falls_back_when_urgency_invalid(self, mock_create, mock_avail):
        mock_create.return_value = {
            "category": "other",
            "spam": False,
            "intent": "Inquiry",
            "urgency": "Critical",
            "sender_type": "unknown",
            "summary": "Test",
            "requires_reply": True,
            "reason": "Test.",
        }
        result = analyze_email_llm("Test", "Test body")
        assert result is not None
        assert result["urgency"] == "Low"

    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_returns_none_when_groq_unavailable(self, mock_create, mock_avail):
        mock_create.side_effect = RuntimeError("Groq error")
        result = analyze_email_llm("Test", "Test body")
        assert result is None

    @patch("app.services.email_analysis_service.is_available", return_value=False)
    def test_returns_none_when_not_available(self, mock_avail):
        result = analyze_email_llm("Test", "Test body")
        assert result is None


# ─── 413 Shortening Retry ───────────────────────────────────────────────────

class Test413ShorteningRetry:
    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_retries_with_shorter_body_on_413(self, mock_create, mock_avail):
        mock_create.side_effect = [
            GroqPayloadTooLarge("Payload too large"),
            {
                "category": "inquiry",
                "spam": False,
                "intent": "Inquiry",
                "urgency": "Low",
                "sender_type": "human",
                "summary": "After shortening.",
                "requires_reply": True,
                "reason": "Shortened analysis.",
            },
        ]
        result = analyze_email_llm("Question", "x" * 20000)
        assert result is not None
        assert mock_create.call_count == 2
        second_call_body = mock_create.call_args[1]["user_prompt"]
        assert len(second_call_body) < 8000

    @patch("app.services.email_analysis_service.is_available", return_value=True)
    @patch("app.services.email_analysis_service.create_structured_analysis")
    def test_returns_none_if_413_retry_also_fails(self, mock_create, mock_avail):
        mock_create.side_effect = [
            GroqPayloadTooLarge("Payload too large"),
            RuntimeError("Still fails"),
        ]
        result = analyze_email_llm("Question", "x" * 20000)
        assert result is None


# ─── Process Email Integration ──────────────────────────────────────────────

class TestProcessEmail:
    @patch("app.services.email_analysis_service.analyze_email_llm")
    def test_uses_combined_analysis_result(self, mock_analyze):
        mock_analyze.return_value = {
            "is_spam": False,
            "intent": "Support",
            "urgency": "High",
            "summary": "User needs help with login.",
            "requires_reply": True,
        }
        with patch("app.services.email_analysis_service.generate_reply") as mock_reply:
            mock_reply.return_value = ("Thank you for reaching out.", "groq")
            result = process_email(
                sender="user@test.com",
                subject="Cannot login",
                body="I cannot access my account",
                tone="Professional",
            )
            assert result["intent"] == "Support"
            assert result["urgency"] == "High"
            assert "login" in result["summary"]
            assert result["is_spam"] is False
            assert len(result["reply"]) > 0

    @patch("app.services.email_analysis_service.analyze_email_llm")
    def test_skips_reply_for_spam(self, mock_analyze):
        mock_analyze.return_value = {
            "is_spam": True,
            "intent": "Spam",
            "urgency": "Low",
            "summary": "Spam detected.",
            "requires_reply": False,
        }
        result = process_email(
            sender="spam@test.com",
            subject="Buy now",
            body="Limited offer",
            tone="Professional",
        )
        assert result["is_spam"] is True
        assert result["reply"] == ""

    @patch("app.services.email_analysis_service.analyze_email_llm")
    def test_skips_reply_when_not_required(self, mock_analyze):
        mock_analyze.return_value = {
            "is_spam": False,
            "intent": "Feedback",
            "urgency": "Low",
            "summary": "User provided feedback.",
            "requires_reply": False,
        }
        result = process_email(
            sender="feedback@test.com",
            subject="Great service",
            body="I love your product",
            tone="Friendly",
        )
        assert result["is_spam"] is False
        assert result["reply"] == ""

    @patch("app.services.email_analysis_service.analyze_email_llm")
    def test_reply_generated_when_required(self, mock_analyze):
        mock_analyze.return_value = {
            "is_spam": False,
            "intent": "Inquiry",
            "urgency": "Medium",
            "summary": "Customer asking about prices.",
            "requires_reply": True,
        }
        with patch("app.services.email_analysis_service.generate_reply") as mock_reply:
            mock_reply.return_value = ("Here are our prices.", "groq")
            result = process_email(
                sender="buyer@test.com",
                subject="Pricing",
                body="How much does it cost?",
                tone="Professional",
            )
            assert result["reply"] == "Here are our prices."

    @patch("app.services.email_analysis_service.analyze_email_llm")
    def test_falls_back_to_rule_based_when_llm_fails(self, mock_analyze):
        mock_analyze.return_value = None
        result = process_email(
            sender="user@test.com",
            subject="Hello",
            body="Just saying hi",
            tone="Professional",
        )
        assert result["intent"] in ["Other", "Inquiry"]
        assert "reply" in result


# ─── Rate Limiter ───────────────────────────────────────────────────────────

class TestRateLimiter:
    def test_enforces_minimum_interval(self):
        reset_rate_limiter()
        start = time.monotonic()
        _enforce_rate_limit()
        _enforce_rate_limit()
        elapsed = time.monotonic() - start
        assert elapsed >= settings.groq_min_request_interval_seconds - 0.1

    def test_first_call_no_delay(self):
        reset_rate_limiter()
        start = time.monotonic()
        _enforce_rate_limit()
        elapsed = time.monotonic() - start
        assert elapsed < 0.1


# ─── Circuit Breaker ────────────────────────────────────────────────────────

class TestCircuitBreaker:
    def test_starts_closed(self):
        reset_circuit_breaker()
        assert _circuit_breaker_allow() is True

    def test_opens_after_threshold_failures(self):
        reset_circuit_breaker()
        threshold = settings.circuit_breaker_threshold
        for _ in range(threshold):
            _circuit_breaker_record_failure()
        assert _circuit_breaker_allow() is False

    def test_allows_requests_below_threshold(self):
        reset_circuit_breaker()
        for _ in range(settings.circuit_breaker_threshold - 1):
            _circuit_breaker_record_failure()
        assert _circuit_breaker_allow() is True

    def test_resets_on_success(self):
        reset_circuit_breaker()
        for _ in range(settings.circuit_breaker_threshold):
            _circuit_breaker_record_failure()
        assert _circuit_breaker_allow() is False
        _circuit_breaker_record_success()
        assert _circuit_breaker_allow() is True

    def test_closes_after_reset_seconds(self):
        reset_circuit_breaker()
        old_reset = settings.circuit_breaker_reset_seconds
        settings.circuit_breaker_reset_seconds = 0.01
        try:
            for _ in range(settings.circuit_breaker_threshold):
                _circuit_breaker_record_failure()
            assert _circuit_breaker_allow() is False
            time.sleep(0.02)
            assert _circuit_breaker_allow() is True
        finally:
            settings.circuit_breaker_reset_seconds = old_reset


# ─── Batch Processing Limit ─────────────────────────────────────────────────

class TestBatchProcessingLimit:
    def test_config_has_batch_size_setting(self):
        assert hasattr(settings, "ai_email_batch_size")
        assert isinstance(settings.ai_email_batch_size, int)
        assert settings.ai_email_batch_size > 0

    def test_scheduler_imports_batch_limit(self):
        from app.services.scheduler_service import run_scheduled_sync
        import inspect
        source = inspect.getsource(run_scheduled_sync)
        assert ".limit(settings.ai_email_batch_size)" in source

    def test_sync_endpoint_imports_batch_limit(self):
        from app.routes.gmail import gmail_sync
        import inspect
        source = inspect.getsource(gmail_sync)
        assert ".limit(settings.ai_email_batch_size)" in source
