def test_analyze_email_success(client, auth_headers):
    payload = {
        "sender": "customer@example.com",
        "sender_name": "Customer",
        "subject": "Broken product - need refund",
        "email_body": "I received a damaged item and I want a full refund immediately.",
        "tone": "Apologetic",
    }
    response = client.post("/api/analyze-email", json=payload, headers=auth_headers)
    assert response.status_code == 200
    data = response.json()
    assert data["intent"] in ["Complaint", "Request"]
    assert data["urgency"] in ["High", "Medium", "Low"]
    assert "summary" in data
    assert "suggested_subject" in data
    assert "reply" in data


def test_analyze_email_missing_field(client, auth_headers):
    response = client.post("/api/analyze-email", json={"sender": "test@test.com"}, headers=auth_headers)
    assert response.status_code == 422


def test_analyze_email_unauthorized(client):
    payload = {
        "sender": "test@test.com",
        "subject": "Test",
        "email_body": "Test body",
        "tone": "Professional",
    }
    response = client.post("/api/analyze-email", json=payload)
    assert response.status_code == 401


def test_health_endpoint(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "groq_api_configured" in data
    assert "version" in data


def test_signup(client):
    response = client.post("/api/auth/signup", json={
        "full_name": "New User",
        "email": "newuser@example.com",
        "password": "password123",
        "confirm_password": "password123",
    })
    assert response.status_code == 201
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"
    assert data["user"]["email"] == "newuser@example.com"


def test_login(client):
    client.post("/api/auth/signup", json={
        "full_name": "Login User",
        "email": "login@example.com",
        "password": "password123",
        "confirm_password": "password123",
    })
    response = client.post("/api/auth/login", json={
        "email": "login@example.com",
        "password": "password123",
    })
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
