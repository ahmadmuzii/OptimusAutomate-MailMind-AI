"""Tests for architecture consolidation."""

import os
import sys

BACKEND_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)))


def test_no_duplicate_gmail_routes():
    """Verify Gmail route is registered only once."""
    from main import app
    gmail_routes = [r.path for r in app.routes if "/api/gmail" in str(r.path)]
    assert "/api/gmail/status" in str(gmail_routes)
    assert "/api/gmail/send" in str(gmail_routes)


def test_no_duplicate_groq_client():
    """Verify only one Groq client implementation exists."""
    with open(os.path.join(BACKEND_DIR, "app", "services", "groq_service.py")) as f:
        content = f.read()
    assert "class Groq" not in content  # Uses Groq() directly, not a wrapper class


def test_no_imports_from_legacy_modules():
    """Verify main.py does not import from legacy module structure."""
    with open(os.path.join(BACKEND_DIR, "main.py")) as f:
        main_content = f.read()
    assert "from modules." not in main_content
    assert "from routes." not in main_content
    assert "from services." not in main_content


def test_application_starts():
    """Verify the FastAPI app can be imported and starts successfully."""
    from main import app
    assert app.title == "MailMind AI"
    assert app.version == "2.0.0"


def test_canonical_structure_exists():
    """Verify the new canonical directory structure exists."""
    expected_dirs = [
        os.path.join(BACKEND_DIR, "app", "core"),
        os.path.join(BACKEND_DIR, "app", "database"),
        os.path.join(BACKEND_DIR, "app", "models"),
        os.path.join(BACKEND_DIR, "app", "schemas"),
        os.path.join(BACKEND_DIR, "app", "routes"),
        os.path.join(BACKEND_DIR, "app", "services"),
        os.path.join(BACKEND_DIR, "app", "repositories"),
        os.path.join(BACKEND_DIR, "app", "utils"),
    ]
    for d in expected_dirs:
        assert os.path.isdir(d), f"Expected directory {d} does not exist"
