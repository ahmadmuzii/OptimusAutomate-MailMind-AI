from datetime import datetime
from pydantic import BaseModel, Field


class SignupRequest(BaseModel):
    full_name: str = Field(..., min_length=1, max_length=255)
    email: str = Field(..., min_length=1, max_length=254)
    password: str = Field(..., min_length=8, max_length=128)
    confirm_password: str = Field(..., min_length=8, max_length=128)


class LoginRequest(BaseModel):
    email: str = Field(..., min_length=1, max_length=254)
    password: str = Field(..., min_length=1, max_length=128)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"


class UserOut(BaseModel):
    id: int
    full_name: str
    email: str
    profile_picture: str | None = None
    default_tone: str = "Professional"
    preferred_reply_length: str = "Medium"
    auto_analyze: bool = True
    notifications_enabled: bool = True

    class Config:
        from_attributes = True


class UserUpdate(BaseModel):
    full_name: str | None = None
    default_tone: str | None = None
    preferred_reply_length: str | None = None
    auto_analyze: bool | None = None
    notifications_enabled: bool | None = None


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=8, max_length=128)


class ForgotPasswordRequest(BaseModel):
    email: str


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(..., min_length=8, max_length=128)
    confirm_password: str = Field(..., min_length=8, max_length=128)


class MessageOut(BaseModel):
    message: str


class EmailAnalyzeRequest(BaseModel):
    sender: str = Field(..., min_length=1, max_length=254)
    sender_name: str | None = None
    subject: str = Field(..., min_length=1, max_length=500)
    email_body: str = Field(..., min_length=1, max_length=10000)
    tone: str = Field(default="Professional", max_length=50)


class EmailAnalyzeResponse(BaseModel):
    email_id: int
    intent: str
    urgency: str
    summary: str
    suggested_subject: str
    reply: str
    is_spam: bool = False
    spam_reason: str = ""


class EmailCreate(BaseModel):
    sender_email: str = Field(..., min_length=1, max_length=254)
    sender_name: str | None = None
    recipient: str | None = None
    subject: str = Field(..., min_length=1, max_length=500)
    body: str = Field(..., min_length=1, max_length=10000)


class EmailOut(BaseModel):
    id: int
    user_id: int
    gmail_message_id: str | None = None
    gmail_thread_id: str | None = None
    sender_name: str | None = None
    sender_email: str
    recipient: str | None = None
    subject: str
    body: str
    body_preview: str | None = None
    received_at: datetime | None = None
    intent: str | None = None
    urgency: str | None = None
    summary: str | None = None
    spam_reason: str | None = None
    is_spam: bool = False
    is_read: bool = False
    source: str = "manual"
    created_at: datetime | None = None

    class Config:
        from_attributes = True


class MailboxCounts(BaseModel):
    inbox: int = 0
    drafts: int = 0
    urgent: int = 0
    spam: int = 0


class DraftCreate(BaseModel):
    email_id: int | None = None
    recipient: str
    subject: str
    body: str
    tone: str = "Professional"


class DraftUpdate(BaseModel):
    recipient: str | None = None
    subject: str | None = None
    body: str | None = None
    tone: str | None = None
    status: str | None = None


class DraftOut(BaseModel):
    id: int
    user_id: int
    email_id: int | None = None
    gmail_draft_id: str | None = None
    recipient: str
    subject: str
    body: str
    tone: str = "Professional"
    status: str = "Local"
    created_at: datetime | None = None
    updated_at: datetime | None = None

    class Config:
        from_attributes = True


class ProfileOut(BaseModel):
    id: int
    full_name: str | None = None
    email: str | None = None
    profile_picture: str | None = None

    class Config:
        from_attributes = True


class ProfileUpdate(BaseModel):
    full_name: str | None = None
    email: str | None = None


class ReplyGenerationRequest(BaseModel):
    tone: str = "Professional"
    previous_reply: str | None = None


class ReplyGenerationResponse(BaseModel):
    reply: str
    tone: str
    source: str


class GmailStatusOut(BaseModel):
    is_connected: bool = False
    gmail_email: str | None = None
    last_sync_at: datetime | None = None
    imported_count: int = 0
