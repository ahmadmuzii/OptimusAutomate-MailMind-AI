import secrets
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models.user import User
from app.schemas.auth import (
    SignupRequest, LoginRequest, TokenResponse, UserOut,
    UserUpdate, ChangePasswordRequest, ForgotPasswordRequest,
    ResetPasswordRequest, MessageOut, ForgotPasswordResponse,
)
from app.core.security import hash_password, verify_password, create_access_token, get_current_user
from app.services.password_reset_service import create_reset_token, reset_password, build_reset_url
from app.services.email_delivery_service import send_password_reset_email
from app.core.config import settings

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/auth", tags=["Authentication"])


@router.post("/signup", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def signup(request: SignupRequest, db: Session = Depends(get_db)):
    if request.password != request.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    existing = db.query(User).filter(User.email == request.email).first()
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")

    user = User(
        full_name=request.full_name,
        email=request.email,
        password_hash=hash_password(request.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = create_access_token({"sub": str(user.id)})
    return TokenResponse(
        access_token=token,
        token_type="bearer",
        user=UserOut.model_validate(user),
    )


@router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == request.email, User.is_active == True).first()
    if not user or not verify_password(request.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token({"sub": str(user.id)})
    return TokenResponse(
        access_token=token,
        token_type="bearer",
        user=UserOut.model_validate(user),
    )


@router.get("/me", response_model=UserOut)
async def get_me(current_user: User = Depends(get_current_user)):
    return UserOut.model_validate(current_user)


@router.post("/logout", response_model=MessageOut)
async def logout(current_user: User = Depends(get_current_user)):
    return MessageOut(message="Logged out successfully")


@router.put("/profile", response_model=UserOut)
async def update_profile(
    update: UserUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if update.full_name is not None:
        current_user.full_name = update.full_name
    if update.default_tone is not None:
        current_user.default_tone = update.default_tone
    if update.preferred_reply_length is not None:
        current_user.preferred_reply_length = update.preferred_reply_length
    if update.auto_analyze is not None:
        current_user.auto_analyze = update.auto_analyze
    if update.notifications_enabled is not None:
        current_user.notifications_enabled = update.notifications_enabled
    if update.auto_gmail_sync is not None:
        current_user.auto_gmail_sync = update.auto_gmail_sync
    current_user.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(current_user)
    return UserOut.model_validate(current_user)


@router.post("/change-password", response_model=MessageOut)
async def change_password(
    request: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not verify_password(request.current_password, current_user.password_hash):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    current_user.password_hash = hash_password(request.new_password)
    current_user.updated_at = datetime.now(timezone.utc)
    db.commit()
    return MessageOut(message="Password changed successfully")


@router.post("/forgot-password", response_model=ForgotPasswordResponse)
async def forgot_password(
    request: ForgotPasswordRequest,
    db: Session = Depends(get_db),
    req: Request = None,
):
    user = db.query(User).filter(User.email == request.email).first()
    response = ForgotPasswordResponse(
        message="If an account exists for this email, a reset link has been sent."
    )

    if user:
        raw_token = create_reset_token(user, db, requested_ip=req.client.host if req else None)
        reset_url = build_reset_url(raw_token)

        if settings.app_env == "development" and settings.return_reset_token_in_development:
            response.development_reset_url = reset_url

        email_sent = send_password_reset_email(
            to_email=user.email,
            to_name=user.full_name,
            reset_url=reset_url,
            expiry_minutes=settings.password_reset_token_minutes,
        )
        if not email_sent:
            logger.warning("Password reset email delivery failed for %s (token still created)", user.email)

    return response


@router.post("/reset-password", response_model=MessageOut)
async def reset_password_endpoint(
    request: ResetPasswordRequest,
    db: Session = Depends(get_db),
):
    if request.new_password != request.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    if len(request.new_password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")

    reset_password(request.token, request.new_password, db)
    return MessageOut(message="Password reset successfully")
