import logging

from fastapi import APIRouter

from app.core.config import settings
from app.services.groq_service import is_available, get_model, get_groq_diagnostics
from app.schemas.gmail import AiHealthResponse

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Health"])


@router.get("/api/health")
async def health_check():
    is_configured = is_available()
    return {
        "status": "healthy",
        "groq_api_configured": is_configured,
        "version": settings.app_version,
        "note": "If groq_api_configured is false, the app will use rule-based fallbacks.",
    }


@router.get("/api/health/ai", response_model=AiHealthResponse)
async def ai_health():
    is_configured = is_available()
    return AiHealthResponse(
        configured=is_configured,
        groq_api_configured=is_configured,
        provider="groq",
        model=get_model() if is_configured else None,
        message=(
            "Groq API is configured"
            if is_configured
            else "GROQ_API_KEY is not configured"
        ),
    )


@router.get("/api/groq/diagnostics")
async def groq_diagnostics():
    """Return Groq service diagnostics. Does not expose the API key."""
    return get_groq_diagnostics()
