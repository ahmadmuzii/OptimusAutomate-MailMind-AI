import os
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.core.config import settings
from app.database.session import get_db
from app.models.user import User
from app.models.draft import Draft
from app.models.sync_log import GmailSyncLog
from app.schemas.gmail import GmailStatusOut, SyncLogOut, GmailSendRequest, GmailSendResponse
from app.core.security import get_current_user
from app.exceptions import GmailReauthRequired
from app.services.gmail_service import GmailService, oauth_states, FRONTEND_URL, send_draft_email

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Gmail"])


def _get_gmail_service(current_user: User, db: Session) -> GmailService:
    return GmailService(current_user.id, db)


@router.get("/api/gmail/status", response_model=GmailStatusOut)
def gmail_status(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    svc = _get_gmail_service(current_user, db)
    conn = svc.get_connection()
    if not conn:
        return GmailStatusOut(
            is_connected=False,
            status="disconnected",
            imported_count=0,
        )
    is_active = conn.status == "connected"
    return GmailStatusOut(
        is_connected=is_active,
        status=conn.status or ("connected" if conn.is_connected else "disconnected"),
        gmail_email=conn.gmail_email,
        last_sync_at=conn.last_sync_at,
        imported_count=svc.count_imported(),
        last_error_code=conn.last_error_code,
        last_error_message=conn.last_error_message,
    )


@router.get("/api/gmail/connect")
def gmail_connect(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    svc = _get_gmail_service(current_user, db)
    auth_url = svc.get_auth_url()
    return {"auth_url": auth_url}


@router.get("/api/gmail/callback")
def gmail_callback(
    code: str | None = Query(None),
    state: str | None = Query(None),
    error: str | None = Query(None),
):
    if error or not code:
        return RedirectResponse(
            f"{FRONTEND_URL}/integrations?gmail=error",
            status_code=303,
        )

    if not state or state not in oauth_states:
        return RedirectResponse(
            f"{FRONTEND_URL}/integrations?gmail=error",
            status_code=303,
        )

    user_id = oauth_states.pop(state, None)
    if user_id is None:
        return RedirectResponse(
            f"{FRONTEND_URL}/integrations?gmail=error",
            status_code=303,
        )

    db = next(get_db())
    try:
        svc = GmailService(user_id, db)
        svc.handle_callback(code)
        return RedirectResponse(
            f"{FRONTEND_URL}/integrations?gmail=connected",
            status_code=303,
        )
    except Exception as e:
        logger.error("Gmail OAuth callback failed for user %d: %s", user_id, e)
        return RedirectResponse(
            f"{FRONTEND_URL}/integrations?gmail=error",
            status_code=303,
        )
    finally:
        db.close()


@router.post("/api/gmail/sync")
def gmail_sync(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    svc = _get_gmail_service(current_user, db)

    sync_log = GmailSyncLog(
        user_id=current_user.id,
        status="Running",
        trigger_type="Manual",
    )
    db.add(sync_log)
    db.commit()

    try:
        result = svc.sync_emails(max_results=200)
        sync_log.status = "Success"
        sync_log.messages_fetched = result.get("total", 0)
        sync_log.messages_imported = result.get("synced", 0)
        sync_log.completed_at = datetime.now(timezone.utc)
        db.commit()

        from app.services.email_analysis_service import process_email
        if current_user.auto_analyze and result.get("synced", 0) > 0:
            from app.models.email import Email
            from sqlalchemy import or_
            new_emails = (
                db.query(Email)
                .filter(
                    Email.user_id == current_user.id,
                    Email.source == "gmail",
                    or_(Email.clean_body.isnot(None), Email.body.isnot(None)),
                    Email.intent.is_(None),
                )
                .limit(settings.ai_email_batch_size)
                .all()
            )
            for email in new_emails:
                try:
                    body_source = email.clean_body or email.body
                    if not body_source:
                        continue
                    analysis = process_email(
                        sender=email.sender_email,
                        subject=email.subject,
                        body=body_source,
                        tone=current_user.default_tone or "Professional",
                    )
                    email.intent = analysis["intent"]
                    email.urgency = analysis["urgency"]
                    email.summary = analysis.get("summary", "")
                    email.is_spam = analysis.get("is_spam", False)
                    email.category = analysis.get("category", None)
                except Exception as e:
                    logger.warning("Auto-analysis failed for email %d: %s", email.id, e)
            db.commit()

        return result
    except GmailReauthRequired:
        sync_log.status = "Failed"
        sync_log.error_message = "Reconnect Gmail to continue syncing."
        sync_log.completed_at = datetime.now(timezone.utc)
        db.commit()
        raise
    except Exception as e:
        sync_log.status = "Failed"
        sync_log.error_message = str(e)[:500]
        sync_log.completed_at = datetime.now(timezone.utc)
        db.commit()
        raise HTTPException(status_code=500, detail=str(e)[:500])


@router.post("/api/gmail/disconnect")
def gmail_disconnect(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    svc = _get_gmail_service(current_user, db)
    svc.disconnect()
    return {"message": "Gmail disconnected successfully"}


@router.post("/api/gmail/create-draft")
def gmail_create_draft(
    draft_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    draft = (
        db.query(Draft)
        .filter(Draft.id == draft_id, Draft.user_id == current_user.id)
        .first()
    )
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")

    svc = _get_gmail_service(current_user, db)
    gmail_draft_id = svc.create_draft(
        to=draft.recipient or "",
        subject=draft.subject or "",
        body=draft.body or "",
    )
    draft.gmail_draft_id = gmail_draft_id
    draft.status = "Gmail"
    db.commit()
    return {"gmail_draft_id": gmail_draft_id}


@router.post("/api/gmail/send", response_model=GmailSendResponse)
def gmail_send(
    request: GmailSendRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    draft = (
        db.query(Draft)
        .filter(Draft.id == request.draft_id, Draft.user_id == current_user.id)
        .first()
    )
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")

    if draft.status == "Sent":
        return GmailSendResponse(
            success=False,
            status="AlreadySent",
            error="This draft has already been sent.",
        )

    if not draft.recipient or not draft.subject or not draft.body:
        raise HTTPException(status_code=400, detail="Draft is missing recipient, subject, or body")

    svc = _get_gmail_service(current_user, db)
    conn = svc.get_connection()
    if not conn or not conn.is_connected:
        raise HTTPException(status_code=401, detail="Gmail not connected")

    if not svc.has_send_scope():
        return GmailSendResponse(
            success=False,
            status="MissingScope",
            error="Gmail 'send' scope is missing. Please disconnect and reconnect Gmail to grant the new permission.",
        )

    try:
        gmail_message_id = send_draft_email(current_user.id, draft, db)
        draft.gmail_message_id = gmail_message_id
        draft.status = "Sent"
        draft.sent_at = datetime.now(timezone.utc)
        draft.send_error = None
        db.commit()

        return GmailSendResponse(
            success=True,
            status="Sent",
            gmail_message_id=gmail_message_id,
        )
    except HTTPException:
        raise
    except Exception as e:
        draft.send_error = str(e)[:500]
        draft.status = "Failed"
        db.commit()
        logger.error("Failed to send email: %s", e)
        return GmailSendResponse(
            success=False,
            status="Failed",
            error=str(e),
        )


@router.get("/api/gmail/sync-history", response_model=list[SyncLogOut])
def gmail_sync_history(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return (
        db.query(GmailSyncLog)
        .filter(GmailSyncLog.user_id == current_user.id)
        .order_by(GmailSyncLog.started_at.desc())
        .limit(20)
        .all()
    )
