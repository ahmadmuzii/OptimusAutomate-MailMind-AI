import os
import uuid
import logging
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models.user import User
from app.schemas.auth import UserOut
from app.schemas.profile import ProfileUpdate
from app.core.security import get_current_user, hash_password, verify_password

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Profile"])

UPLOAD_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "uploads", "profile_pictures"
)
ALLOWED_TYPES = {"image/png", "image/jpg", "image/jpeg", "image/webp"}
MAX_SIZE = 5 * 1024 * 1024


@router.get("/api/profile", response_model=UserOut)
def get_profile(current_user: User = Depends(get_current_user)):
    return UserOut.model_validate(current_user)


@router.put("/api/profile", response_model=UserOut)
def update_profile(
    data: ProfileUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if data.full_name is not None:
        current_user.full_name = data.full_name
    if data.email is not None:
        existing = db.query(User).filter(User.email == data.email, User.id != current_user.id).first()
        if existing:
            raise HTTPException(status_code=409, detail="Email already in use")
        current_user.email = data.email
    db.commit()
    db.refresh(current_user)
    return UserOut.model_validate(current_user)


@router.post("/api/profile/picture", response_model=UserOut)
async def upload_picture(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(status_code=400, detail="Only PNG, JPG, JPEG, and WebP are allowed.")
    contents = await file.read()
    if len(contents) > MAX_SIZE:
        raise HTTPException(status_code=400, detail="File size must be under 5 MB.")
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    ext = os.path.splitext(file.filename)[1] if file.filename else ".jpg"
    safe_name = f"{uuid.uuid4()}{ext}"
    file_path = os.path.join(UPLOAD_DIR, safe_name)
    with open(file_path, "wb") as f:
        f.write(contents)
    if current_user.profile_picture:
        old_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))), current_user.profile_picture
        )
        if os.path.exists(old_path):
            try:
                os.remove(old_path)
            except OSError:
                pass
    current_user.profile_picture = f"uploads/profile_pictures/{safe_name}"
    db.commit()
    db.refresh(current_user)
    return UserOut.model_validate(current_user)


@router.delete("/api/profile/picture", response_model=UserOut)
def delete_picture(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.profile_picture:
        path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))), current_user.profile_picture
        )
        if os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass
        current_user.profile_picture = None
        db.commit()
        db.refresh(current_user)
    return UserOut.model_validate(current_user)


@router.put("/api/profile/password")
def change_password(
    data: dict,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    current_password = data.get("current_password", "")
    new_password = data.get("new_password", "")
    if not verify_password(current_password, current_user.password_hash):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    if len(new_password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    current_user.password_hash = hash_password(new_password)
    db.commit()
    return {"message": "Password changed successfully"}
