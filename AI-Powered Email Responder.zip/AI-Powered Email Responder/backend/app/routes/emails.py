import logging
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.database.session import get_db
from app.models.user import User
from app.models.email import Email
from app.models.draft import Draft
from app.schemas.email import (
    EmailOut, EmailCreate, MailboxCounts, EmailAnalyzeResponse,
    EmailAnalyzeRequest, ReplyGenerationRequest, ReplyGenerationResponse,
)
from app.core.security import get_current_user
from app.services.email_analysis_service import (
    process_email,
    generate_reply as generate_reply_module,
    generate_reply_rule,
    validate_generated_reply,
    check_no_reply_rules,
    check_no_reply_headers,
)
from app.services.email_cleaner import clean_email_content
from app.services.gmail_service import GmailService
from app.services.groq_service import get_model, get_last_model_used
from app.exceptions import GmailReauthRequired

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Emails"])


@router.get("/api/emails", response_model=list[EmailOut])
def list_emails(
    folder: str | None = Query(None),
    search: str | None = Query(None),
    intent: str | None = Query(None),
    urgency: str | None = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Email).filter(Email.user_id == current_user.id).order_by(desc(Email.received_at))
    if folder == "inbox":
        query = query.filter(Email.is_spam == False)
    elif folder == "urgent":
        query = query.filter(Email.urgency == "High")
    elif folder == "spam":
        query = query.filter(Email.is_spam == True)
    if search:
        like = f"%{search}%"
        query = query.filter(
            Email.subject.ilike(like)
            | Email.body_preview.ilike(like)
            | Email.sender_email.ilike(like)
            | Email.sender_name.ilike(like)
        )
    if intent:
        query = query.filter(Email.intent.ilike(f"%{intent}%"))
    if urgency:
        query = query.filter(Email.urgency.ilike(f"%{urgency}%"))
    offset = (page - 1) * limit
    return query.offset(offset).limit(limit).all()


@router.get("/api/emails/{email_id}", response_model=EmailOut)
def get_email(
    email_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")

    if not email.is_read:
        email.is_read = True

    if not email.body_loaded and email.gmail_message_id and email.source == "gmail":
        try:
            svc = GmailService(current_user.id, db)
            parts = svc.fetch_email_body_parts(email.gmail_message_id)
            raw_html = parts.get("raw_html") or None
            plain_text = parts.get("plain_text") or None
            clean_body = clean_email_content(
                html_body=raw_html,
                plain_body=plain_text,
            )

            email.raw_html = raw_html
            email.clean_body = clean_body
            email.body = clean_body
            email.body_preview = (clean_body or "")[:200] or None
            email.body_loaded = True

            db.commit()
            db.refresh(email)
        except GmailReauthRequired:
            db.rollback()
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "GMAIL_REAUTH_REQUIRED",
                    "message": "Reconnect Gmail to load this email.",
                },
            )
        except Exception:
            db.rollback()
            logger.exception("Failed to load Gmail body for email_id=%s", email.id)
            raise HTTPException(
                status_code=502,
                detail={
                    "code": "EMAIL_BODY_LOAD_FAILED",
                    "message": "The email body could not be loaded.",
                },
            )
    else:
        db.commit()

    return email


@router.post("/api/emails/manual", response_model=EmailOut, status_code=status.HTTP_201_CREATED)
def create_manual_email(
    data: EmailCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = Email(
        user_id=current_user.id,
        sender_email=data.sender_email,
        sender_name=data.sender_name,
        recipient=data.recipient,
        subject=data.subject,
        body=data.body,
        body_preview=data.body[:200] if data.body else None,
        source="manual",
    )
    db.add(email)
    db.commit()
    db.refresh(email)
    return email


@router.post("/api/emails/{email_id}/analyze", response_model=EmailAnalyzeResponse)
def analyze_email(
    email_id: int,
    tone: str = Query("Professional"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    body_source = email.clean_body or email.body
    if not body_source:
        raise HTTPException(status_code=400, detail="Email body not loaded yet. Open the email first to load its content.")
    try:
        result = process_email(
            sender=email.sender_email,
            subject=email.subject,
            body=body_source,
            tone=tone,
        )
    except Exception as e:
        logger.exception("Email processing failed")
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")
    email.intent = result["intent"]
    email.urgency = result["urgency"]
    email.summary = result["summary"]
    email.is_spam = result.get("is_spam", False)
    email.category = result.get("category", None)
    if result.get("is_spam"):
        email.spam_reason = result.get("spam_reason", "Detected as spam")
    db.commit()
    return EmailAnalyzeResponse(
        email_id=email.id,
        intent=result["intent"],
        urgency=result["urgency"],
        summary=result["summary"],
        suggested_subject=result["suggested_subject"],
        reply=result["reply"],
        is_spam=result.get("is_spam", False),
        spam_reason=result.get("spam_reason", ""),
        category=result.get("category", ""),
        requires_reply=result.get("requires_reply", True),
        analysis_provider=result.get("analysis_provider", ""),
        reply_provider=result.get("reply_provider", ""),
        reply_generated=result.get("reply_generated", True),
    )


@router.post("/api/emails/{email_id}/generate-reply", response_model=ReplyGenerationResponse)
def generate_reply(
    email_id: int,
    body: ReplyGenerationRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    body_source = email.clean_body or email.body
    if not body_source:
        raise HTTPException(status_code=400, detail="Email body not loaded yet. Open the email first to load its content.")

    no_reply = check_no_reply_rules(
        category=email.category or "",
        sender_type=email.sender_type if hasattr(email, "sender_type") else "",
        sender_email=email.sender_email,
        requires_reply=True,
    )
    if no_reply["block_reply"]:
        error_code = "NO_REPLY_NEEDED"
        if email.category == "job_alert":
            error_code = "NO_REPLY_RECOMMENDED"
            return ReplyGenerationResponse(
                reply="",
                tone=body.tone,
                source="none",
                reply_generated=False,
                error_code=error_code,
                message=no_reply["reason"],
                tone_applied=False,
                model=None,
                fallback_reason="automated_job_alert",
            )
        return ReplyGenerationResponse(
            reply="",
            tone=body.tone,
            source="none",
            reply_generated=False,
            error_code=error_code,
            message=no_reply["reason"],
            tone_applied=False,
            model=None,
            fallback_reason=None,
        )

    model_used = get_model()
    fallback_reason: str | None = None

    try:
        reply_text, source = generate_reply_module(
            sender_name=email.sender_name or "",
            sender_email=email.sender_email,
            subject=email.subject,
            email_body=body_source,
            intent=email.intent or "Other",
            urgency=email.urgency or "Low",
            tone=body.tone,
            previous_reply=body.previous_reply,
        )
    except Exception as e:
        logger.exception("Reply generation failed")
        reply_text, source = None, "error"

    if not reply_text:
        fallback_no_reply = check_no_reply_rules(
            category=email.category or "",
            sender_type="",
            sender_email=email.sender_email,
            requires_reply=True,
        )
        if not fallback_no_reply["block_reply"]:
            try:
                fallback_reply = generate_reply_rule(
                    sender_name=email.sender_name or "",
                    sender_email=email.sender_email,
                    subject=email.subject,
                    email_body=body_source,
                    tone=body.tone,
                    intent=email.intent or "Other",
                    urgency=email.urgency or "Low",
                )
                if fallback_reply:
                    validation = validate_generated_reply(fallback_reply)
                    if validation.valid:
                        logger.info(
                            "Generate reply: email_id=%s, requested_tone=%s, provider=local_rules",
                            email_id, body.tone,
                        )
                        return ReplyGenerationResponse(
                            reply=fallback_reply,
                            tone=body.tone,
                            source="local_rules",
                            reply_generated=True,
                            message="Groq was unavailable, so a basic template reply was generated.",
                            tone_applied=True,
                            model=None,
                            fallback_reason="groq_unavailable",
                        )
            except Exception as fallback_err:
                logger.warning("Rule-based fallback also failed: %s", fallback_err)

        error_code = source if source in ("groq_unavailable", "INVALID_GENERATED_REPLY", "EMPTY_REPLY", "CONTAINS_HTML", "CONTAINS_TRACKING_URL", "CONTAINS_PLACEHOLDER", "DUPLICATE_GREETING", "DUPLICATE_CLOSING", "TOO_LONG") else "REPLY_GENERATION_UNAVAILABLE"
        error_msg = "AI reply generation is temporarily unavailable." if source == "groq_unavailable" else "The generated reply did not pass quality checks."
        if source == "error":
            error_msg = "A valid reply could not be generated."
        return ReplyGenerationResponse(
            reply="",
            tone=body.tone,
            source=source,
            reply_generated=False,
            error_code=error_code,
            message=error_msg,
            tone_applied=False,
            model=None,
            fallback_reason=fallback_reason,
        )

    actual_model = get_last_model_used() or model_used
    logger.info(
        "Generate reply: email_id=%s, requested_tone=%s, provider=groq, model=%s",
        email_id, body.tone, actual_model,
    )
    return ReplyGenerationResponse(
        reply=reply_text,
        tone=body.tone,
        source=source,
        reply_generated=True,
        tone_applied=True,
        model=actual_model,
        fallback_reason=None,
    )


@router.put("/api/emails/{email_id}/read", response_model=EmailOut)
def toggle_read(
    email_id: int,
    is_read: bool = Query(True),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    email.is_read = is_read
    db.commit()
    return email


@router.put("/api/emails/{email_id}/spam", response_model=EmailOut)
def toggle_spam(
    email_id: int,
    is_spam: bool = Query(True),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    email.is_spam = is_spam
    db.commit()
    return email


@router.delete("/api/emails/{email_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_email(
    email_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    db.delete(email)
    db.commit()


@router.get("/api/mailbox/counts", response_model=MailboxCounts)
def get_mailbox_counts(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    base = db.query(Email).filter(Email.user_id == current_user.id)
    inbox = base.filter(Email.is_spam == False).count()
    spam = base.filter(Email.is_spam == True).count()
    urgent = base.filter(Email.urgency == "High").count()
    drafts = db.query(Draft).filter(Draft.user_id == current_user.id).count()

    inbox_total = 0
    inbox_unread = 0
    try:
        svc = GmailService(current_user.id, db)
        gmail_counts = svc._get_gmail_label_counts()
        inbox_total = gmail_counts.get("inbox_total", 0)
        inbox_unread = gmail_counts.get("inbox_unread", 0)
    except GmailReauthRequired:
        logger.debug("Gmail reauth required for mailbox counts")
    except Exception as e:
        logger.warning("Failed to fetch Gmail counts: %s", e)

    return MailboxCounts(
        inbox_total=inbox_total,
        inbox_unread=inbox_unread,
        imported_total=inbox + spam,
        inbox=inbox,
        drafts=drafts,
        urgent=urgent,
        spam=spam,
    )
