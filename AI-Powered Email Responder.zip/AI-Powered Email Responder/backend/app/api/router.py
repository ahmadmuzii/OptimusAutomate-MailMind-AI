from fastapi import APIRouter

from app.api.v1 import health as health_router
from app.api.v1 import email as email_router

api_router = APIRouter(prefix="/api")
api_router.include_router(health_router.router)
api_router.include_router(email_router.router)
