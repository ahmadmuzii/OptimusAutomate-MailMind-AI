import os

from fastapi import APIRouter

from app.config import settings
from app.core.groq_client import is_groq_available
from app.schemas.health import HealthResponse

router = APIRouter(tags=["Health"])


@router.get("/health", response_model=HealthResponse)
async def health_check():
    return HealthResponse(
        status="healthy",
        groq_api_configured=is_groq_available(),
        version=settings.app_version,
        note="If groq_api_configured is false, the app will use rule-based fallbacks.",
    )
