import logging

from fastapi import APIRouter, HTTPException, status

from app.schemas.email import EmailRequest, AnalysisResponse
from app.services.analysis_pipeline import run_analysis_pipeline

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Email Analysis"])


@router.post(
    "/analyze-email",
    response_model=AnalysisResponse,
    status_code=status.HTTP_200_OK,
    summary="Analyze an email and generate a smart reply",
    responses={
        422: {"description": "Validation error in request body."},
        500: {"description": "Internal server error during analysis."},
    },
)
async def analyze_email(request: EmailRequest) -> AnalysisResponse:
    try:
        tone = request.validate_tone()
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))

    try:
        result = run_analysis_pipeline(
            sender=request.sender,
            subject=request.subject,
            email_body=request.email_body,
            tone=tone,
        )
    except Exception as e:
        logger.exception("Analysis pipeline failed")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Analysis failed: {str(e)}",
        )

    return AnalysisResponse(
        intent=result.intent,
        urgency=result.urgency,
        summary=result.summary,
        suggested_subject=result.suggested_subject,
        reply=result.reply,
    )
