"""
Reprocess imported emails: re-clean, reclassify, replace corrupted
summaries, and remove invalid generated drafts.

Usage:
    python -m app.scripts.reprocess_emails --limit 100

Does not send any email.
"""

import argparse
import logging
import sys
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-8s | %(message)s")
logger = logging.getLogger(__name__)


def reprocess_emails(limit: int = 100) -> dict:
    from sqlalchemy.orm import Session
    from app.database.session import SessionLocal
    from app.models.email import Email
    from app.models.draft import Draft
    from app.services.email_cleaner import clean_email_content
    from app.services.email_analysis_service import process_email

    db = SessionLocal()
    try:
        emails = (
            db.query(Email)
            .filter(Email.body.isnot(None))
            .order_by(Email.received_at.desc())
            .limit(limit)
            .all()
        )
        logger.info("Found %d emails to reprocess", len(emails))

        stats = {"cleaned": 0, "reclassified": 0, "drafts_removed": 0, "errors": 0}

        for email in emails:
            try:
                if email.raw_html or email.body:
                    raw = email.raw_html or ""
                    plain = email.body if not email.raw_html else ""
                    cleaned = clean_email_content(
                        html_body=raw or None,
                        plain_body=plain or None,
                    )
                    if cleaned != email.clean_body:
                        email.clean_body = cleaned
                        email.body_preview = cleaned[:200] if cleaned else None
                        stats["cleaned"] += 1

                if cleaned:
                    result = process_email(
                        sender=email.sender_email,
                        subject=email.subject,
                        body=cleaned,
                        tone="Professional",
                    )
                    email.intent = result["intent"]
                    email.urgency = result["urgency"]
                    email.summary = result["summary"]
                    email.is_spam = result.get("is_spam", False)
                    email.category = result.get("category", None)
                    if result.get("is_spam"):
                        email.spam_reason = result.get("spam_reason", "Reclassified as spam")
                    stats["reclassified"] += 1

                invalid_drafts = (
                    db.query(Draft)
                    .filter(
                        Draft.email_id == email.id,
                        Draft.body.like("%[Please provide the requested details here]%"),
                    )
                    .all()
                )
                for d in invalid_drafts:
                    logger.info("Removing invalid draft %d for email %d", d.id, email.id)
                    db.delete(d)
                    stats["drafts_removed"] += 1

                email.updated_at = datetime.now(timezone.utc)
                db.commit()
            except Exception as e:
                stats["errors"] += 1
                logger.exception("Failed to reprocess email %d: %s", email.id, e)
                db.rollback()

        logger.info("Reprocessing complete: %s", stats)
        return stats
    finally:
        db.close()


def main():
    parser = argparse.ArgumentParser(description="Reprocess imported emails")
    parser.add_argument("--limit", type=int, default=100, help="Max emails to reprocess")
    args = parser.parse_args()
    reprocess_emails(limit=args.limit)


if __name__ == "__main__":
    main()
