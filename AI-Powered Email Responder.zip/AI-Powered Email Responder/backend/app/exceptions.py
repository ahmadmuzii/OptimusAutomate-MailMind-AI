from fastapi import Request, status
from fastapi.responses import JSONResponse


class AnalysisError(Exception):
    def __init__(self, detail: str, status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR):
        self.detail = detail
        self.status_code = status_code


class ValidationError(AnalysisError):
    def __init__(self, detail: str):
        super().__init__(detail=detail, status_code=status.HTTP_422_UNPROCESSABLE_ENTITY)


class GmailReauthRequired(Exception):
    def __init__(self, message: str = "Reconnect Gmail to continue syncing."):
        self.message = message
        super().__init__(self.message)


async def analysis_error_handler(request: Request, exc: AnalysisError) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "error": exc.__class__.__name__},
    )


async def gmail_reauth_error_handler(request: Request, exc: GmailReauthRequired) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_409_CONFLICT,
        content={
            "success": False,
            "error": {
                "code": "GMAIL_REAUTH_REQUIRED",
                "message": exc.message,
            },
        },
    )
