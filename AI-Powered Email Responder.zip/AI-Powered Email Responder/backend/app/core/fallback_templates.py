FALLBACK_TEMPLATES: dict[str, str] = {
    "Professional": (
        "Dear Customer,\n\n"
        "Thank you for reaching out to us regarding your concern. "
        "We have reviewed your email and take this matter seriously. "
        "Our team is currently looking into this and will provide you "
        "with a detailed response within 24 hours.\n\n"
        "We appreciate your patience.\n\n"
        "Best regards,\n"
        "Customer Support Team"
    ),
    "Friendly": (
        "Hi there!\n\n"
        "Thanks so much for getting in touch! We totally understand "
        "where you're coming from, and we want to help make things right. "
        "Our team is on it and we'll get back to you super soon!\n\n"
        "Hang tight — we've got you covered.\n\n"
        "Warmly,\n"
        "Customer Support Team"
    ),
    "Apologetic": (
        "Dear Customer,\n\n"
        "We sincerely apologize for the experience you've described. "
        "This is not the standard we hold ourselves to, and we deeply "
        "regret any inconvenience caused.\n\n"
        "We are urgently reviewing your case and will reach out to you "
        "with a resolution as soon as possible.\n\n"
        "Thank you for bringing this to our attention.\n\n"
        "With sincere apologies,\n"
        "Customer Support Team"
    ),
    "Short": (
        "Hi,\n\n"
        "Thanks for your email. We're looking into this and will get "
        "back to you shortly.\n\n"
        "Best,\n"
        "Support Team"
    ),
}


VALID_TONES = list(FALLBACK_TEMPLATES.keys())


def get_fallback_reply(tone: str, intent: str) -> str:
    template_tone = tone if tone in VALID_TONES else "Professional"
    if intent == "Complaint" and tone not in VALID_TONES:
        template_tone = "Apologetic"
    return FALLBACK_TEMPLATES[template_tone]
