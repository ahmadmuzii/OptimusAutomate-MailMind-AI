INTENT_KEYWORDS: dict[str, list[str]] = {
    "Complaint": [
        "refund", "damaged", "broken", "worst", "terrible", "unacceptable",
        "angry", "frustrated", "disappointed", "complain", "poor quality",
        "never again", "furious", "unhappy", "faulty", "defective",
    ],
    "Inquiry": [
        "question", "wondering", "curious", "how does", "what is",
        "can you tell", "information", "details", "pricing", "cost",
        "do you offer", "is it possible", "availability",
    ],
    "Support": [
        "help", "issue", "not working", "error", "bug", "fix",
        "trouble", "problem", "cannot", "unable to", "setup",
        "install", "configure", "troubleshoot",
    ],
    "Collaboration": [
        "partner", "collaborate", "joint", "together", "proposal",
        "partnership", "co-operation", "mutual", "synergy", "project",
        "team up", "work together",
    ],
    "Spam": [
        "click here", "free money", "winner", "congratulations",
        "act now", "limited time", "unsubscribe", "buy now",
        "make money fast", "no obligation", "100% free",
    ],
}

URGENCY_KEYWORDS: dict[str, list[str]] = {
    "High": [
        "urgent", "asap", "immediately", "right now", "emergency",
        "critical", "deadline today", "within hours", "legal",
        "lawsuit", "attorney", "cancel immediately", "chargeback",
        "consumer rights", "regulatory",
    ],
    "Medium": [
        "soon", "this week", "by friday", "quick response",
        "timely", "important", "priority", "need answer",
        "waiting", "follow up", "reminder",
    ],
    "Low": [
        "whenever", "no rush", "take your time", "just wondering",
        "when you get a chance", "at your convenience", "fyi",
        "for your information", "thought you should know",
    ],
}

VALID_INTENTS = list(INTENT_KEYWORDS.keys()) + ["Other"]
VALID_URGENCIES = list(URGENCY_KEYWORDS.keys())


def detect_intent_by_keywords(subject: str, email_body: str) -> str:
    combined = f"{subject} {email_body}".lower()
    for intent, keywords in INTENT_KEYWORDS.items():
        for kw in keywords:
            if kw in combined:
                return intent
    return "Other"


def detect_urgency_by_keywords(subject: str, email_body: str) -> str:
    combined = f"{subject} {email_body}".lower()
    for kw in URGENCY_KEYWORDS["High"]:
        if kw in combined:
            return "High"
    for kw in URGENCY_KEYWORDS["Medium"]:
        if kw in combined:
            return "Medium"
    return "Low"
