import os
from groq import Groq

_client: Groq | None = None


def get_groq_client() -> Groq | None:
    global _client
    if _client is None:
        api_key = os.getenv("GROQ_API_KEY", "")
        _client = Groq(api_key=api_key) if api_key and not api_key.startswith("gsk_your") else None
    return _client


def is_groq_available() -> bool:
    return get_groq_client() is not None
