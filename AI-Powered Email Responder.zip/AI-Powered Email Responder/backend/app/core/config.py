from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


BASE_DIR = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    app_name: str = "MailMind AI"
    app_version: str = "2.0.0"

    groq_api_key: str = ""
    groq_model: str = "openai/gpt-oss-120b"
    groq_fallback_model: str = "qwen/qwen3.6-27b"

    database_url: str = "sqlite:///./mailmind.db"
    jwt_secret_key: str = "mailmind-dev-secret-key-change-in-production"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60

    frontend_url: str = "http://localhost:3000"

    gmail_client_secret_file: str = ""
    gmail_redirect_uri: str = "http://localhost:8000/api/gmail/callback"

    enable_gmail_polling: bool = True
    gmail_poll_interval_minutes: int = 5

    password_reset_token_minutes: int = 30
    password_reset_email_provider: str = "smtp"

    mail_provider: str = "smtp"
    mail_from_name: str = "MailMind AI"
    mail_from_email: str = "no-reply@example.com"

    smtp_host: str = "smtp.gmail.com"
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_use_tls: bool = True

    app_env: str = "development"
    return_reset_token_in_development: bool = True

    groq_max_concurrent_requests: int = 1
    groq_min_request_interval_seconds: float = 2.0
    groq_max_retries: int = 2
    groq_max_email_chars: int = 12_000

    ai_email_batch_size: int = 5

    circuit_breaker_threshold: int = 3
    circuit_breaker_reset_seconds: int = 60

    cors_origins: list[str] = [
        "http://localhost:5173",
        "http://localhost:3000",
        "http://localhost:4173",
        "http://localhost:8000",
    ]

    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


settings = Settings()
