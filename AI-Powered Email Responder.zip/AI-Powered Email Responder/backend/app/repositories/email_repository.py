from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.models.email import Email


class EmailRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_by_id(self, email_id: int, user_id: int) -> Email | None:
        return (
            self.db.query(Email)
            .filter(Email.id == email_id, Email.user_id == user_id)
            .first()
        )

    def get_by_gmail_id(self, gmail_message_id: str, user_id: int) -> Email | None:
        return (
            self.db.query(Email)
            .filter(Email.gmail_message_id == gmail_message_id, Email.user_id == user_id)
            .first()
        )

    def list_by_user(
        self,
        user_id: int,
        folder: str | None = None,
        search: str | None = None,
        intent: str | None = None,
        urgency: str | None = None,
        page: int = 1,
        limit: int = 50,
    ) -> list[Email]:
        query = self.db.query(Email).filter(Email.user_id == user_id).order_by(desc(Email.received_at))
        if folder == "inbox":
            query = query.filter(Email.is_spam == False)
        elif folder == "urgent":
            query = query.filter(Email.urgency == "High")
        elif folder == "spam":
            query = query.filter(Email.is_spam == True)
        if search:
            like = f"%{search}%"
            query = query.filter(
                Email.subject.ilike(like) | Email.body.ilike(like) | Email.sender_email.ilike(like)
            )
        if intent:
            query = query.filter(Email.intent.ilike(f"%{intent}%"))
        if urgency:
            query = query.filter(Email.urgency.ilike(f"%{urgency}%"))
        offset = (page - 1) * limit
        return query.offset(offset).limit(limit).all()

    def create(self, email: Email) -> Email:
        self.db.add(email)
        self.db.commit()
        self.db.refresh(email)
        return email

    def delete(self, email: Email) -> None:
        self.db.delete(email)
        self.db.commit()

    def get_unanalyzed_gmail_emails(self, user_id: int) -> list[Email]:
        return (
            self.db.query(Email)
            .filter(
                Email.user_id == user_id,
                Email.source == "gmail",
                Email.intent.is_(None),
            )
            .all()
        )
