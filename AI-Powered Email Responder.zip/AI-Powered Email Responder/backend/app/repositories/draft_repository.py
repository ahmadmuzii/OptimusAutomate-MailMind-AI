from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.models.draft import Draft


class DraftRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_by_id(self, draft_id: int, user_id: int) -> Draft | None:
        return (
            self.db.query(Draft)
            .filter(Draft.id == draft_id, Draft.user_id == user_id)
            .first()
        )

    def list_by_user(self, user_id: int) -> list[Draft]:
        return (
            self.db.query(Draft)
            .filter(Draft.user_id == user_id)
            .order_by(desc(Draft.created_at))
            .all()
        )

    def create(self, draft: Draft) -> Draft:
        self.db.add(draft)
        self.db.commit()
        self.db.refresh(draft)
        return draft

    def update(self, draft: Draft) -> Draft:
        self.db.commit()
        self.db.refresh(draft)
        return draft

    def delete(self, draft: Draft) -> None:
        self.db.delete(draft)
        self.db.commit()

    def count_by_user(self, user_id: int) -> int:
        return self.db.query(Draft).filter(Draft.user_id == user_id).count()
