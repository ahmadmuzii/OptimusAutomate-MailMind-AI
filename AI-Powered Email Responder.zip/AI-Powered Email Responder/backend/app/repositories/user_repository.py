from sqlalchemy.orm import Session

from app.models.user import User


class UserRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_by_id(self, user_id: int) -> User | None:
        return self.db.query(User).filter(User.id == user_id, User.is_active == True).first()

    def get_by_email(self, email: str) -> User | None:
        return self.db.query(User).filter(User.email == email, User.is_active == True).first()

    def get_by_email_any(self, email: str) -> User | None:
        return self.db.query(User).filter(User.email == email).first()

    def create(self, user: User) -> User:
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user

    def email_exists(self, email: str) -> bool:
        return self.db.query(User).filter(User.email == email).first() is not None

    def get_all_with_gmail_sync_enabled(self) -> list[User]:
        return (
            self.db.query(User)
            .filter(User.is_active == True, User.auto_gmail_sync == True)
            .all()
        )
