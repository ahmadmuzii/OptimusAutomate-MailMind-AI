from fastapi import Header, HTTPException, status


async def verify_content_type(content_type: str = Header(...)):
    if "application/json" not in content_type:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail="Content-Type must be application/json",
        )
