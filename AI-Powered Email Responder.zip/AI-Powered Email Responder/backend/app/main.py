import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from app.config import settings
from app.logging_config import setup_logging
from app.api.router import api_router
from app.exceptions import AnalysisError, analysis_error_handler

setup_logging(settings.log_level)

STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.app_name,
        description="Email Intelligence Engine — Analyze emails and generate smart AI responses.",
        version=settings.app_version,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.add_exception_handler(AnalysisError, analysis_error_handler)

    app.include_router(api_router)

    _mount_static(app)

    return app


def _mount_static(app: FastAPI) -> None:
    assets_dir = os.path.join(STATIC_DIR, "assets")
    index_path = os.path.join(STATIC_DIR, "index.html")

    if os.path.exists(index_path):
        if os.path.exists(assets_dir):
            app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

        @app.get("/", include_in_schema=False)
        async def serve_frontend():
            return FileResponse(index_path, media_type="text/html")

        @app.exception_handler(404)
        async def spa_fallback(request, exc):
            return FileResponse(index_path, media_type="text/html")


app = create_app()
