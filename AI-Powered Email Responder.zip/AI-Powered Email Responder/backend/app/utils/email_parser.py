import base64
import logging

logger = logging.getLogger(__name__)


def extract_email_body(msg: dict) -> str:
    """Extract plain-text body from a Gmail API message object."""
    payload = msg.get("payload", {})
    parts = payload.get("parts", [])
    if not parts:
        data = payload.get("body", {}).get("data", "")
        if data:
            try:
                return base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
            except Exception:
                return "[Unable to decode email body]"
        return ""
    for part in parts:
        if part.get("mimeType") == "text/plain":
            data = part.get("body", {}).get("data", "")
            if data:
                try:
                    return base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
                except Exception:
                    pass
        if part.get("mimeType") == "text/html" and not any(
            p.get("mimeType") == "text/plain" for p in parts
        ):
            data = part.get("body", {}).get("data", "")
            if data:
                try:
                    return base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
                except Exception:
                    pass
    return ""


def parse_sender(sender: str) -> tuple[str | None, str]:
    """Parse a Gmail From header into (sender_name, sender_email)."""
    sender_name = None
    sender_email = sender
    if "<" in sender and ">" in sender:
        parts = sender.split("<")
        sender_name = parts[0].strip().strip('"')
        sender_email = parts[1].rstrip(">")
    return sender_name, sender_email


def build_mime_message(to: str, subject: str, body: str) -> bytes:
    """Build a MIME message for Gmail API sending."""
    from email.mime.text import MIMEText
    import base64

    mime_message = MIMEText(body, "plain", "utf-8")
    mime_message["To"] = to
    mime_message["Subject"] = subject
    mime_message["From"] = "me"
    return base64.urlsafe_b64encode(mime_message.as_bytes())
