import re

VALID_TONES = ["Professional", "Friendly", "Apologetic", "Short"]
VALID_SOURCES = ["groq", "fallback"]
VALID_DRAFT_STATUSES = ["Local", "Gmail", "Sent", "Deleted", "Failed"]
VALID_SYNC_TRIGGERS = ["Manual", "Scheduled"]
VALID_SYNC_STATUSES = ["Running", "Success", "Partial", "Failed"]

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")


def validate_tone(tone: str) -> str:
    normalized = tone.strip().title()
    if normalized in VALID_TONES:
        return normalized
    for vt in VALID_TONES:
        if vt.lower().startswith(normalized.lower()):
            return vt
    raise ValueError(f"Invalid tone '{tone}'. Must be one of: {', '.join(VALID_TONES)}")


def validate_email(email: str) -> bool:
    return bool(EMAIL_REGEX.match(email))


def validate_password(password: str) -> tuple[bool, str]:
    if len(password) < 8:
        return False, "Password must be at least 8 characters"
    if len(password) > 128:
        return False, "Password must be at most 128 characters"
    return True, ""
