"""
Safe migration script for MailMind AI.

Adds new fields and tables to the existing SQLite database without
dropping existing data.

Run: python -m app.database.migrations
"""
import os
import sys
import logging

from sqlalchemy import text

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))

from dotenv import load_dotenv
load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-8s | %(message)s")
logger = logging.getLogger(__name__)


def run_migrations():
    """Apply all necessary schema changes to the existing database."""
    from sqlalchemy import create_engine, inspect, text
    from app.core.config import settings

    engine = create_engine(settings.database_url, connect_args={"check_same_thread": False})
    inspector = inspect(engine)
    conn = engine.connect()

    try:
        _add_column_if_not_exists(conn, inspector, "gmail_connections", "status", "VARCHAR(50)", "'disconnected'")
        _add_column_if_not_exists(conn, inspector, "gmail_connections", "last_error_code", "VARCHAR(100)", "NULL")
        _add_column_if_not_exists(conn, inspector, "gmail_connections", "last_error_message", "TEXT", "NULL")

        _add_column_if_not_exists(conn, inspector, "users", "preferred_reply_length", "VARCHAR(50)", "Medium")
        _add_column_if_not_exists(conn, inspector, "users", "auto_analyze", "BOOLEAN", "1")
        _add_column_if_not_exists(conn, inspector, "users", "notifications_enabled", "BOOLEAN", "1")
        _add_column_if_not_exists(conn, inspector, "users", "auto_gmail_sync", "BOOLEAN", "1")

        _add_column_if_not_exists(conn, inspector, "drafts", "gmail_message_id", "VARCHAR(255)", "NULL")
        _add_column_if_not_exists(conn, inspector, "drafts", "send_error", "TEXT", "NULL")
        _add_column_if_not_exists(conn, inspector, "drafts", "sent_at", "DATETIME", "NULL")

        # Email schema changes: add body_loaded, make body nullable, body_preview→TEXT
        _migrate_emails_table(conn, inspector)

        _add_column_if_not_exists(conn, inspector, "emails", "raw_html", "TEXT", "NULL")
        _add_column_if_not_exists(conn, inspector, "emails", "clean_body", "TEXT", "NULL")
        _add_column_if_not_exists(conn, inspector, "emails", "category", "VARCHAR(50)", "NULL")

        _create_table_if_not_exists(conn, inspector, "password_reset_tokens", """
            CREATE TABLE password_reset_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id),
                token_hash VARCHAR(255) NOT NULL,
                expires_at DATETIME NOT NULL,
                used_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                requested_ip VARCHAR(45),
                is_revoked BOOLEAN DEFAULT 0
            )
        """)

        _create_table_if_not_exists(conn, inspector, "gmail_sync_logs", """
            CREATE TABLE gmail_sync_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id),
                started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                completed_at DATETIME,
                status VARCHAR(50) DEFAULT 'Running',
                messages_fetched INTEGER DEFAULT 0,
                messages_imported INTEGER DEFAULT 0,
                error_message TEXT,
                trigger_type VARCHAR(50) DEFAULT 'Manual',
                is_completed BOOLEAN DEFAULT 0
            )
        """)

        _create_index_if_not_exists(conn, inspector, "password_reset_tokens", "ix_password_reset_tokens_token_hash", "token_hash")
        _create_index_if_not_exists(conn, inspector, "password_reset_tokens", "ix_password_reset_tokens_user_id", "user_id")
        _create_index_if_not_exists(conn, inspector, "gmail_sync_logs", "ix_gmail_sync_logs_user_id", "user_id")

        logger.info("Migrations completed successfully")
    finally:
        conn.close()
        engine.dispose()


def _add_column_if_not_exists(conn, inspector, table, column, coltype, default):
    if column not in [c["name"] for c in inspector.get_columns(table)]:
        logger.info("Adding column %s.%s", table, column)
        default_clause = f"DEFAULT {default}" if default != "NULL" else "NULL"
        conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {column} {coltype} {default_clause}"))
        conn.commit()


def _create_table_if_not_exists(conn, inspector, table, create_sql):
    if table not in inspector.get_table_names():
        logger.info("Creating table %s", table)
        conn.execute(text(create_sql))
        conn.commit()


def _migrate_emails_table(conn, inspector):
    """Migrate emails table: add body_loaded, make body nullable, body_preview→TEXT."""
    columns = [c["name"] for c in inspector.get_columns("emails")]
    needs_recreate = False

    if "body_loaded" not in columns:
        logger.info("Adding column emails.body_loaded")
        conn.execute(text("ALTER TABLE emails ADD COLUMN body_loaded BOOLEAN NOT NULL DEFAULT 0"))
        conn.commit()

    if "body_loaded" in columns or needs_recreate:
        conn.execute(text("UPDATE emails SET body_loaded = 1 WHERE body IS NOT NULL AND body != ''"))
        conn.commit()

    body_col = next((c for c in inspector.get_columns("emails") if c["name"] == "body"), None)
    preview_col = next((c for c in inspector.get_columns("emails") if c["name"] == "body_preview"), None)
    if body_col and body_col.get("nullable", True) is False:
        needs_recreate = True
    if preview_col and preview_col.get("type") and "VARCHAR" in str(preview_col["type"]):
        needs_recreate = True

    if not needs_recreate:
        return

    logger.info("Recreating emails table to change body nullable and body_preview type")
    conn.execute(text("""
        CREATE TABLE emails_new (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id),
            gmail_message_id VARCHAR(255) UNIQUE,
            gmail_thread_id VARCHAR(255),
            sender_name VARCHAR(255),
            sender_email VARCHAR(254) NOT NULL,
            recipient VARCHAR(254),
            subject VARCHAR(500) NOT NULL,
            body TEXT,
            body_loaded BOOLEAN NOT NULL DEFAULT 0,
            body_preview TEXT,
            received_at DATETIME,
            intent VARCHAR(50),
            urgency VARCHAR(20),
            summary TEXT,
            spam_reason VARCHAR(255),
            is_spam BOOLEAN DEFAULT 0,
            is_read BOOLEAN DEFAULT 0,
            source VARCHAR(50) DEFAULT 'manual',
            created_at DATETIME,
            updated_at DATETIME
        )
    """))
    conn.execute(text("""
        INSERT INTO emails_new (
            id, user_id, gmail_message_id, gmail_thread_id,
            sender_name, sender_email, recipient, subject,
            body, body_loaded, body_preview,
            received_at, intent, urgency, summary,
            spam_reason, is_spam, is_read, source,
            created_at, updated_at
        )
        SELECT
            id, user_id, gmail_message_id, gmail_thread_id,
            sender_name, sender_email, recipient, subject,
            body,
            CASE WHEN body IS NOT NULL AND body != '' THEN 1 ELSE 0 END,
            body_preview,
            received_at, intent, urgency, summary,
            spam_reason, is_spam, is_read, source,
            created_at, updated_at
        FROM emails
    """))
    conn.execute(text("DROP TABLE emails"))
    conn.execute(text("ALTER TABLE emails_new RENAME TO emails"))
    conn.execute(text("CREATE INDEX IF NOT EXISTS ix_emails_user_id ON emails(user_id)"))
    conn.execute(text("CREATE INDEX IF NOT EXISTS ix_emails_gmail_message_id ON emails(gmail_message_id)"))
    conn.commit()


def _create_index_if_not_exists(conn, inspector, table, index_name, column):
    existing = [i["name"] for i in inspector.get_indexes(table)]
    if index_name not in existing:
        logger.info("Creating index %s on %s(%s)", index_name, table, column)
        conn.execute(text(f"CREATE INDEX IF NOT EXISTS {index_name} ON {table}({column})"))
        conn.commit()


if __name__ == "__main__":
    logger.info("Starting database migrations...")
    run_migrations()
    logger.info("Done. Backup is recommended before running in production.")
