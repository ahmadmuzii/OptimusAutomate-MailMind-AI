import logging

from app.core.groq_client import get_groq_client, is_groq_available
from app.core.keyword_maps import detect_urgency_by_keywords, VALID_URGENCIES

logger = logging.getLogger(__name__)

_URGENCY_PROMPT_TEMPLATE = """You are an email urgency analyzer. Determine how urgently this email needs a response.

Valid levels (choose EXACTLY one):
- High: Needs response within hours. Involves legal issues, chargebacks, angry customers, emergencies, or time-sensitive deadlines.
- Medium: Needs response within 1-2 days. Important but not critical. Follow-ups, reminders, or moderate complaints.
- Low: Can wait 3+ days. General inquiries, FYIs, non-time-sensitive requests, or casual messages.

Additional context - detected intent: {intent}

Email Subject: {subject}
Email Body: {body}

Respond with ONLY the urgency level. No explanation."""


def analyze_urgency(subject: str, email_body: str, intent: str) -> str:
    if not is_groq_available():
        return detect_urgency_by_keywords(subject, email_body)

    client = get_groq_client()
    prompt = _URGENCY_PROMPT_TEMPLATE.format(subject=subject, body=email_body, intent=intent)

    try:
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            max_tokens=20,
        )
        detected = response.choices[0].message.content.strip()

        if detected in VALID_URGENCIES:
            return detected
        for valid in VALID_URGENCIES:
            if valid.lower() == detected.lower():
                return valid

        logger.warning("LLM returned invalid urgency '%s', falling back to keywords", detected)
    except Exception as e:
        logger.error("Groq urgency analysis failed: %s", e)

    return detect_urgency_by_keywords(subject, email_body)
