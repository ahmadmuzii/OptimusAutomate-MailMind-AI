import logging
from datetime import datetime, timezone
from contextlib import asynccontextmanager

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from fastapi import FastAPI
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.core.config import settings
from app.database.session import SessionLocal
from app.models.user import User
from app.models.gmail_connection import GmailConnection
from app.models.sync_log import GmailSyncLog
from app.models.email import Email
from app.exceptions import GmailReauthRequired
from app.services.gmail_service import GmailService
from app.services.email_analysis_service import process_email

logger = logging.getLogger(__name__)

_scheduler: BackgroundScheduler | None = None
_sync_locks: dict[int, bool] = {}


def run_scheduled_sync() -> None:
    if not settings.enable_gmail_polling:
        return

    logger.info("Starting scheduled Gmail sync for all connected users")
    db = SessionLocal()
    try:
        connections = (
            db.query(GmailConnection)
            .filter(GmailConnection.is_connected == True)
            .all()
        )

        for conn in connections:
            user = db.query(User).filter(User.id == conn.user_id).first()
            if not user or not user.auto_gmail_sync:
                continue

            user_id = conn.user_id
            if _sync_locks.get(user_id, False):
                logger.info("Sync already in progress for user %d, skipping", user_id)
                continue

            _sync_locks[user_id] = True
            sync_log = GmailSyncLog(
                user_id=user_id,
                status="Running",
                trigger_type="Scheduled",
            )
            db.add(sync_log)
            db.commit()

            try:
                svc = GmailService(user_id, db)
                result = svc.sync_incremental()

                messages_fetched = result.get("total", 0)
                messages_imported = result.get("synced", 0)

                if user.auto_analyze:
                    from sqlalchemy import or_
                    new_emails = (
                        db.query(Email)
                        .filter(
                            Email.user_id == user_id,
                            Email.source == "gmail",
                            or_(Email.clean_body.isnot(None), Email.body.isnot(None)),
                            Email.intent.is_(None),
                        )
                        .limit(settings.ai_email_batch_size)
                        .all()
                    )
                    for email in new_emails:
                        body_source = email.clean_body or email.body
                        if not body_source:
                            continue
                        try:
                            analysis = process_email(
                                sender=email.sender_email,
                                subject=email.subject,
                                body=body_source,
                                tone=user.default_tone or "Professional",
                            )
                            email.intent = analysis["intent"]
                            email.urgency = analysis["urgency"]
                            email.summary = analysis.get("summary", "")
                            email.is_spam = analysis.get("is_spam", False)
                            email.category = analysis.get("category", None)
                        except Exception as e:
                            logger.warning("Auto-analysis failed for email %d: %s", email.id, e)
                    db.commit()

                sync_log.status = "Success"
                sync_log.messages_fetched = messages_fetched
                sync_log.messages_imported = messages_imported
                sync_log.completed_at = datetime.now(timezone.utc)
                db.commit()

                logger.info("Scheduled sync completed for user %d: %d new messages", user_id, messages_imported)
            except GmailReauthRequired as e:
                sync_log.status = "Failed"
                sync_log.error_message = str(e)[:500]
                sync_log.completed_at = datetime.now(timezone.utc)
                db.commit()
                logger.warning(
                    "Scheduled sync skipped for user %d — Gmail reauth required. "
                    "Will retry after user reconnects.",
                    user_id,
                )
            except Exception as e:
                sync_log.status = "Failed"
                sync_log.error_message = str(e)[:500]
                sync_log.completed_at = datetime.now(timezone.utc)
                db.commit()
                logger.warning("Scheduled sync failed for user %d: %s", user_id, e)
            finally:
                _sync_locks[user_id] = False
    except Exception as e:
        logger.error("Scheduled sync error: %s", e)
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _scheduler
    if settings.enable_gmail_polling:
        _scheduler = BackgroundScheduler()
        _scheduler.add_job(
            run_scheduled_sync,
            trigger=IntervalTrigger(minutes=settings.gmail_poll_interval_minutes),
            id="gmail_sync",
            name="Gmail scheduled sync",
            replace_existing=True,
        )
        _scheduler.start()
        logger.info(
            "Gmail polling scheduler started (interval=%d minutes)",
            settings.gmail_poll_interval_minutes,
        )
    yield
    if _scheduler:
        _scheduler.shutdown(wait=False)
        logger.info("Gmail polling scheduler stopped")
