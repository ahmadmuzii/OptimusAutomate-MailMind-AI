import logging

from app.core.groq_client import get_groq_client, is_groq_available
from app.core.fallback_templates import get_fallback_reply, VALID_TONES

logger = logging.getLogger(__name__)

_TONE_INSTRUCTIONS = {
    "Professional": (
        "Write in a formal, business-like tone. Use proper salutations, "
        "clear language, and a structured format. Avoid slang or casual expressions."
    ),
    "Friendly": (
        "Write in a warm, approachable tone. Be conversational yet respectful. "
        "Use light language, show empathy, and make the customer feel valued."
    ),
    "Apologetic": (
        "Write with genuine empathy and regret. Acknowledge the issue directly, "
        "apologize sincerely without being overly dramatic, and assure action."
    ),
    "Short": (
        "Write a very brief reply — 2-3 sentences maximum. Get straight to the point. "
        "Acknowledge the issue and state next steps. No fluff."
    ),
}

_URGENCY_NOTES = {
    "High": "This is urgent — mention that the team is prioritizing this and will respond very quickly.",
    "Medium": "This is moderately important — mention a response within 24 hours.",
    "Low": "This is not time-sensitive — a standard response timeline is fine.",
}

_REPLY_PROMPT_TEMPLATE = """You are a skilled customer support email writer for MailMind AI. Write a reply to the following email.

CONTEXT:
- Sender: {sender}
- Detected Intent: {intent}
- Urgency Level: {urgency}
- Internal Summary: {summary}

TONE INSTRUCTIONS:
{tone_guide}

URGENCY NOTE:
{urgency_note}

ORIGINAL EMAIL:
Subject: {subject}
Body: {body}

RULES:
- Do NOT invent specific details like order numbers, dates, or product names unless mentioned in the email.
- Do NOT promise specific outcomes (like "we will refund you") unless the email clearly warrants it — instead say you're reviewing the case.
- Sign off as "Customer Support Team".
- Output ONLY the reply email text. No explanations, no labels, no markdown formatting.

Write the reply now:"""


def generate_reply(sender: str, subject: str, email_body: str, intent: str, urgency: str, tone: str, summary: str) -> str:
    if not is_groq_available():
        return get_fallback_reply(tone, intent)

    client = get_groq_client()
    tone_guide = _TONE_INSTRUCTIONS.get(tone, _TONE_INSTRUCTIONS["Professional"])
    urgency_note = _URGENCY_NOTES.get(urgency, _URGENCY_NOTES["Medium"])

    prompt = _REPLY_PROMPT_TEMPLATE.format(
        sender=sender,
        subject=subject,
        body=email_body,
        intent=intent,
        urgency=urgency,
        tone_guide=tone_guide,
        urgency_note=urgency_note,
        summary=summary,
    )

    try:
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=500,
        )
        reply = response.choices[0].message.content.strip()
        if len(reply) >= 20:
            return reply

        logger.warning("LLM returned suspiciously short reply (%d chars), falling back", len(reply))
    except Exception as e:
        logger.error("Groq reply generation failed: %s", e)

    return get_fallback_reply(tone, intent)
