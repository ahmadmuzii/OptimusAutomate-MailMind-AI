import os
import json
import logging
import base64
import secrets
from datetime import datetime, timezone
from email.mime.text import MIMEText
from typing import Optional

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.core.config import settings
from app.exceptions import GmailReauthRequired
from app.models.gmail_connection import GmailConnection
from app.models.email import Email
from app.models.draft import Draft

logger = logging.getLogger(__name__)

SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.compose",
    "https://www.googleapis.com/auth/gmail.send",
]

REDIRECT_URI = settings.gmail_redirect_uri
FRONTEND_URL = settings.frontend_url


def _get_google_credentials():
    from google.oauth2.credentials import Credentials
    return Credentials


def _get_google_request():
    from google.auth.transport.requests import Request
    return Request


def _get_google_build():
    from googleapiclient.discovery import build
    return build


def _get_google_flow():
    from google_auth_oauthlib.flow import Flow
    return Flow


def _find_client_secret() -> str:
    creds_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "credentials")
    env_path = settings.gmail_client_secret_file or os.path.join(creds_dir, "client_secret.json")
    if os.path.exists(env_path):
        return env_path
    if os.path.isdir(creds_dir):
        for f in os.listdir(creds_dir):
            if f.endswith(".json"):
                return os.path.join(creds_dir, f)
    return env_path


oauth_states: dict = {}


class GmailService:
    def __init__(self, user_id: int, db: Session):
        self.user_id = user_id
        self.db = db
        self._secret_file = _find_client_secret()

    def get_connection(self) -> Optional[GmailConnection]:
        return (
            self.db.query(GmailConnection)
            .filter(GmailConnection.user_id == self.user_id)
            .first()
        )

    def _get_client_id(self) -> str:
        try:
            with open(self._secret_file) as f:
                data = json.load(f)
            return (
                data.get("installed", {}).get("client_id", "")
                or data.get("web", {}).get("client_id", "")
            )
        except (FileNotFoundError, json.JSONDecodeError):
            return ""

    def _get_client_secret(self) -> str:
        try:
            with open(self._secret_file) as f:
                data = json.load(f)
            return (
                data.get("installed", {}).get("client_secret", "")
                or data.get("web", {}).get("client_secret", "")
            )
        except (FileNotFoundError, json.JSONDecodeError):
            return ""

    def _get_credentials(self) -> Optional[object]:
        from google.auth.exceptions import RefreshError
        Credentials = _get_google_credentials()
        GoogleRequest = _get_google_request()
        conn = self.get_connection()
        if not conn or not conn.is_connected:
            return None
        creds = Credentials(
            token=conn.access_token,
            refresh_token=conn.refresh_token,
            token_uri="https://oauth2.googleapis.com/token",
            client_id=self._get_client_id(),
            client_secret=self._get_client_secret(),
            scopes=conn.scopes.split(",") if conn.scopes else SCOPES,
            expiry=conn.token_expiry,
        )
        if creds.expired and creds.refresh_token:
            try:
                creds.refresh(GoogleRequest())
                conn.access_token = creds.token
                conn.token_expiry = creds.expiry
                conn.status = "connected"
                conn.last_error_code = None
                conn.last_error_message = None
                self.db.commit()
            except RefreshError as e:
                logger.warning("Gmail token refresh failed (RefreshError): %s", e)
                conn.is_connected = False
                conn.status = "reauth_required"
                conn.last_error_code = "GMAIL_REAUTH_REQUIRED"
                conn.last_error_message = (
                    "The Gmail authorization has expired or was revoked. "
                    "Reconnect Gmail to continue syncing."
                )
                self.db.commit()
                return None
            except Exception as e:
                logger.warning("Token refresh failed: %s", e)
                return None
        elif creds.expired and not creds.refresh_token:
            conn.is_connected = False
            conn.status = "reauth_required"
            conn.last_error_code = "GMAIL_REAUTH_REQUIRED"
            conn.last_error_message = (
                "No refresh token available. Reconnect Gmail to continue syncing."
            )
            self.db.commit()
        return creds

    def is_configured(self) -> bool:
        return os.path.exists(self._secret_file)

    def get_auth_url(self) -> str:
        if not self.is_configured():
            raise HTTPException(
                status_code=400,
                detail="Gmail not configured: client_secret.json not found",
            )
        state = secrets.token_urlsafe(32)
        oauth_states[state] = self.user_id
        Flow = _get_google_flow()
        flow = Flow.from_client_secrets_file(
            self._secret_file,
            scopes=SCOPES,
            redirect_uri=REDIRECT_URI,
            autogenerate_code_verifier=False,
        )
        auth_url, _ = flow.authorization_url(
            access_type="offline",
            include_granted_scopes="true",
            prompt="consent",
            state=state,
        )
        return auth_url

    def handle_callback(self, code: str) -> dict:
        Flow = _get_google_flow()
        flow = Flow.from_client_secrets_file(
            self._secret_file,
            scopes=SCOPES,
            redirect_uri=REDIRECT_URI,
            autogenerate_code_verifier=False,
        )
        flow.fetch_token(code=code)
        creds = flow.credentials
        gmail_email = self._get_gmail_email(creds)
        conn = self.get_connection()
        if conn:
            conn.access_token = creds.token
            if creds.refresh_token:
                conn.refresh_token = creds.refresh_token
            conn.token_expiry = creds.expiry
            conn.gmail_email = gmail_email
            conn.scopes = ",".join(creds.scopes or SCOPES)
            conn.is_connected = True
            conn.status = "connected"
            conn.last_error_code = None
            conn.last_error_message = None
        else:
            conn = GmailConnection(
                user_id=self.user_id,
                gmail_email=gmail_email,
                access_token=creds.token,
                refresh_token=creds.refresh_token or "",
                token_expiry=creds.expiry,
                scopes=",".join(creds.scopes or SCOPES),
                is_connected=True,
                status="connected",
            )
            self.db.add(conn)
        self.db.commit()
        return {"status": "connected", "email": gmail_email}

    def _get_gmail_email(self, creds: object) -> str:
        build = _get_google_build()
        try:
            service = build("gmail", "v1", credentials=creds)
            profile = service.users().getProfile(userId="me").execute()
            return profile.get("emailAddress", "unknown@unknown.com")
        except Exception as e:
            logger.warning("Failed to get Gmail profile: %s", e)
            return "unknown@unknown.com"

    def _get_gmail_service(self):
        build = _get_google_build()
        conn = self.get_connection()
        if not conn:
            raise GmailReauthRequired("Gmail is not connected. Connect Gmail to continue.")
        if conn.status == "reauth_required":
            raise GmailReauthRequired(
                conn.last_error_message
                or "Reconnect Gmail to continue syncing."
            )
        if not conn.is_connected:
            raise GmailReauthRequired("Gmail is not connected. Connect Gmail to continue.")
        creds = self._get_credentials()
        if not creds:
            raise GmailReauthRequired("Reconnect Gmail to continue syncing.")
        return build("gmail", "v1", credentials=creds)

    def _extract_body_parts(self, msg: dict) -> dict:
        """Extract both raw HTML and plain text from a message recursively."""
        result = {"raw_html": "", "plain_text": ""}

        def _walk(part: dict) -> None:
            mime = part.get("mimeType", "")
            data = part.get("body", {}).get("data", "")
            if not data:
                for sub in part.get("parts", []):
                    _walk(sub)
                return
            try:
                decoded = base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
            except Exception:
                return
            if mime == "text/plain":
                result["plain_text"] = decoded
            elif mime == "text/html":
                if not result["raw_html"]:
                    result["raw_html"] = decoded

        payload = msg.get("payload", {})
        _walk(payload)

        return result

    def _extract_body(self, msg: dict) -> str:
        parts = self._extract_body_parts(msg)
        return parts.get("plain_text") or parts.get("raw_html") or ""

    def fetch_email_body_parts(self, gmail_message_id: str) -> dict:
        """Fetch full email body from Gmail API, return both raw HTML and plain text."""
        service = self._get_gmail_service()
        full = service.users().messages().get(
            userId="me", id=gmail_message_id, format="full"
        ).execute()
        return self._extract_body_parts(full)

    def _get_gmail_label_counts(self) -> dict:
        """Fetch inbox total/unread counts from Gmail labels."""
        try:
            service = self._get_gmail_service()
            labels = service.users().labels().get(userId="me", id="INBOX").execute()
            return {
                "inbox_total": labels.get("messagesTotal", 0),
                "inbox_unread": labels.get("messagesUnread", 0),
            }
        except Exception as e:
            logger.warning("Failed to fetch Gmail label counts: %s", e)
            return {"inbox_total": 0, "inbox_unread": 0}

    def fetch_email_body(self, gmail_message_id: str) -> str:
        """Fetch full email body from Gmail API for a single message."""
        service = self._get_gmail_service()
        full = service.users().messages().get(
            userId="me", id=gmail_message_id, format="full"
        ).execute()
        return self._extract_body(full)

    def _import_message_metadata(self, service, msg_id: str) -> bool:
        """Import one message metadata-only. Returns True if new, False if skipped."""
        try:
            existing = (
                self.db.query(Email)
                .filter(Email.gmail_message_id == msg_id)
                .first()
            )
            if existing:
                return False

            meta = (
                service.users()
                .messages()
                .get(
                    userId="me",
                    id=msg_id,
                    format="metadata",
                    metadataHeaders=["Subject", "From", "To", "Date"],
                )
                .execute()
            )
            headers = {h["name"]: h["value"] for h in meta.get("payload", {}).get("headers", [])}
            subject = headers.get("Subject", "(No Subject)")
            sender = headers.get("From", "unknown@unknown.com")
            sender_name = None
            sender_email = sender
            if "<" in sender and ">" in sender:
                parts = sender.split("<")
                sender_name = parts[0].strip().strip('"')
                sender_email = parts[1].rstrip(">")
            snippet = meta.get("snippet", "")
            internal_date = int(meta.get("internalDate", "0"))
            received_at = (
                datetime.fromtimestamp(internal_date / 1000, tz=timezone.utc)
                if internal_date
                else datetime.now(timezone.utc)
            )
            email = Email(
                user_id=self.user_id,
                gmail_message_id=msg_id,
                gmail_thread_id=meta.get("threadId"),
                sender_name=sender_name,
                sender_email=sender_email,
                recipient=headers.get("To"),
                subject=subject,
                body=None,
                body_loaded=False,
                body_preview=snippet[:500] if snippet else None,
                received_at=received_at,
                is_read="UNREAD" not in meta.get("labelIds", []),
                source="gmail",
            )
            self.db.add(email)
            return True
        except Exception as e:
            logger.warning("Failed to sync message %s: %s", msg_id, e)
            return False

    def sync_emails(self, max_results: int = 200) -> dict:
        """Metadata-only sync of inbox messages. Stores snippet, not full body."""
        service = self._get_gmail_service()

        results = (
            service.users()
            .messages()
            .list(userId="me", labelIds=["INBOX"], maxResults=max_results)
            .execute()
        )
        messages = results.get("messages", [])
        synced = 0
        for msg in messages:
            if self._import_message_metadata(service, msg["id"]):
                synced += 1

        conn = self.get_connection()
        if conn:
            conn.last_sync_at = datetime.now(timezone.utc)
            history_id = results.get("historyId") or results.get("nextPageToken")
            if history_id:
                conn.last_history_id = str(history_id)
        self.db.commit()
        return {"status": "success", "synced": synced, "total": len(messages)}

    def sync_incremental(self) -> dict:
        """Incremental sync using stored historyId — fetches only changes."""
        conn = self.get_connection()
        if not conn or not conn.last_history_id:
            return self.sync_emails(max_results=200)

        try:
            service = self._get_gmail_service()
            history = (
                service.users()
                .history()
                .list(userId="me", startHistoryId=conn.last_history_id)
                .execute()
            )
        except Exception as e:
            err_str = str(e)
            if "historyId" in err_str and "not found" in err_str.lower():
                logger.warning("historyId expired, falling back to full metadata sync")
                return self.sync_emails(max_results=200)
            raise

        history_records = history.get("history", [])
        added = 0

        for record in history_records:
            for msg_added in record.get("messagesAdded", []):
                msg = msg_added.get("message", {})
                msg_id = msg.get("id")
                if msg_id and self._import_message_metadata(service, msg_id):
                    added += 1

        conn.last_sync_at = datetime.now(timezone.utc)
        if history.get("historyId"):
            conn.last_history_id = str(history["historyId"])
        self.db.commit()
        return {"status": "success", "synced": added, "total": len(history_records)}

    def create_draft(self, to: str, subject: str, body: str) -> str:
        service = self._get_gmail_service()
        message = (
            f"To: {to}\r\n"
            f"Subject: {subject}\r\n"
            f"Content-Type: text/plain; charset=UTF-8\r\n\r\n"
            f"{body}"
        )
        encoded = base64.urlsafe_b64encode(message.encode("utf-8")).decode("utf-8")
        draft = (
            service.users()
            .drafts()
            .create(userId="me", body={"message": {"raw": encoded}})
            .execute()
        )
        return draft.get("id", "")

    def send_email(self, to: str, subject: str, body: str) -> str:
        service = self._get_gmail_service()
        mime_message = MIMEText(body, "plain", "utf-8")
        mime_message["To"] = to
        mime_message["Subject"] = subject
        mime_message["From"] = "me"

        raw = base64.urlsafe_b64encode(mime_message.as_bytes()).decode("utf-8")
        sent = (
            service.users()
            .messages()
            .send(userId="me", body={"raw": raw})
            .execute()
        )
        return sent.get("id", "")

    def has_send_scope(self) -> bool:
        conn = self.get_connection()
        if not conn or not conn.scopes:
            return False
        return "gmail.send" in conn.scopes

    def disconnect(self):
        conn = self.get_connection()
        if conn:
            conn.is_connected = False
            conn.status = "disconnected"
            conn.access_token = ""
            conn.refresh_token = ""
            conn.token_expiry = None
            conn.gmail_email = ""
            conn.last_error_code = None
            conn.last_error_message = None
            self.db.commit()

    def count_imported(self) -> int:
        return (
            self.db.query(Email)
            .filter(Email.user_id == self.user_id, Email.source == "gmail")
            .count()
        )


def push_draft_to_gmail(user_id: int, draft: Draft, db: Session) -> str:
    svc = GmailService(user_id, db)
    return svc.create_draft(draft.recipient, draft.subject, draft.body)


def send_draft_email(user_id: int, draft: Draft, db: Session) -> str:
    svc = GmailService(user_id, db)
    if not svc.has_send_scope():
        raise HTTPException(
            status_code=400,
            detail="Gmail 'send' scope is missing. Please disconnect and reconnect Gmail to grant the new permission.",
        )
    return svc.send_email(draft.recipient, draft.subject, draft.body)
