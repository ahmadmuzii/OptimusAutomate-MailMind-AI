import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from app.core.config import settings

logger = logging.getLogger(__name__)


def send_password_reset_email(
    to_email: str,
    to_name: str,
    reset_url: str,
    expiry_minutes: int,
) -> bool:
    subject = "Reset your MailMind AI password"
    body_text = (
        f"Hello {to_name or 'there'},\n\n"
        f"We received a request to reset your MailMind AI password.\n\n"
        f"Click the link below to reset it:\n{reset_url}\n\n"
        f"This link will expire in {expiry_minutes} minutes.\n\n"
        f"If you did not request this, please ignore this email.\n\n"
        f"Best regards,\nMailMind AI Team"
    )
    body_html = (
        f"<p>Hello {to_name or 'there'},</p>"
        f"<p>We received a request to reset your MailMind AI password.</p>"
        f'<p><a href="{reset_url}">Click here to reset your password</a></p>'
        f"<p>This link will expire in {expiry_minutes} minutes.</p>"
        f"<p>If you did not request this, please ignore this email.</p>"
        f"<p>Best regards,<br>MailMind AI Team</p>"
    )

    if settings.mail_provider == "smtp":
        return _send_via_smtp(to_email, subject, body_text, body_html)
    elif settings.mail_provider == "gmail":
        logger.warning("Gmail mail provider not yet implemented, falling back to SMTP")
        return _send_via_smtp(to_email, subject, body_text, body_html)
    else:
        logger.warning("Unknown mail provider '%s', falling back to SMTP", settings.mail_provider)
        return _send_via_smtp(to_email, subject, body_text, body_html)


def _send_via_smtp(to_email: str, subject: str, body_text: str, body_html: str) -> bool:
    if not settings.smtp_username or not settings.smtp_password:
        logger.warning("SMTP not configured. Would send email to %s with subject '%s'", to_email, subject)
        return False

    msg = MIMEMultipart("alternative")
    msg["From"] = f"{settings.mail_from_name} <{settings.mail_from_email}>"
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body_text, "plain", "utf-8"))
    msg.attach(MIMEText(body_html, "html", "utf-8"))

    try:
        if settings.smtp_use_tls:
            server = smtplib.SMTP(settings.smtp_host, settings.smtp_port)
            server.starttls()
        else:
            server = smtplib.SMTP(settings.smtp_host, settings.smtp_port)

        server.login(settings.smtp_username, settings.smtp_password)
        server.sendmail(settings.mail_from_email, to_email, msg.as_string())
        server.quit()
        logger.info("Password reset email sent to %s", to_email)
        return True
    except Exception as e:
        logger.error("Failed to send password reset email: %s", e)
        return False
