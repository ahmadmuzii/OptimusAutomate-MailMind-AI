import json
import logging

from app.core.groq_client import get_groq_client, is_groq_available

logger = logging.getLogger(__name__)

_SUMMARY_PROMPT_TEMPLATE = """You are an email summarization assistant. Generate TWO things for this email:

1. A concise internal summary (1-2 sentences) for the support agent. Be factual and specific.
2. A professional reply subject line that acknowledges the topic.

Additional context - detected intent: {intent}

Email Subject: {subject}
Email Body: {body}

You MUST respond in valid JSON format with exactly these two keys:
{{
    "summary": "The concise summary here.",
    "suggested_subject": "The reply subject line here."
}}

Respond with ONLY the JSON. No extra text, no markdown, no code blocks."""


def _rule_based_fallback(subject: str, email_body: str) -> dict:
    body_clean = email_body.strip()
    summary = body_clean[:147] + "..." if len(body_clean) > 150 else (body_clean or "No content provided.")

    subject_clean = subject.strip()
    if subject_clean.lower().startswith("re:"):
        suggested_subject = subject_clean
    elif subject_clean:
        suggested_subject = f"Re: {subject_clean}"
    else:
        suggested_subject = "Re: Your Email"

    return {"summary": summary, "suggested_subject": suggested_subject}


def summarize_email(subject: str, email_body: str, intent: str) -> dict:
    if not is_groq_available():
        return _rule_based_fallback(subject, email_body)

    client = get_groq_client()
    prompt = _SUMMARY_PROMPT_TEMPLATE.format(subject=subject, body=email_body, intent=intent)

    try:
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=200,
            response_format={"type": "json_object"},
        )
        raw = response.choices[0].message.content.strip()
        result = json.loads(raw)
        summary = result.get("summary", "").strip()
        suggested_subject = result.get("suggested_subject", "").strip()

        if summary and suggested_subject:
            return {"summary": summary, "suggested_subject": suggested_subject}

        logger.warning("LLM returned empty summary fields, falling back")
    except Exception as e:
        logger.error("Groq summarization failed: %s", e)

    return _rule_based_fallback(subject, email_body)
