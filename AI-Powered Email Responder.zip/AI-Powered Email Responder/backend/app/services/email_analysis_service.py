import json
import logging
import re
from typing import Optional

from app.core.config import settings
from app.services.groq_service import (
    create_chat_completion,
    create_structured_analysis,
    is_available,
    GroqPayloadTooLarge,
    GroqServiceUnavailable,
    GroqRateLimited,
)
from app.services.email_cleaner import clean_email_content

logger = logging.getLogger(__name__)

ALLOWED_INTENTS = ["Inquiry", "Complaint", "Support", "Collaboration", "Feedback", "Request", "Project_Discussion", "Meeting_Request", "Question", "Follow_Up", "Confirmation", "Information", "Spam", "Other"]
ALLOWED_URGENCIES = ["Low", "Medium", "High"]
ALLOWED_CATEGORIES = [
    "personal", "support", "inquiry", "transactional", "security",
    "job_alert", "newsletter", "promotion", "spam", "social_notification",
    "receipt", "other",
]
ALLOWED_SENDER_TYPES = ["human", "business", "automated", "bulk_marketing", "no_reply", "unknown"]

NO_REPLY_CATEGORIES = {"promotion", "newsletter", "spam", "social_notification", "job_alert", "receipt"}
NO_REPLY_SENDER_TYPES = {"bulk_marketing", "no_reply", "automated"}
NO_REPLY_SENDER_PREFIXES = ("no-reply", "noreply", "no_reply")
NO_REPLY_HEADER_SIGNALS = ["list-unsubscribe", "auto-submitted", "precedence"]

INTENT_KEYWORDS: dict[str, list[str]] = {
    "inquiry": ["how much", "how long", "what is", "tell me about", "information", "availability", "price", "cost",
                "policy", "guidance", "i would like to know", "can you provide", "interested in"],
    "complaint": ["refund", "damaged", "poor service", "unhappy", "dissatisfied", "bad experience", "not working",
                  "broken", "defective", "terrible", "worst", "angry", "frustrated", "disappointed"],
    "support": ["help", "issue", "problem", "error", "trouble", "not working", "can't log in", "password reset",
                "account access", "technical", "bug", "assistance", "how to fix"],
    "collaboration": ["partnership", "sponsorship", "collaborate", "joint", "business opportunity", "meet",
                      "partners", "cooperation", "proposal", "interested in working"],
    "feedback": ["feedback", "suggestion", "review", "opinion", "recommend", "thoughts on", "my experience",
                 "concerned about", "concern about", "concern", "worried about", "i think", "in my opinion",
                 "my experience", "i feel", "i believe"],
    "request": ["request", "approval", "permission", "leave", "please approve", "i need", "can i have",
                "authorization", "apply for", "i would like to request"],
    "question": ["question", "i wonder", "i was wondering", "can you explain", "could you clarify",
                 "what does", "how does", "why is", "i don't understand", "clarify"],
    "follow_up": ["follow up", "following up", "checking in", "any update", "status update",
                   "progress", "next steps", "as discussed", "per our conversation"],
    "confirmation": ["confirm", "confirmation", "i confirm", "please confirm", "can you confirm",
                     "i received", "got it", "acknowledge", "understood"],
    "information": ["let me know", "keep me posted", "keep me informed", "update me",
                    "send me", "share", "details", "more information"],
    "project_discussion": ["project", "automation", "system", "workflow", "platform", "tool",
                           "integration", "development", "rollout", "implementation", "deployment",
                           "milestone", "timeline", "deadline", "deliverable"],
}

HIGH_KEYWORDS = ["urgent", "immediately", "asap", "deadline today", "critical", "emergency",
                 "security breach", "account compromised", "system outage", "legal deadline"]
MEDIUM_KEYWORDS = ["complaint", "refund", "support", "reschedule", "action required",
                   "leave request", "by next week", "within a few days"]

SPAM_TRIGGERS = [
    "buy now", "click here", "free money", "congratulations you won", "limited offer",
    "act now", "risk free", "no obligation", "exclusive deal", "earn money fast",
    "work from home", "make money", "double your", "increase your", "cash bonus",
]

TONE_CLOSINGS = {
    "Professional": "Best regards",
    "Friendly": "Best",
    "Apologetic": "Sincerely",
    "Short": "Best",
}

TONE_RENDERERS = {
    "Professional": {
        "Inquiry": "Thank you for your message. I have received your inquiry and will review it shortly.",
        "Complaint": "Thank you for bringing this to my attention. I sincerely apologize for the inconvenience. I take your concerns seriously and will look into this matter promptly.",
        "Support": "Thank you for contacting me regarding {subject}. I will review your case and get back to you shortly.",
        "Collaboration": "Thank you for your proposal regarding {subject}. I appreciate your interest and will review the details. I will get back to you soon.",
        "Feedback": "Thank you for your valuable feedback regarding {subject}. I appreciate you taking the time to share your thoughts.",
        "Request": "Thank you for your request regarding {subject}. I have received it and will process it accordingly.",
        "Spam": "",
        "Other": "Thank you for your message regarding {subject}. I will review it and respond accordingly.",
    },
    "Friendly": {
        "Inquiry": "Thanks for reaching out! I\u2019ll take a look and get back to you shortly.",
        "Complaint": "Thanks for letting me know. I\u2019m sorry for the trouble and I\u2019ll look into this right away.",
        "Support": "Thanks for reaching out! I\u2019ll review what\u2019s going on and get back to you as soon as I can.",
        "Collaboration": "Thanks for your proposal! I appreciate the opportunity and will review everything carefully.",
        "Feedback": "Thanks so much for sharing your thoughts \u2014 I really appreciate your feedback!",
        "Request": "Thanks for your request! I\u2019ve received it and will take care of it.",
        "Spam": "",
        "Other": "Thanks for your message! I\u2019ll review it and get back to you.",
    },
    "Apologetic": {
        "Inquiry": "Thank you for reaching out. I understand your concern and will review the details carefully.",
        "Complaint": "I sincerely apologize for the inconvenience. Thank you for your patience while I look into this matter.",
        "Support": "I\u2019m sorry for the difficulty you\u2019ve experienced. Thank you for your patience while I review your case.",
        "Collaboration": "Thank you for your proposal. I appreciate your interest and will review it carefully.",
        "Feedback": "Thank you for your thoughtful feedback. I value your perspective and will take it into account.",
        "Request": "Thank you for your request. I appreciate your patience and will process it as soon as possible.",
        "Spam": "",
        "Other": "Thank you for your message. I appreciate your understanding and will respond as soon as I can.",
    },
    "Short": {
        "Inquiry": "Thanks for your message. I\u2019ll review it shortly.",
        "Complaint": "Thanks for reaching out. I\u2019ll look into this right away.",
        "Support": "Thanks for contacting me. I\u2019ll review this and get back to you soon.",
        "Collaboration": "Thanks for reaching out. I\u2019ll review your proposal shortly.",
        "Feedback": "Thanks for your feedback. I appreciate it.",
        "Request": "Thanks for your request. I\u2019ll take care of it.",
        "Spam": "",
        "Other": "Thanks for your message. I\u2019ll review it shortly.",
    },
}

REPLY_SYSTEM_PROMPT = """Write a reply to the provided email using the requested tone.

Use only information supported by the email and its analysis.

Do not invent promises, deadlines, actions, facts, attachments, or responsibility.

Never include raw HTML, tracking URLs, placeholder text, or the entire original email.

Use one greeting and one closing.

Make the requested tone noticeably different from the other supported tones.

Return only the email reply."""

TONE_GUIDES = {
    "Professional": (
        "Write formally and clearly.\n"
        "Use complete sentences.\n"
        "Avoid slang, contractions, excessive enthusiasm, and unnecessary apologies.\n"
        "Keep the reply concise and businesslike."
    ),
    "Friendly": (
        "Write warmly and conversationally.\n"
        "Use natural contractions where appropriate.\n"
        "Sound approachable without becoming casual or unprofessional.\n"
        "Use a warmer greeting and closing than Professional."
    ),
    "Apologetic": (
        "Acknowledge the sender's concern.\n"
        "Apologize only when the email context shows a real delay, mistake, inconvenience, or responsibility.\n"
        "Do not invent a mistake or accept blame when none exists.\n"
        "When no apology is contextually justified, use an understanding and considerate tone instead."
    ),
    "Short": (
        "Use no more than two short body sentences.\n"
        "Remove background explanation and repetition.\n"
        "Answer only the main point.\n"
        "Keep the complete reply under 60 words."
    ),
}

COMBINED_ANALYSIS_PROMPT = """You are an email classifier. Analyze the email below and return valid JSON.

Return exactly this structure:
{{
  "category": "personal | support | inquiry | transactional | security | job_alert | newsletter | promotion | spam | social_notification | receipt | other",
  "intent": "Inquiry | Complaint | Support | Collaboration | Feedback | Request | Project_Discussion | Meeting_Request | Question | Follow_Up | Confirmation | Information | Spam | Other",
  "urgency": "Low | Medium | High",
  "spam": false,
  "sender_type": "human | business | automated | bulk_marketing | no_reply | unknown",
  "requires_reply": true,
  "summary": "1-3 sentence summary of the email content.",
  "reason": "Brief explanation for the classification."
}}

Rules:
- category: classify the email type accurately.
- intent: classify the primary communication purpose.
- urgency: Low, Medium, or High based on time-sensitivity.
- spam: true only if deceptive, promotional-bulk, malicious, or unsolicited.
- sender_type: determine if this is a human, business, automated system, bulk marketing, no-reply, or unknown.
- requires_reply: false for promotions, newsletters, spam, social notifications, automated messages, and no-reply senders.
- summary: concise 1-3 sentence summary of the key points.
- reason: brief justification for category, spam, and requires_reply decisions.

Email:
Subject: {subject}
Body:
{body}"""


def clean_email_body(body: str) -> str:
    """Strip HTML tags, quotes, signatures, MIME boundaries from email body."""
    if not body:
        return ""
    text = body
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'(?m)^[>|].*$', '', text)
    text = re.sub(r'(?m)^--+\s*$.*', '', text, flags=re.DOTALL)
    text = re.sub(r'(?m)^Content-(Type|Transfer-Encoding|Disposition):.*$', '', text, flags=re.IGNORECASE)
    text = re.sub(r'(?m)^--[a-zA-Z0-9]+[_=].*$', '', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = text.strip()
    return text[:settings.groq_max_email_chars]


# ─── No-Reply Deterministic Rules ───────────────────────────────────────────

def check_no_reply_headers(
    subject: str = "",
    sender_email: str = "",
    headers: Optional[dict] = None,
) -> dict:
    sender_lower = sender_email.lower()
    for prefix in NO_REPLY_SENDER_PREFIXES:
        if sender_lower.startswith(prefix) or f"@{prefix}" in sender_lower:
            return {
                "block_reply": True,
                "reason": f"Sender address ({sender_email}) appears to be a no-reply address.",
            }

    if headers:
        headers_lower = {k.lower(): v.lower() for k, v in headers.items()}
        if "list-unsubscribe" in headers_lower:
            return {
                "block_reply": True,
                "reason": "Email contains a List-Unsubscribe header (bulk mail).",
            }
        if "auto-submitted" in headers_lower:
            return {
                "block_reply": True,
                "reason": "Email is auto-submitted (automated message).",
            }
        if headers_lower.get("precedence", "") == "bulk":
            return {
                "block_reply": True,
                "reason": "Email has Precedence: bulk (automated message).",
            }

    return {"block_reply": False, "reason": ""}


def check_no_reply_rules(
    category: str = "",
    sender_type: str = "",
    sender_email: str = "",
    requires_reply: bool = True,
    headers: Optional[dict] = None,
) -> dict:
    if category in NO_REPLY_CATEGORIES:
        reason = f"Category '{category}' does not require a reply."
        if category == "job_alert":
            reason = "This is an automated job-alert email and does not require a reply."
        if category == "receipt":
            reason = "This is a receipt and does not require a reply."
        return {
            "block_reply": True,
            "reason": reason,
            "requires_reply": False,
        }
    if sender_type in NO_REPLY_SENDER_TYPES:
        return {
            "block_reply": True,
            "reason": f"Sender type '{sender_type}' does not require a reply.",
            "requires_reply": False,
        }
    header_check = check_no_reply_headers(sender_email=sender_email, headers=headers)
    if header_check["block_reply"]:
        return {
            "block_reply": True,
            "reason": header_check["reason"],
            "requires_reply": False,
        }
    if not requires_reply:
        return {
            "block_reply": True,
            "reason": "Analysis indicates no reply is needed.",
            "requires_reply": False,
        }
    return {"block_reply": False, "reason": "", "requires_reply": True}


# ─── Reply Validation ───────────────────────────────────────────────────────

class ValidationResult:
    def __init__(self, valid: bool, error_code: str = "", message: str = ""):
        self.valid = valid
        self.error_code = error_code
        self.message = message

    def to_dict(self) -> dict:
        return {
            "valid": self.valid,
            "error_code": self.error_code,
            "message": self.message,
        }


PLACEHOLDER_PATTERNS = [
    re.compile(r'\[.*?\]'),
    re.compile(r'lorem ipsum', re.IGNORECASE),
    re.compile(r'\bbest regards\b.*\bbest regards\b', re.DOTALL | re.IGNORECASE),
    re.compile(r'(?:^|\n)best regards\s*$.*?(?:^|\n)best regards', re.DOTALL | re.IGNORECASE),
]
GREETING_PATTERNS = [
    re.compile(r'^(?:hello|hi|dear|hey)\s', re.IGNORECASE),
    re.compile(r'\n(?:hello|hi|dear|hey)\s', re.IGNORECASE),
]
CLOSING_PATTERNS = [
    re.compile(r'\bbest regards\b', re.IGNORECASE),
    re.compile(r'\bsincerely\b', re.IGNORECASE),
    re.compile(r'\bthanks?\b', re.IGNORECASE),
    re.compile(r'\bcheers\b', re.IGNORECASE),
]
HTML_TAG = re.compile(r'<[^>]+>')
TRACKING_URL_RE = re.compile(r'https?://[^\s]*(?:mmstat|doubleclick|googleadservices)\.[^\s)\">]+', re.IGNORECASE)
EMPTY_OR_WS = re.compile(r'^\s*$')


def validate_generated_reply(reply: str) -> ValidationResult:
    if EMPTY_OR_WS.match(reply):
        return ValidationResult(False, "EMPTY_REPLY", "Generated reply is empty.")

    if HTML_TAG.search(reply):
        return ValidationResult(False, "CONTAINS_HTML", "Generated reply contains raw HTML tags.")

    if TRACKING_URL_RE.search(reply):
        return ValidationResult(False, "CONTAINS_TRACKING_URL", "Generated reply contains tracking URLs.")

    for pattern in PLACEHOLDER_PATTERNS:
        if pattern.search(reply):
            return ValidationResult(False, "CONTAINS_PLACEHOLDER", "Generated reply contains placeholder text.")

    greeting_count = len(GREETING_PATTERNS[0].findall(reply)) + len(GREETING_PATTERNS[1].findall(reply))
    if greeting_count > 2:
        return ValidationResult(False, "DUPLICATE_GREETING", "Generated reply has too many greetings.")

    closing_count = sum(len(p.findall(reply)) for p in CLOSING_PATTERNS)
    if closing_count > 2:
        return ValidationResult(False, "DUPLICATE_CLOSING", "Generated reply has too many closings.")

    lines = reply.strip().split("\n")
    if len(lines) > 50:
        return ValidationResult(False, "TOO_LONG", "Generated reply is excessively long.")

    return ValidationResult(True)


# ─── Combined Analysis ──────────────────────────────────────────────────────

def analyze_email_llm(subject: str, body: str) -> Optional[dict]:
    if not is_available():
        return None
    cleaned = clean_email_body(body)
    if len(cleaned) > settings.groq_max_email_chars * 0.9:
        cleaned = cleaned[:settings.groq_max_email_chars]
    user_prompt = COMBINED_ANALYSIS_PROMPT.format(subject=subject, body=cleaned)
    try:
        data = create_structured_analysis(
            system_prompt="You are an email classifier. Return only valid JSON.",
            user_prompt=user_prompt,
        )
        return _parse_analysis_result(data)
    except GroqPayloadTooLarge:
        shorter = cleaned[:6000]
        try:
            data = create_structured_analysis(
                system_prompt="You are an email classifier. Return only valid JSON.",
                user_prompt=COMBINED_ANALYSIS_PROMPT.format(subject=subject, body=shorter),
            )
            return _parse_analysis_result(data)
        except Exception as e2:
            logger.warning("Combined analysis failed even after shortening: %s", e2)
            return None
    except Exception as e:
        logger.warning("Combined email analysis failed: %s", e)
        return None


def _parse_analysis_result(data: dict) -> dict:
    category = data.get("category", "").strip().lower()
    intent = data.get("intent", "").strip().title()
    urgency = data.get("urgency", "").strip().title()
    sender_type = data.get("sender_type", "").strip().lower()

    if category not in ALLOWED_CATEGORIES:
        category = "other"
    if intent not in ALLOWED_INTENTS:
        intent = "Other"
    if urgency not in ALLOWED_URGENCIES:
        urgency = "Low"
    if sender_type not in ALLOWED_SENDER_TYPES:
        sender_type = "unknown"

    return {
        "is_spam": bool(data.get("spam", False)),
        "intent": intent,
        "urgency": urgency,
        "category": category,
        "sender_type": sender_type,
        "summary": data.get("summary", "").strip(),
        "requires_reply": bool(data.get("requires_reply", True)),
        "reason": data.get("reason", "").strip(),
    }


def detect_intent_llm(subject: str, body: str) -> Optional[str]:
    if not is_available():
        return None
    try:
        data = create_structured_analysis(
            system_prompt="You are an email intent classifier. Return only valid JSON.",
            user_prompt=f"""Classify the intent of this email into exactly one:
Inquiry, Complaint, Support, Collaboration, Feedback, Request, Project_Discussion, Meeting_Request, Question, Follow_Up, Confirmation, Information, Spam, Other

Subject: {subject}
Body: {clean_email_body(body)[:2000]}

Return: {{"intent": "category"}}""",
        )
        intent = data.get("intent", "").strip().title()
        return intent if intent in ALLOWED_INTENTS else None
    except Exception as e:
        logger.warning("LLM intent detection failed: %s", e)
        return None


def detect_intent_rule(subject: str, body: str) -> str:
    text = (subject + " " + body).lower()
    scores = {}
    for category, keywords in INTENT_KEYWORDS.items():
        scores[category] = sum(1 for kw in keywords if kw in text)
    if max(scores.values()) == 0:
        return "Other"
    return max(scores, key=scores.get).title()


def detect_intent(subject: str, body: str) -> str:
    result = detect_intent_llm(subject, body)
    if result:
        return result
    return detect_intent_rule(subject, body)


def analyze_urgency_llm(subject: str, body: str, intent: str) -> Optional[str]:
    if not is_available():
        return None
    try:
        data = create_structured_analysis(
            system_prompt="You are an email urgency analyzer. Return only valid JSON.",
            user_prompt=f"""Analyze the urgency of this email as Low, Medium, or High.

Subject: {subject}
Body: {clean_email_body(body)[:2000]}
Intent: {intent}

Return: {{"urgency": "level"}}""",
        )
        urgency = data.get("urgency", "").strip().title()
        return urgency if urgency in ALLOWED_URGENCIES else None
    except Exception as e:
        logger.warning("LLM urgency analysis failed: %s", e)
        return None


def analyze_urgency_rule(subject: str, body: str, intent: str) -> str:
    text = (subject + " " + body).lower()
    if any(kw in text for kw in HIGH_KEYWORDS):
        return "High"
    if intent.title() in ["Complaint", "Support"]:
        return "Medium"
    if any(kw in text for kw in MEDIUM_KEYWORDS):
        return "Medium"
    return "Low"


def analyze_urgency(subject: str, body: str, intent: str) -> str:
    result = analyze_urgency_llm(subject, body, intent)
    if result:
        return result
    return analyze_urgency_rule(subject, body, intent)


def summarize_llm(subject: str, body: str, intent: str) -> Optional[dict]:
    if not is_available():
        return None
    try:
        data = create_structured_analysis(
            system_prompt="You are an email summarizer. Return only valid JSON.",
            user_prompt=f"""Summarize this email in 1-3 sentences.

Subject: {subject}
Body: {clean_email_body(body)[:2000]}
Intent: {intent}

Return:
{{"summary": "concise summary",
  "suggested_subject": "Re: suggested subject"}}""",
        )
        return {
            "summary": data.get("summary", "").strip(),
            "suggested_subject": data.get("suggested_subject", f"Re: {subject}").strip(),
        }
    except Exception as e:
        logger.warning("LLM summarization failed: %s", e)
        return None


def summarize_rule(subject: str, body: str, intent: str) -> dict:
    body_preview = body[:200].strip()
    return {
        "summary": f"{body_preview}{'...' if len(body) > 200 else ''}",
        "suggested_subject": f"Re: {subject}",
    }


def summarize_email(subject: str, body: str, intent: str) -> dict:
    result = summarize_llm(subject, body, intent)
    if result:
        return result
    return summarize_rule(subject, body, intent)


def detect_spam_llm(subject: str, body: str) -> Optional[bool]:
    if not is_available():
        return None
    try:
        data = create_structured_analysis(
            system_prompt="You are a spam detector. Return only valid JSON.",
            user_prompt=f"""Determine if this email is spam. Return true if it appears deceptive, promotional, irrelevant, malicious, or unsolicited.

Subject: {subject}
Body: {clean_email_body(body)[:2000]}

Return: {{"is_spam": true/false}}""",
        )
        return bool(data.get("is_spam", False))
    except Exception as e:
        logger.warning("LLM spam detection failed: %s", e)
        return None


def detect_spam_rule(subject: str, body: str) -> bool:
    text = (subject + " " + body).lower()
    matches = sum(1 for trigger in SPAM_TRIGGERS if trigger in text)
    return matches >= 2


def detect_spam(subject: str, body: str) -> bool:
    result = detect_spam_llm(subject, body)
    if result is not None:
        return result
    return detect_spam_rule(subject, body)


def detect_category_rule(intent: str, body: str) -> str:
    intent_lower = intent.lower()
    if intent_lower == "spam":
        return "spam"
    if intent_lower in ("project_discussion", "meeting_request", "follow_up"):
        return "personal"
    if intent_lower in ("feedback", "question", "confirmation", "information"):
        return "personal"
    if intent_lower in ("inquiry", "request"):
        return "inquiry"
    if intent_lower == "complaint":
        return "support"
    if intent_lower == "support":
        return "support"
    if intent_lower == "collaboration":
        return "personal"
    text = body.lower()
    human_indicators = ["i ", "my ", "me ", "i'm", "i've", "i'll", "i'd",
                        "we ", "our ", "let me", "can you", "could you"]
    if any(ind in text for ind in human_indicators):
        return "personal"
    return "other"


def detect_sender_type(sender: str, sender_name: str = "") -> str:
    sender_lower = sender.lower()
    name_lower = sender_name.lower().strip()

    if not name_lower and not sender_lower:
        return "unknown"

    for prefix in ("no-reply", "noreply", "no_reply"):
        if sender_lower.startswith(prefix) or f"@{prefix}" in sender_lower:
            return "no_reply"

    bulk_domains = ["mailchimp.com", "sendgrid.net", "hubspot.com", "constantcontact.com",
                    "mailgun.com", "amazonses.com", "mailjet.com", "sendinblue.com",
                    "braze.com", "iterable.com", "customerio.com", "klaviyo.com"]
    for domain in bulk_domains:
        if domain in sender_lower:
            return "bulk_marketing"

    human_patterns = ["@gmail.com", "@yahoo.com", "@outlook.com", "@hotmail.com",
                      "@icloud.com", "@protonmail.com", "@live.com", "@aol.com",
                      "@ymail.com", "@zoho.com", "@fastmail.com"]
    for pattern in human_patterns:
        if pattern in sender_lower:
            return "human"

    if name_lower and any(keyword in name_lower for keyword in
                          ["noreply", "no-reply", "no_reply", "notification", "alert"]):
        return "no_reply"

    if name_lower and len(name_lower) > 1 and not any(prefix in sender_lower for prefix in
                                                        ["unsubscribe", "list-", "bounce"]):
        return "human"

    return "unknown"


# ─── Reply Generation ───────────────────────────────────────────────────────

def generate_reply_groq(
    sender_name: str,
    sender_email: str,
    subject: str,
    email_body: str,
    tone: str,
    intent: str,
    urgency: str,
    category: str = "",
    summary: str = "",
    previous_reply: Optional[str] = None,
) -> Optional[str]:
    if not is_available():
        return None

    greeting_name = sender_name if sender_name and "@" not in sender_name else ""
    tone_guide = TONE_GUIDES.get(tone, TONE_GUIDES["Professional"])
    cleaned_body = clean_email_body(email_body)
    trimmed = cleaned_body[:settings.groq_max_email_chars]

    user_parts = [f"Write an email reply with the following context:\n"]
    user_parts.append(f"Sender name: {greeting_name or '(unknown)'}")
    user_parts.append(f"Subject: {subject}")
    if category:
        user_parts.append(f"Category: {category}")
    user_parts.append(f"Intent: {intent}")
    user_parts.append(f"Tone: {tone}")
    user_parts.append(f"Tone guidance:\n{tone_guide}")
    if summary:
        user_parts.append(f"Summary: {summary}")
    user_parts.append(f"Email body:\n{trimmed}")

    if previous_reply:
        user_parts.append(f"\nPrevious reply (write a clearly different version):\n{previous_reply}")
        user_parts.append("\nMake the new reply noticeably different in wording, sentence structure, opening, and closing.")
        user_parts.append("Preserve the same meaning, accuracy, and tone.")

    user_parts.append("\nReturn only the reply text. No JSON.")

    messages = [
        {"role": "system", "content": REPLY_SYSTEM_PROMPT},
        {"role": "user", "content": "\n".join(user_parts)},
    ]

    try:
        return create_chat_completion(
            messages=messages,
            temperature=0.6,
            top_p=0.9,
            max_tokens=600,
        )
    except GroqPayloadTooLarge:
        shorter = trimmed[:4000]
        user_parts = [p for p in user_parts if not p.startswith("Email body:")]
        user_parts.insert(6, f"Email body:\n{shorter}")
        messages = [
            {"role": "system", "content": REPLY_SYSTEM_PROMPT},
            {"role": "user", "content": "\n".join(user_parts)},
        ]
        try:
            return create_chat_completion(
                messages=messages,
                temperature=0.6,
                top_p=0.9,
                max_tokens=600,
            )
        except Exception as e2:
            logger.warning("Groq reply generation failed even after shortening: %s", e2)
            return None
    except Exception as e:
        logger.warning("Groq reply generation failed: %s", e)
        return None


def generate_reply_rule(
    sender_name: str,
    sender_email: str,
    subject: str,
    email_body: str,
    tone: str,
    intent: str,
    urgency: str,
) -> str:
    name = sender_name if sender_name and "@" not in sender_name else ""
    greeting = "Hello"
    if name:
        if tone.title() == "Friendly":
            greeting = f"Hi {name}"
        else:
            greeting = f"Dear {name}"
    elif sender_email and "@" in sender_email:
        name_part = sender_email.split("@")[0].replace(".", " ").title()
        greeting = f"Dear {name_part}"

    tone_closing = TONE_CLOSINGS.get(tone.title(), "Best regards")

    intent_key = intent.title() if intent.title() in TONE_RENDERERS.get(tone.title(), {}) else "Other"
    tone_templates = TONE_RENDERERS.get(tone.title(), TONE_RENDERERS["Professional"])
    body_text = tone_templates.get(intent_key, tone_templates["Other"])
    if not body_text:
        return ""

    return f"{greeting},\n\n{body_text}\n\n{tone_closing}"


def generate_reply(
    sender_name: str,
    sender_email: str,
    subject: str,
    email_body: str,
    intent: str,
    urgency: str,
    tone: str,
    category: str = "",
    summary: str = "",
    previous_reply: Optional[str] = None,
) -> tuple[str, str]:
    result = generate_reply_groq(
        sender_name=sender_name,
        sender_email=sender_email,
        subject=subject,
        email_body=email_body,
        tone=tone,
        intent=intent,
        urgency=urgency,
        category=category,
        summary=summary,
        previous_reply=previous_reply,
    )
    if result:
        validation = validate_generated_reply(result)
        if validation.valid:
            logger.info("Reply generated using Groq")
            return result, "groq"
        logger.warning("Groq reply failed validation: %s", validation.message)
        return "", validation.error_code

    logger.warning("Groq failed, no fallback reply generated")
    return "", "groq_unavailable"


# ─── Main Entry Point ───────────────────────────────────────────────────────

def process_email(sender: str, subject: str, body: str, tone: str) -> dict:
    result = analyze_email_llm(subject, body)
    if result:
        is_spam = result["is_spam"]
        intent = result["intent"]
        urgency = result["urgency"]
        summary = result["summary"]
        requires_reply = result["requires_reply"]
        category = result.get("category", "other")
        sender_type = result.get("sender_type", "unknown")
        reason = result.get("reason", "")

        if not intent:
            intent = detect_intent_rule(subject, body)
        if not urgency:
            urgency = analyze_urgency_rule(subject, body, intent)
        if not summary:
            summary = summarize_rule(subject, body, intent)["summary"]

        if is_spam:
            return {
                "intent": "Spam",
                "urgency": "Low",
                "summary": "This message has been classified as spam.",
                "suggested_subject": "Re: " + subject,
                "reply": "",
                "is_spam": True,
                "category": "spam",
                "requires_reply": False,
                "analysis_provider": "groq",
                "reply_provider": "none",
                "reply_generated": False,
                "spam_reason": reason or "Detected as spam by AI",
            }

        no_reply = check_no_reply_rules(
            category=category,
            sender_type=sender_type,
            sender_email=sender,
            requires_reply=requires_reply,
        )
        if no_reply["block_reply"]:
            return {
                "intent": intent,
                "urgency": urgency,
                "summary": summary,
                "suggested_subject": f"Re: {subject}",
                "reply": "",
                "is_spam": False,
                "category": category,
                "requires_reply": False,
                "analysis_provider": "groq",
                "reply_provider": "none",
                "reply_generated": False,
                "reason": no_reply["reason"],
            }

        reply, source = generate_reply(
            sender_name="",
            sender_email=sender,
            subject=subject,
            email_body=body,
            intent=intent,
            urgency=urgency,
            tone=tone,
            summary=summary,
        )
        reply_provider = source if source in ("groq",) else "local_rules"
        reply_generated = bool(reply)

        return {
            "intent": intent,
            "urgency": urgency,
            "summary": summary,
            "suggested_subject": f"Re: {subject}",
            "reply": reply,
            "is_spam": False,
            "category": category,
            "requires_reply": True,
            "analysis_provider": "groq",
            "reply_provider": reply_provider,
            "reply_generated": reply_generated,
            "reason": reason,
        }

    is_spam = detect_spam(subject, body)
    if is_spam:
        return {
            "intent": "Spam",
            "urgency": "Low",
            "summary": "This message has been classified as spam.",
            "suggested_subject": "Re: " + subject,
            "reply": "",
            "is_spam": True,
            "category": "spam",
            "requires_reply": False,
            "analysis_provider": "local_rules",
            "reply_provider": "none",
            "reply_generated": False,
            "spam_reason": "Detected as spam by local rules",
        }

    intent = detect_intent(subject, body)
    urgency = analyze_urgency(subject, body, intent)
    category = detect_category_rule(intent, body)
    sender_type = detect_sender_type(sender)
    summary_data = summarize_email(subject, body, intent)
    summary = summary_data.get("summary", "")
    suggested_subject = summary_data.get("suggested_subject", f"Re: {subject}")

    no_reply_result = check_no_reply_rules(
        category=category,
        sender_type=sender_type,
        sender_email=sender,
        requires_reply=True,
    )
    requires_reply = not no_reply_result["block_reply"]

    reply, source = generate_reply(
        sender_name="",
        sender_email=sender,
        subject=subject,
        email_body=body,
        intent=intent,
        urgency=urgency,
        tone=tone,
        summary=summary,
    )
    reply_provider = "local_rules" if reply else "none"
    reply_generated = bool(reply)

    return {
        "intent": intent,
        "urgency": urgency,
        "summary": summary,
        "suggested_subject": suggested_subject,
        "reply": reply if requires_reply else "",
        "is_spam": False,
        "category": category,
        "requires_reply": requires_reply,
        "analysis_provider": "local_rules",
        "reply_provider": reply_provider,
        "reply_generated": reply_generated if requires_reply else False,
        "reason": no_reply_result["reason"] if no_reply_result["block_reply"] else "",
    }
