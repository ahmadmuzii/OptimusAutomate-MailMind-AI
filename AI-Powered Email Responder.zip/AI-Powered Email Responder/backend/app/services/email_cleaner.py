import html as html_module
import logging
import re

logger = logging.getLogger(__name__)

_TRACKING_DOMAINS = re.compile(
    r'https?://[^\s]*(?:mmstat|doubleclick|googleadservices|googletagmanager|quantserve|scorecardresearch|'
    r'outbrain|taboola|amazon-adsystem|adnxs|rubiconproject|pubmatic|openx|criteo|mathtag|bluekai|'
    r'exelator|demdex|krxd|rlcdn|adsrvr|adroll|tribalfusion|pro-market)\.[^\s)\">]+',
    re.IGNORECASE,
)
_IMG_TAG = re.compile(r'<img[^>]*>', re.IGNORECASE)
_SCRIPT_TAG = re.compile(r'<script[^>]*>.*?</script>', re.IGNORECASE | re.DOTALL)
_STYLE_TAG = re.compile(r'<style[^>]*>.*?</style>', re.IGNORECASE | re.DOTALL)
_COMMENT = re.compile(r'<!--.*?-->', re.DOTALL)
_META_TAG = re.compile(r'<meta[^>]*>', re.IGNORECASE)
_LINK_TAG = re.compile(r'<link[^>]*>', re.IGNORECASE)
_NOSCRIPT_TAG = re.compile(r'<noscript[^>]*>.*?</noscript>', re.IGNORECASE | re.DOTALL)
_BLOCK_TAGS = re.compile(r'</?(?:div|p|br|tr|li|h[1-6]|blockquote|table|section|article|header|footer)[^>]*>', re.IGNORECASE)
_ALL_TAGS = re.compile(r'<[^>]*>')
_WHITESPACE = re.compile(r'\s+')
_MULTI_NEWLINE = re.compile(r'\n{3,}')
_QUOTED_REPLY_HEADER = re.compile(r'(?m)^(?:On .+ wrote:|From:.+Sent:|To:.+Subject:).*$')
_QUOTE_LINE = re.compile(r'(?m)^[>|].*$')
_FORWARD_HEADER = re.compile(r'(?m)^-{3,}Forwarded message-{3,}.*$', re.IGNORECASE)
_SIGNATURE = re.compile(r'(?m)^--\s*$.*(?:\n.*)*', re.DOTALL)
_DISCLAIMER_BLOCKS = [
    re.compile(r'(?im)this (?:e-?mail|message) .{0,30} (?:confidential|privileged|legally binding).*?(?:\n\n|\Z)', re.DOTALL),
    re.compile(r'(?im)disclaimer:.*?(?:\n\n|\Z)', re.DOTALL),
    re.compile(r'(?im)please consider.{0,30}environment.*?(?:\n\n|\Z)', re.DOTALL),
    re.compile(r'(?im)if you are not the intended recipient.*?(?:\n\n|\Z)', re.DOTALL),
]
_UNSUBSCRIBE = re.compile(r'(?im)^.*unsubscribe.*$')
_HIDDEN_UNICODE = re.compile(r'[\u200b\u200c\u200d\u2060\u2061\u2062\u2063\u2064\ufeff]')
_BASE64_LINE = re.compile(r'^[A-Za-z0-9+/=]{60,}$', re.MULTILINE)
_CID_REF = re.compile(r'cid:[^\s\">]+', re.IGNORECASE)
_DATA_URI = re.compile(r'data:[^;]+;base64[^\)\s\"]+', re.IGNORECASE)
_HIDDEN_STYLE = re.compile(r'style=["\'][^"\']*display\s*:\s*none[^"\']*["\']', re.IGNORECASE)
_HIDDEN_ATTR = re.compile(r'\shidden[=>\s]', re.IGNORECASE)


def clean_email_content(
    html_body: str | None = None,
    plain_body: str | None = None,
    max_chars: int = 12_000,
) -> str:
    if plain_body and plain_body.strip():
        text = plain_body
    elif html_body and html_body.strip():
        text = _html_to_text(html_body)
    else:
        return ""

    text = _remove_hidden_unicode(text)
    text = _remove_quote_lines(text)
    text = _remove_forward_headers(text)
    text = _remove_quoted_reply_headers(text)
    text = _remove_signatures(text)
    text = _remove_disclaimers(text)
    text = _remove_unsubscribe(text)
    text = _remove_tracking_urls(text)
    text = _remove_base64_lines(text)
    text = _collapse_whitespace(text)
    text = text.strip()

    if max_chars and len(text) > max_chars:
        break_point = text.rfind("\n", 0, max_chars)
        text = text[:break_point] if break_point > 0 else text[:max_chars]

    return text


def _html_to_text(html: str) -> str:
    text = html
    text = _SCRIPT_TAG.sub("", text)
    text = _STYLE_TAG.sub("", text)
    text = _NOSCRIPT_TAG.sub("", text)
    text = _COMMENT.sub("", text)
    text = _remove_hidden_elements(text)
    text = _IMG_TAG.sub("", text)
    text = _META_TAG.sub("", text)
    text = _LINK_TAG.sub("", text)
    text = _CID_REF.sub("", text)
    text = _DATA_URI.sub("", text)
    text = _BLOCK_TAGS.sub("\n", text)
    text = _ALL_TAGS.sub("", text)
    text = html_module.unescape(text)
    return text


def _remove_hidden_elements(html: str) -> str:
    result = html
    pos = 0
    while pos < len(result):
        # Find elements with hidden style or attribute
        style_match = _HIDDEN_STYLE.search(result, pos)
        attr_match = _HIDDEN_ATTR.search(result, pos)
        match = None
        if style_match and attr_match:
            match = style_match if style_match.start() < attr_match.start() else attr_match
        elif style_match or attr_match:
            match = style_match or attr_match

        if not match:
            break

        # Find the start of the containing tag
        tag_start = result.rfind("<", 0, match.start())
        if tag_start == -1:
            pos = match.end()
            continue

        # Find if this is a self-closing tag
        tag_end = result.find(">", match.start())
        if tag_end == -1:
            pos = match.end()
            continue

        tag_snippet = result[tag_start:tag_end + 1]
        if tag_snippet.endswith("/>") or tag_snippet.startswith("<!") or tag_snippet.startswith("<?"):
            result = result[:tag_start] + result[tag_end + 1:]
            pos = tag_start
            continue

        # Find the closing tag
        tag_name_match = re.match(r'<(\w+)', tag_snippet)
        if not tag_name_match:
            pos = tag_end + 1
            continue

        close_tag = f"</{tag_name_match.group(1)}"
        close_pos = result.find(close_tag, tag_end)
        if close_pos == -1:
            result = result[:tag_start] + result[tag_end + 1:]
            pos = tag_start
            continue

        end_close = result.find(">", close_pos)
        if end_close == -1:
            result = result[:tag_start] + result[tag_end + 1:]
            pos = tag_start
            continue

        result = result[:tag_start] + result[end_close + 1:]
        pos = tag_start

    return result


def _remove_tracking_urls(text: str) -> str:
    return _TRACKING_DOMAINS.sub("[tracking link removed]", text)


def _remove_quoted_reply_headers(text: str) -> str:
    return _QUOTED_REPLY_HEADER.sub("", text)


def _remove_quote_lines(text: str) -> str:
    return _QUOTE_LINE.sub("", text)


def _remove_forward_headers(text: str) -> str:
    return _FORWARD_HEADER.sub("", text)


def _remove_signatures(text: str) -> str:
    return _SIGNATURE.sub("", text)


def _remove_disclaimers(text: str) -> str:
    for pattern in _DISCLAIMER_BLOCKS:
        text = pattern.sub("", text)
    return text


def _remove_unsubscribe(text: str) -> str:
    return _UNSUBSCRIBE.sub("", text)


def _remove_hidden_unicode(text: str) -> str:
    return _HIDDEN_UNICODE.sub("", text)


def _remove_base64_lines(text: str) -> str:
    return _BASE64_LINE.sub("", text)


def _collapse_whitespace(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = _MULTI_NEWLINE.sub("\n\n", text)
    return text.strip()
