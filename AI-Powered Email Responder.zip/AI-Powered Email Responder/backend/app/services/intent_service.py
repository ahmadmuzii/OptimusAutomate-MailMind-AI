import logging

from app.core.groq_client import get_groq_client, is_groq_available
from app.core.keyword_maps import detect_intent_by_keywords, VALID_INTENTS

logger = logging.getLogger(__name__)

_INTENT_PROMPT_TEMPLATE = """You are an email intent classifier. Analyze the email below and classify its intent.

Valid categories (choose EXACTLY one):
- Inquiry: The sender is asking a question or seeking information.
- Complaint: The sender is expressing dissatisfaction or reporting a problem with a product/service.
- Support: The sender needs technical help, troubleshooting, or guidance.
- Collaboration: The sender is proposing a partnership, joint project, or cooperative effort.
- Spam: The email is unsolicited, promotional, or suspicious.
- Other: Doesn't fit any of the above categories.

Email Subject: {subject}
Email Body: {body}

Respond with ONLY the intent category name. No explanation."""


def detect_intent(subject: str, email_body: str) -> str:
    if not is_groq_available():
        return detect_intent_by_keywords(subject, email_body)

    client = get_groq_client()
    prompt = _INTENT_PROMPT_TEMPLATE.format(subject=subject, body=email_body)

    try:
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            max_tokens=20,
        )
        detected = response.choices[0].message.content.strip()

        if detected in VALID_INTENTS:
            return detected
        for valid in VALID_INTENTS:
            if valid.lower() == detected.lower():
                return valid

        logger.warning("LLM returned invalid intent '%s', falling back to keywords", detected)
    except Exception as e:
        logger.error("Groq intent detection failed: %s", e)

    return detect_intent_by_keywords(subject, email_body)
