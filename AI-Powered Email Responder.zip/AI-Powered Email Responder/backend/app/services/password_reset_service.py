import hashlib
import secrets
import logging
from datetime import datetime, timezone, timedelta

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import hash_password
from app.models.user import User
from app.models.password_reset import PasswordResetToken

logger = logging.getLogger(__name__)


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_reset_token(user: User, db: Session, requested_ip: str | None = None) -> str:
    revoke_previous_tokens(user.id, db)

    raw_token = secrets.token_urlsafe(32)
    token_hash = _hash_token(raw_token)
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=settings.password_reset_token_minutes)

    reset_token = PasswordResetToken(
        user_id=user.id,
        token_hash=token_hash,
        expires_at=expires_at,
        requested_ip=requested_ip or "",
    )
    db.add(reset_token)
    db.commit()

    logger.info("Created password reset token for user %d", user.id)
    return raw_token


def revoke_previous_tokens(user_id: int, db: Session) -> None:
    active = (
        db.query(PasswordResetToken)
        .filter(
            PasswordResetToken.user_id == user_id,
            PasswordResetToken.is_revoked == False,
            PasswordResetToken.used_at.is_(None),
        )
        .all()
    )
    for token in active:
        token.is_revoked = True
    db.commit()


def validate_and_use_token(raw_token: str, db: Session) -> User:
    token_hash = _hash_token(raw_token)
    now = datetime.now(timezone.utc)

    reset_token = (
        db.query(PasswordResetToken)
        .filter(
            PasswordResetToken.token_hash == token_hash,
            PasswordResetToken.is_revoked == False,
            PasswordResetToken.used_at.is_(None),
        )
        .first()
    )

    if not reset_token:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")

    if reset_token.expires_at < now:
        reset_token.is_revoked = True
        db.commit()
        raise HTTPException(status_code=400, detail="Reset token has expired")

    user = db.query(User).filter(User.id == reset_token.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    reset_token.used_at = now
    db.commit()

    revoke_previous_tokens(user.id, db)

    return user


def reset_password(raw_token: str, new_password: str, db: Session) -> None:
    user = validate_and_use_token(raw_token, db)
    user.password_hash = hash_password(new_password)
    db.commit()
    logger.info("Password reset completed for user %d", user.id)


def build_reset_url(raw_token: str) -> str:
    return f"{settings.frontend_url}/reset-password?token={raw_token}"
