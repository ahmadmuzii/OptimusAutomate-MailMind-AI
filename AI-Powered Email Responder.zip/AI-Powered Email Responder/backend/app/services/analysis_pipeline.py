import logging

from app.services.intent_service import detect_intent
from app.services.urgency_service import analyze_urgency
from app.services.summarizer_service import summarize_email
from app.services.reply_service import generate_reply

logger = logging.getLogger(__name__)


class AnalysisResult:
    def __init__(self, intent: str, urgency: str, summary: str, suggested_subject: str, reply: str):
        self.intent = intent
        self.urgency = urgency
        self.summary = summary
        self.suggested_subject = suggested_subject
        self.reply = reply


def run_analysis_pipeline(sender: str, subject: str, email_body: str, tone: str) -> AnalysisResult:
    logger.info("Starting analysis pipeline for sender=%s subject=%s", sender, subject)

    intent = detect_intent(subject=subject, email_body=email_body)
    logger.info("Intent detected: %s", intent)

    urgency = analyze_urgency(subject=subject, email_body=email_body, intent=intent)
    logger.info("Urgency detected: %s", urgency)

    summary_data = summarize_email(subject=subject, email_body=email_body, intent=intent)
    logger.info("Summary generated")

    reply = generate_reply(
        sender=sender,
        subject=subject,
        email_body=email_body,
        intent=intent,
        urgency=urgency,
        tone=tone,
        summary=summary_data["summary"],
    )
    logger.info("Reply generated (%d chars)", len(reply))

    return AnalysisResult(
        intent=intent,
        urgency=urgency,
        summary=summary_data["summary"],
        suggested_subject=summary_data["suggested_subject"],
        reply=reply,
    )
