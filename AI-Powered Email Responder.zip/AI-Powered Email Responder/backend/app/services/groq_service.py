import json
import logging
import time
from typing import Optional

from groq import (
    Groq,
    APIStatusError,
    APITimeoutError,
    APIConnectionError,
    RateLimitError,
    AuthenticationError,
    BadRequestError,
)

from app.core.config import settings

logger = logging.getLogger(__name__)

_client: Optional[Groq] = None
_available: bool = False
_model: str = ""

# --- Rate limiter state ---
_last_request_time: float = 0.0

# --- Circuit breaker state ---
CIRCUIT_CLOSED = "CLOSED"
CIRCUIT_OPEN = "OPEN"
CIRCUIT_HALF_OPEN = "HALF_OPEN"

_circuit_state: str = CIRCUIT_CLOSED
_consecutive_failures: int = 0
_circuit_open_until: float = 0.0
_circuit_half_open_used: bool = False

# --- Last error tracking for diagnostics ---
_last_error_code: str = ""

# --- Last model used tracking ---
_last_model_used: str = ""


def get_last_model_used() -> str:
    return _last_model_used


class GroqPayloadTooLarge(RuntimeError):
    pass


class GroqRateLimited(RuntimeError):
    pass


class GroqServiceUnavailable(RuntimeError):
    pass


def _initialize() -> None:
    global _client, _available, _model
    api_key = settings.groq_api_key
    _model = settings.groq_model or "openai/gpt-oss-120b"

    if not api_key:
        _available = False
        _client = None
        logger.info("GROQ_API_KEY is not set. LLM features will fall back to rule-based.")
        return

    if api_key.startswith("gsk_your"):
        _available = False
        _client = None
        logger.warning("GROQ_API_KEY has placeholder value. LLM features will fall back.")
        return

    try:
        _client = Groq(api_key=api_key)
        _available = True
        logger.info("Groq client initialized with model %s", _model)
    except Exception as e:
        _available = False
        _client = None
        logger.warning("Failed to initialize Groq client: %s", e)


def is_available() -> bool:
    if _client is None:
        _initialize()
    return _available


def get_model() -> str:
    if _client is None:
        _initialize()
    return _model


def _enforce_rate_limit() -> None:
    global _last_request_time
    elapsed = time.monotonic() - _last_request_time
    if elapsed < settings.groq_min_request_interval_seconds:
        sleep_time = settings.groq_min_request_interval_seconds - elapsed
        logger.debug("Rate limiter: sleeping %.2fs", sleep_time)
        time.sleep(sleep_time)
    _last_request_time = time.monotonic()


# ─── Circuit Breaker (closed / open / half-open) ──────────────────────────────

def get_circuit_breaker_state() -> dict:
    """Return current circuit breaker state for diagnostics."""
    now = time.monotonic()
    cooldown = 0.0
    if _circuit_state == CIRCUIT_OPEN:
        cooldown = max(0.0, _circuit_open_until - now)
    return {
        "state": _circuit_state,
        "failure_count": _consecutive_failures,
        "threshold": settings.circuit_breaker_threshold,
        "cooldown_remaining": round(cooldown, 1),
        "half_open_used": _circuit_half_open_used,
    }


def _circuit_breaker_allow() -> bool:
    global _circuit_state, _circuit_half_open_used, _circuit_open_until
    now = time.monotonic()

    if _circuit_state == CIRCUIT_CLOSED:
        return True

    if _circuit_state == CIRCUIT_OPEN:
        if now >= _circuit_open_until:
            _circuit_state = CIRCUIT_HALF_OPEN
            _circuit_half_open_used = True
            logger.info("Circuit breaker: OPEN -> HALF_OPEN (test request allowed)")
            return True
        logger.warning(
            "Circuit breaker: OPEN for another %.0fs",
            _circuit_open_until - now,
        )
        return False

    # HALF_OPEN — allow exactly one test request
    if _circuit_state == CIRCUIT_HALF_OPEN:
        if not _circuit_half_open_used:
            _circuit_half_open_used = True
            logger.info("Circuit breaker: HALF_OPEN — allowing test request")
            return True
        logger.warning("Circuit breaker: HALF_OPEN — test request already used")
        return False

    return False


def _circuit_breaker_record_success() -> None:
    global _circuit_state, _consecutive_failures, _circuit_open_until, _circuit_half_open_used, _last_error_code
    _circuit_state = CIRCUIT_CLOSED
    _consecutive_failures = 0
    _circuit_open_until = 0.0
    _circuit_half_open_used = False
    _last_error_code = ""


def _circuit_breaker_record_failure() -> None:
    global _circuit_state, _consecutive_failures, _circuit_open_until, _circuit_half_open_used, _last_error_code

    if _circuit_state == CIRCUIT_HALF_OPEN:
        _circuit_state = CIRCUIT_OPEN
        _circuit_open_until = time.monotonic() + settings.circuit_breaker_reset_seconds
        _circuit_half_open_used = False
        logger.warning(
            "Circuit breaker: HALF_OPEN -> OPEN (test request failed, cooldown %ds)",
            settings.circuit_breaker_reset_seconds,
        )
        return

    _consecutive_failures += 1
    if _consecutive_failures >= settings.circuit_breaker_threshold:
        _circuit_state = CIRCUIT_OPEN
        _circuit_open_until = time.monotonic() + settings.circuit_breaker_reset_seconds
        logger.warning(
            "Circuit breaker: CLOSED -> OPEN after %d consecutive failures (cooldown %ds)",
            _consecutive_failures,
            settings.circuit_breaker_reset_seconds,
        )


# ─── Error Classification ────────────────────────────────────────────────────

def _parse_retry_after(e: Exception) -> float:
    """Extract Retry-After header value from a rate-limit error."""
    try:
        if hasattr(e, "response") and hasattr(e.response, "headers"):
            retry_after = e.response.headers.get("retry-after")
            if retry_after:
                return float(retry_after)
    except (ValueError, AttributeError, TypeError):
        pass
    return settings.groq_min_request_interval_seconds


def _classify_groq_error(e: Exception) -> RuntimeError:
    global _last_error_code

    if isinstance(e, RateLimitError):
        _circuit_breaker_record_failure()
        _last_error_code = "RATE_LIMITED"
        return GroqRateLimited("Groq API rate limit exceeded. Please try again later.")
    if isinstance(e, APITimeoutError):
        _last_error_code = "TIMEOUT"
        return RuntimeError("Groq API request timed out. Please try again.")
    if isinstance(e, APIConnectionError):
        _circuit_breaker_record_failure()
        _last_error_code = "CONNECTION_FAILED"
        return GroqServiceUnavailable("Groq API connection failed. The service may be unavailable.")
    if isinstance(e, AuthenticationError):
        _last_error_code = "AUTH_FAILED"
        return RuntimeError("Groq API authentication failed. Please check your API key.")
    if isinstance(e, BadRequestError):
        if hasattr(e, "status_code") and e.status_code == 413:
            _last_error_code = "PAYLOAD_TOO_LARGE"
            return GroqPayloadTooLarge("Email content exceeds the maximum allowed request size.")
        _last_error_code = "BAD_REQUEST"
        return RuntimeError(f"Groq API bad request: {e}")
    if isinstance(e, APIStatusError):
        status = getattr(e, "status_code", 0)
        if status == 413:
            _last_error_code = "PAYLOAD_TOO_LARGE"
            return GroqPayloadTooLarge("Email content exceeds the maximum allowed request size.")
        if status == 429:
            _circuit_breaker_record_failure()
            _last_error_code = "RATE_LIMITED"
            return GroqRateLimited("Groq API rate limit exceeded. Please try again later.")
        if status == 503 or status == 502:
            _circuit_breaker_record_failure()
            _last_error_code = f"SERVICE_UNAVAILABLE_{status}"
            return GroqServiceUnavailable(f"Groq API temporarily unavailable (HTTP {status}).")
        if status == 404:
            _circuit_breaker_record_failure()
            body = getattr(e, "body", None) or ""
            error_body_str = str(body).lower()
            if "model_not_found" in error_body_str or "model" in error_body_str:
                _last_error_code = "GROQ_MODEL_NOT_FOUND"
            elif "route" in error_body_str or "not found" in error_body_str:
                _last_error_code = "GROQ_ROUTE_NOT_FOUND"
            else:
                _last_error_code = f"API_ERROR_{status}"
            logger.warning("Groq 404 error body: %s", body)
            return RuntimeError(f"Groq API error (HTTP {status}): {e}")
        if status == 403:
            _last_error_code = "GROQ_PERMISSION_DENIED"
            return RuntimeError(f"Groq API permission denied (HTTP {status}): {e}")
        if status == 401:
            _last_error_code = "GROQ_AUTH_FAILED"
            return RuntimeError(f"Groq API authentication failed (HTTP {status}): {e}")
        _last_error_code = f"API_ERROR_{status}"
        return RuntimeError(f"Groq API error (HTTP {status}): {e}")
    _last_error_code = "UNKNOWN"
    return RuntimeError(f"Groq API error: {e}")


def _make_groq_call(kwargs: dict, _429_retries: int = 0) -> str:
    _enforce_rate_limit()

    try:
        response = _client.chat.completions.create(**kwargs)
        _circuit_breaker_record_success()
    except RateLimitError as e:
        _circuit_breaker_record_failure()
        if _429_retries < 2:
            retry_after = _parse_retry_after(e)
            logger.warning(
                "Rate limited (429), retrying after %.1fs (attempt %d/2)",
                retry_after, _429_retries + 1,
            )
            time.sleep(retry_after)
            return _make_groq_call(kwargs, _429_retries + 1)
        _last_error_code = "RATE_LIMITED"
        raise GroqRateLimited("Groq API rate limit exceeded after retries.") from e
    except Exception as e:
        raise _classify_groq_error(e) from e

    content = response.choices[0].message.content
    if not content or not content.strip():
        _last_error_code = "EMPTY_RESPONSE"
        raise RuntimeError("Groq returned an empty response")
    return content.strip()


def _log_safe_endpoint() -> None:
    """Log the final Groq Chat Completions endpoint without headers or API key."""
    try:
        is_available()
        if _client is not None and hasattr(_client, "_base_url"):
            base = str(_client._base_url)
            logger.info("Groq base_url: %s", base)
            logger.info("Groq Chat Completions endpoint: %s/openai/v1/chat/completions", base.rstrip("/"))
        else:
            logger.info("Groq Chat Completions endpoint: https://api.groq.com/openai/v1/chat/completions (inferred)")
    except Exception as log_err:
        logger.debug("Could not log Groq endpoint: %s", log_err)


def _try_model_with_fallback(kwargs: dict, actual_model: str, fallback_model: str) -> str:
    global _last_model_used
    _log_safe_endpoint()
    kwargs["model"] = actual_model
    try:
        result = _make_groq_call(kwargs)
        _last_model_used = actual_model
        return result
    except (GroqPayloadTooLarge, GroqRateLimited):
        raise
    except Exception as e:
        err_msg = str(e).lower()
        if ("model_not_found" in err_msg or "not found" in err_msg or "does not exist" in err_msg):
            _last_error_code = "GROQ_MODEL_NOT_FOUND"
            if actual_model != fallback_model:
                logger.warning("Model '%s' not found, trying fallback '%s'", actual_model, fallback_model)
                kwargs["model"] = fallback_model
                try:
                    result = _make_groq_call(kwargs)
                    _last_model_used = fallback_model
                    return result
                except Exception as e2:
                    raise RuntimeError(f"Groq API error (both models failed): {e2}") from e2
            raise RuntimeError(f"Groq API error: {e}") from e
        raise


def create_chat_completion(
    messages: list[dict[str, str]],
    temperature: float = 0.7,
    max_tokens: int = 600,
    top_p: float = 0.95,
    response_format: Optional[dict] = None,
    model: Optional[str] = None,
) -> str:
    if not is_available():
        raise RuntimeError("Groq client not available")

    actual_model = model or _model
    fallback_model = settings.groq_fallback_model or "mixtral-8x7b-32768"

    if not _circuit_breaker_allow():
        raise GroqServiceUnavailable("Groq circuit breaker is open. Please try again later.")

    kwargs: dict = {
        "model": actual_model,
        "messages": messages,
        "temperature": temperature,
        "top_p": top_p,
        "max_tokens": max_tokens,
    }
    if response_format:
        kwargs["response_format"] = response_format

    return _try_model_with_fallback(kwargs, actual_model, fallback_model)


def create_structured_analysis(
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.1,
    max_tokens: int = 200,
) -> dict:
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]
    try:
        content = create_chat_completion(
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format={"type": "json_object"},
        )
        return json.loads(content)
    except json.JSONDecodeError:
        logger.warning("Groq returned invalid JSON")
        raise RuntimeError("Groq returned invalid JSON response")
    except Exception as e:
        logger.warning("Groq structured analysis failed: %s", e)
        raise


def get_groq_diagnostics() -> dict:
    """Return diagnostic info about the Groq service. Does not expose the API key."""
    cb = get_circuit_breaker_state()
    return {
        "configured": is_available(),
        "model": _model if _available else None,
        "fallback_model": settings.groq_fallback_model,
        "circuit_state": _circuit_state.lower(),
        "circuit_breaker": cb,
        "last_error_code": _last_error_code or None,
    }


def reset_rate_limiter() -> None:
    global _last_request_time
    _last_request_time = 0.0


def reset_circuit_breaker() -> None:
    global _circuit_state, _consecutive_failures, _circuit_open_until, _circuit_half_open_used, _last_error_code
    _circuit_state = CIRCUIT_CLOSED
    _consecutive_failures = 0
    _circuit_open_until = 0.0
    _circuit_half_open_used = False
    _last_error_code = ""
