from datetime import datetime, timezone
from sqlalchemy import Column, String, Text, Boolean, DateTime, Integer, ForeignKey
from sqlalchemy.orm import relationship

from app.database.base import Base


class GmailSyncLog(Base):
    __tablename__ = "gmail_sync_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)
    status = Column(String(50), default="Running")
    messages_fetched = Column(Integer, default=0)
    messages_imported = Column(Integer, default=0)
    error_message = Column(Text, nullable=True)
    trigger_type = Column(String(50), default="Manual")
    is_completed = Column(Boolean, default=False)

    user = relationship("User", back_populates="sync_logs")
