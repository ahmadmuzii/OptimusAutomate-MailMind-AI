from datetime import datetime, timezone
from sqlalchemy import Column, String, Text, Boolean, DateTime, Integer, ForeignKey
from sqlalchemy.orm import relationship

from app.database.base import Base


class Email(Base):
    __tablename__ = "emails"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    gmail_message_id = Column(String(255), nullable=True, unique=True, index=True)
    gmail_thread_id = Column(String(255), nullable=True)
    sender_name = Column(String(255), nullable=True)
    sender_email = Column(String(254), nullable=False)
    recipient = Column(String(254), nullable=True)
    subject = Column(String(500), nullable=False)
    body = Column(Text, nullable=True)
    body_loaded = Column(Boolean, default=False, nullable=False)
    body_preview = Column(Text, nullable=True)
    raw_html = Column(Text, nullable=True)
    clean_body = Column(Text, nullable=True)
    category = Column(String(50), nullable=True)
    received_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    intent = Column(String(50), nullable=True)
    urgency = Column(String(20), nullable=True)
    summary = Column(Text, nullable=True)
    spam_reason = Column(String(255), nullable=True)
    is_spam = Column(Boolean, default=False)
    is_read = Column(Boolean, default=False)
    source = Column(String(50), default="manual")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    user = relationship("User", back_populates="emails")
    drafts = relationship("Draft", back_populates="email", cascade="all, delete-orphan")
