from datetime import datetime, timezone
from sqlalchemy import Column, String, Text, Boolean, DateTime, Integer, ForeignKey
from sqlalchemy.orm import relationship

from app.database.base import Base


class Draft(Base):
    __tablename__ = "drafts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    email_id = Column(Integer, ForeignKey("emails.id"), nullable=True)
    gmail_draft_id = Column(String(255), nullable=True)
    gmail_message_id = Column(String(255), nullable=True)
    recipient = Column(String(254), nullable=False)
    subject = Column(String(500), nullable=False)
    body = Column(Text, nullable=False)
    tone = Column(String(50), default="Professional")
    status = Column(String(50), default="Local")
    send_error = Column(Text, nullable=True)
    sent_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    user = relationship("User", back_populates="drafts")
    email = relationship("Email", back_populates="drafts")
