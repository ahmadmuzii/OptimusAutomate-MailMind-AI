from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    groq_api_key: str = ""
    app_name: str = "MailMind AI"
    app_version: str = "1.0.0"
    cors_origins: list[str] = [
        "http://localhost:5173",
        "http://localhost:3000",
        "http://localhost:4173",
    ]
    log_level: str = "INFO"

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()
