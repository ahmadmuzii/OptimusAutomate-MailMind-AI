from datetime import datetime
from pydantic import BaseModel, Field


class EmailAnalyzeRequest(BaseModel):
    sender: str = Field(..., min_length=1, max_length=254)
    sender_name: str | None = None
    subject: str = Field(..., min_length=1, max_length=500)
    email_body: str = Field(..., min_length=1, max_length=10000)
    tone: str = Field(default="Professional", max_length=50)


class EmailAnalyzeResponse(BaseModel):
    email_id: int
    intent: str
    urgency: str
    summary: str
    suggested_subject: str
    reply: str
    is_spam: bool = False
    spam_reason: str = ""
    category: str = ""
    requires_reply: bool = True
    analysis_provider: str = ""
    reply_provider: str = ""
    reply_generated: bool = True


class EmailCreate(BaseModel):
    sender_email: str = Field(..., min_length=1, max_length=254)
    sender_name: str | None = None
    recipient: str | None = None
    subject: str = Field(..., min_length=1, max_length=500)
    body: str = Field(..., min_length=1, max_length=10000)


class EmailOut(BaseModel):
    id: int
    user_id: int
    gmail_message_id: str | None = None
    gmail_thread_id: str | None = None
    sender_name: str | None = None
    sender_email: str
    recipient: str | None = None
    subject: str
    body: str | None = None
    body_loaded: bool = False
    body_preview: str | None = None
    raw_html: str | None = None
    clean_body: str | None = None
    category: str | None = None
    received_at: datetime | None = None
    intent: str | None = None
    urgency: str | None = None
    summary: str | None = None
    spam_reason: str | None = None
    is_spam: bool = False
    is_read: bool = False
    source: str = "manual"
    created_at: datetime | None = None

    class Config:
        from_attributes = True


class MailboxCounts(BaseModel):
    inbox_total: int = 0
    inbox_unread: int = 0
    imported_total: int = 0
    inbox: int = 0
    drafts: int = 0
    urgent: int = 0
    spam: int = 0


class ReplyGenerationRequest(BaseModel):
    tone: str = "Professional"
    previous_reply: str | None = None


class ReplyGenerationResponse(BaseModel):
    reply: str
    tone: str
    source: str
    reply_generated: bool = True
    error_code: str = ""
    message: str = ""
    tone_applied: bool = True
    model: str | None = None
    fallback_reason: str | None = None
