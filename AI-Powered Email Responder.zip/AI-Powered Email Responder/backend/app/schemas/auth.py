from datetime import datetime
from pydantic import BaseModel, Field


class SignupRequest(BaseModel):
    full_name: str = Field(..., min_length=1, max_length=255)
    email: str = Field(..., min_length=1, max_length=254)
    password: str = Field(..., min_length=8, max_length=128)
    confirm_password: str = Field(..., min_length=8, max_length=128)


class LoginRequest(BaseModel):
    email: str = Field(..., min_length=1, max_length=254)
    password: str = Field(..., min_length=1, max_length=128)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"


class UserOut(BaseModel):
    id: int
    full_name: str
    email: str
    profile_picture: str | None = None
    default_tone: str = "Professional"
    preferred_reply_length: str = "Medium"
    auto_analyze: bool = True
    notifications_enabled: bool = True
    auto_gmail_sync: bool = True

    class Config:
        from_attributes = True


class UserUpdate(BaseModel):
    full_name: str | None = None
    default_tone: str | None = None
    preferred_reply_length: str | None = None
    auto_analyze: bool | None = None
    notifications_enabled: bool | None = None
    auto_gmail_sync: bool | None = None


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=8, max_length=128)


class ForgotPasswordRequest(BaseModel):
    email: str


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(..., min_length=8, max_length=128)
    confirm_password: str = Field(..., min_length=8, max_length=128)


class ForgotPasswordResponse(BaseModel):
    message: str
    development_reset_url: str | None = None


class MessageOut(BaseModel):
    message: str
