from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str
    groq_api_configured: bool
    version: str
    note: str = ""
