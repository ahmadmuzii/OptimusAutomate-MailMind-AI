from datetime import datetime
from pydantic import BaseModel


class GmailStatusOut(BaseModel):
    is_connected: bool = False
    status: str = "disconnected"
    gmail_email: str | None = None
    last_sync_at: datetime | None = None
    imported_count: int = 0
    last_error_code: str | None = None
    last_error_message: str | None = None


class SyncLogOut(BaseModel):
    id: int
    user_id: int
    started_at: datetime | None = None
    completed_at: datetime | None = None
    status: str
    messages_fetched: int = 0
    messages_imported: int = 0
    error_message: str | None = None
    trigger_type: str = "Manual"

    class Config:
        from_attributes = True


class GmailSendRequest(BaseModel):
    draft_id: int


class GmailSendResponse(BaseModel):
    success: bool
    status: str = ""
    gmail_message_id: str | None = None
    error: str | None = None


class AiHealthResponse(BaseModel):
    configured: bool
    groq_api_configured: bool
    provider: str = "groq"
    model: str | None = None
    message: str | None = None
