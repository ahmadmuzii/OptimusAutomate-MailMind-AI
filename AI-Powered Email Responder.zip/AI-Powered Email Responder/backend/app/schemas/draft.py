from datetime import datetime
from pydantic import BaseModel, Field


class DraftCreate(BaseModel):
    email_id: int | None = None
    recipient: str
    subject: str
    body: str
    tone: str = "Professional"


class DraftUpdate(BaseModel):
    recipient: str | None = None
    subject: str | None = None
    body: str | None = None
    tone: str | None = None
    status: str | None = None


class DraftOut(BaseModel):
    id: int
    user_id: int
    email_id: int | None = None
    gmail_draft_id: str | None = None
    gmail_message_id: str | None = None
    recipient: str
    subject: str
    body: str
    tone: str = "Professional"
    status: str = "Local"
    send_error: str | None = None
    sent_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None

    class Config:
        from_attributes = True
