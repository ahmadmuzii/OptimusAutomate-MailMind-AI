from pydantic import BaseModel


class ProfileOut(BaseModel):
    id: int
    full_name: str | None = None
    email: str | None = None
    profile_picture: str | None = None

    class Config:
        from_attributes = True


class ProfileUpdate(BaseModel):
    full_name: str | None = None
    email: str | None = None
