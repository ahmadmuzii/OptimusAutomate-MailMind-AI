import os
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from dotenv import load_dotenv

load_dotenv()

from app.database.session import engine
from app.database.base import Base
from app.models import User, Email, Draft, GmailConnection, PasswordResetToken, GmailSyncLog
from app.schemas.email import EmailAnalyzeRequest, EmailAnalyzeResponse
from app.core.security import get_current_user
from app.services.email_analysis_service import process_email
from app.routes.auth import router as auth_router
from app.routes.emails import router as email_router
from app.routes.drafts import router as draft_router
from app.routes.profile import router as profile_router
from app.routes.gmail import router as gmail_router
from app.routes.health import router as health_router
from app.services.scheduler_service import lifespan as scheduler_lifespan
from app.core.config import settings
from app.database.migrations import run_migrations
from app.exceptions import GmailReauthRequired, gmail_reauth_error_handler

logging.basicConfig(
    level=getattr(logging, settings.app_env, logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created")
    try:
        run_migrations()
    except Exception as e:
        logger.warning("Migrations failed (may be OK if tables are up-to-date): %s", e)
    async with scheduler_lifespan(app) as _:
        yield


app = FastAPI(
    title="MailMind AI",
    description="Email Intelligence Engine — Analyze emails and generate smart AI responses.",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_exception_handler(GmailReauthRequired, gmail_reauth_error_handler)

app.include_router(auth_router)
app.include_router(email_router)
app.include_router(draft_router)
app.include_router(profile_router)
app.include_router(gmail_router)
app.include_router(health_router)

STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
UPLOADS_DIR = os.path.join(os.path.dirname(__file__), "uploads")


@app.post("/api/analyze-email", response_model=EmailAnalyzeResponse, tags=["Analysis"])
async def analyze_email_standalone(
    req: EmailAnalyzeRequest,
    current_user: User = Depends(get_current_user),
):
    try:
        result = process_email(
            sender=req.sender,
            subject=req.subject,
            body=req.email_body,
            tone=req.tone,
        )
    except Exception as e:
        logger.exception("Email analysis failed")
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

    return EmailAnalyzeResponse(
        email_id=0,
        intent=result["intent"],
        urgency=result["urgency"],
        summary=result["summary"],
        suggested_subject=result["suggested_subject"],
        reply=result["reply"],
        is_spam=result.get("is_spam", False),
        spam_reason=result.get("spam_reason", ""),
    )


@app.get("/", include_in_schema=False)
async def serve_frontend():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path, media_type="text/html")
    return {"app": "MailMind AI", "status": "running", "version": "2.0.0"}


if os.path.exists(os.path.join(STATIC_DIR, "assets")):
    app.mount("/assets", StaticFiles(directory=os.path.join(STATIC_DIR, "assets")), name="assets")

if os.path.exists(UPLOADS_DIR):
    app.mount("/uploads", StaticFiles(directory=UPLOADS_DIR), name="uploads")
