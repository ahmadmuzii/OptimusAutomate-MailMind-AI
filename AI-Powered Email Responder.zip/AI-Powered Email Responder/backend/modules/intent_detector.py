import json
import logging
from services.groq_service import create_chat_completion, is_available
from modules.prompt_builder import build_intent_prompt, ALLOWED_INTENTS

logger = logging.getLogger(__name__)

KEYWORD_MAP = {
    "inquiry": ["how much", "how long", "what is", "tell me about", "information", "availability", "price", "cost",
                "policy", "guidance", "i would like to know", "can you provide", "interested in"],
    "complaint": ["refund", "damaged", "poor service", "unhappy", "dissatisfied", "bad experience", "not working",
                  "broken", "defective", "terrible", "worst", "angry", "frustrated", "disappointed"],
    "support": ["help", "issue", "problem", "error", "trouble", "not working", "can't log in", "password reset",
                "account access", "technical", "bug", "assistance", "how to fix"],
    "collaboration": ["partnership", "sponsorship", "collaborate", "joint", "business opportunity", "meet",
                      "partners", "cooperation", "proposal", "interested in working"],
    "feedback": ["feedback", "suggestion", "review", "opinion", "recommend", "thoughts on", "my experience"],
    "request": ["request", "approval", "permission", "leave", "please approve", "i need", "can i have",
                "authorization", "apply for", "i would like to request"],
}


def detect_intent_llm(subject: str, body: str) -> str | None:
    if not is_available():
        return None
    messages = build_intent_prompt(subject, body)
    try:
        content = create_chat_completion(
            messages=messages,
            temperature=0.1,
            max_tokens=100,
            response_format={"type": "json_object"},
        )
        data = json.loads(content)
        intent = data.get("intent", "").strip().title()
        return intent if intent in ALLOWED_INTENTS else None
    except Exception as e:
        logger.warning(f"LLM intent detection failed: {e}")
        return None


def detect_intent_rule(subject: str, body: str) -> str:
    text = (subject + " " + body).lower()
    scores = {}
    for category, keywords in KEYWORD_MAP.items():
        scores[category] = sum(1 for kw in keywords if kw in text)
    if max(scores.values()) == 0:
        return "Other"
    return max(scores, key=scores.get).title()


def detect_intent(subject: str, body: str) -> str:
    result = detect_intent_llm(subject, body)
    if result:
        return result
    return detect_intent_rule(subject, body)
