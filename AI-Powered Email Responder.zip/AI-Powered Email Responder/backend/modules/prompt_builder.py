import random

REPLY_SYSTEM_PROMPT = """You are MailMind AI, an intelligent email response assistant.

Write natural, accurate, context-aware email replies.

Rules:
- Address the sender's actual message directly.
- Never use an unrelated generic template.
- Never invent facts, approvals, dates, policies, refunds, or promises.
- Ask for missing information when needed.
- Match the selected tone exactly.
- Do not mention artificial intelligence or that you are an AI.
- Do not use an email address as a person's name.
- Use a neutral greeting ("Hello") when the sender's name is unavailable.
- Return only the final email reply text, no extra commentary."""

VARIATION_STYLES = [
    "Start by directly acknowledging the sender's request.",
    "Use a warm but concise opening.",
    "Use a direct and action-focused structure.",
    "Use a natural conversational structure.",
    "Begin by briefly summarizing what the sender needs.",
]

TONE_GUIDES = {
    "Professional": "Use formal, clear, respectful business language.",
    "Friendly": "Use warm, approachable, natural language while staying professional.",
    "Apologetic": "Acknowledge inconvenience, show empathy, offer a reasonable next step. Do not admit legal liability.",
    "Short": "Be concise and direct. Maximum 3 short paragraphs. No unnecessary wording.",
}

ALLOWED_INTENTS = [
    "Inquiry", "Complaint", "Support", "Collaboration",
    "Feedback", "Request", "Spam", "Other",
]

ALLOWED_URGENCIES = ["Low", "Medium", "High"]


def build_reply_prompt(
    sender_name: str,
    sender_email: str,
    subject: str,
    email_body: str,
    tone: str,
    intent: str,
    urgency: str,
    previous_reply: str | None = None,
) -> list[dict[str, str]]:
    greeting_name = sender_name if sender_name and "@" not in sender_name else ""
    variation = random.choice(VARIATION_STYLES)
    tone_guide = TONE_GUIDES.get(tone, TONE_GUIDES["Professional"])

    user_parts = [f"Write an email reply with the following context:\n"]
    user_parts.append(f"Sender name: {greeting_name or '(unknown)'}")
    user_parts.append(f"Sender email: {sender_email}")
    user_parts.append(f"Original subject: {subject}")
    user_parts.append(f"Original body:\n{email_body}")
    user_parts.append(f"Detected intent: {intent}")
    user_parts.append(f"Detected urgency: {urgency}")
    user_parts.append(f"Tone: {tone}")
    user_parts.append(f"Tone guidance: {tone_guide}")
    user_parts.append(f"Structure: {variation}")

    if previous_reply:
        user_parts.append(f"\nPrevious reply (write a clearly different version):\n{previous_reply}")
        user_parts.append("\nMake the new reply noticeably different in wording, sentence structure, opening, and closing.")
        user_parts.append("Preserve the same meaning, accuracy, and tone.")

    user_parts.append("\nReturn only the reply text. No JSON.")

    return [
        {"role": "system", "content": REPLY_SYSTEM_PROMPT},
        {"role": "user", "content": "\n".join(user_parts)},
    ]


def build_analysis_prompt(subject: str, body: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": "You are an email analysis assistant. Return only valid JSON."},
        {"role": "user", "content": f"""Analyze this email and return valid JSON only:

Subject: {subject}
Body: {body}

Return:
{{"intent": "one of Inquiry/Complaint/Support/Collaboration/Feedback/Request/Spam/Other",
  "urgency": "one of Low/Medium/High",
  "summary": "1-3 sentence summary of what the sender wants",
  "suggested_subject": "Re: suggested reply subject",
  "is_spam": true or false}}"""},
    ]


def build_summary_prompt(subject: str, body: str, intent: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": "You are an email summarizer. Return only valid JSON."},
        {"role": "user", "content": f"""Summarize this email in 1-3 sentences.

Subject: {subject}
Body: {body}
Intent: {intent}

Return:
{{"summary": "concise summary",
  "suggested_subject": "Re: suggested subject"}}"""},
    ]


def build_intent_prompt(subject: str, body: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": "You are an email intent classifier. Return only valid JSON."},
        {"role": "user", "content": f"""Classify the intent of this email into exactly one:
Inquiry, Complaint, Support, Collaboration, Feedback, Request, Spam, Other

Subject: {subject}
Body: {body}

Return: {{"intent": "category"}}"""},
    ]


def build_urgency_prompt(subject: str, body: str, intent: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": "You are an email urgency analyzer. Return only valid JSON."},
        {"role": "user", "content": f"""Analyze the urgency of this email as Low, Medium, or High.

Subject: {subject}
Body: {body}
Intent: {intent}

Return: {{"urgency": "level"}}"""},
    ]
