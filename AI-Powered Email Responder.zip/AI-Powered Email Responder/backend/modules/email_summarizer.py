import json
import logging
from services.groq_service import create_chat_completion, is_available
from modules.prompt_builder import build_summary_prompt

logger = logging.getLogger(__name__)


def summarize_llm(subject: str, body: str, intent: str) -> dict | None:
    if not is_available():
        return None
    messages = build_summary_prompt(subject, body, intent)
    try:
        content = create_chat_completion(
            messages=messages,
            temperature=0.2,
            max_tokens=300,
            response_format={"type": "json_object"},
        )
        data = json.loads(content)
        return {
            "summary": data.get("summary", "").strip(),
            "suggested_subject": data.get("suggested_subject", f"Re: {subject}").strip(),
        }
    except Exception as e:
        logger.warning(f"LLM summarization failed: {e}")
        return None


def summarize_rule(subject: str, body: str, intent: str) -> dict:
    body_preview = body[:200].strip()
    return {
        "summary": f"[{intent}] {body_preview}{'...' if len(body) > 200 else ''}",
        "suggested_subject": f"Re: {subject}",
    }


def summarize_email(subject: str, body: str, intent: str) -> dict:
    result = summarize_llm(subject, body, intent)
    if result:
        return result
    return summarize_rule(subject, body, intent)
