import logging
from modules.intent_detector import detect_intent
from modules.urgency_analyzer import analyze_urgency
from modules.email_summarizer import summarize_email
from modules.reply_generator import generate_reply
from modules.spam_detector import detect_spam

logger = logging.getLogger(__name__)


def process_email(sender: str, subject: str, body: str, tone: str) -> dict:
    is_spam = detect_spam(subject, body)
    if is_spam:
        return {
            "intent": "Spam",
            "urgency": "Low",
            "summary": "This message has been classified as spam.",
            "suggested_subject": "Re: " + subject,
            "reply": "",
            "is_spam": True,
        }

    intent = detect_intent(subject, body)
    urgency = analyze_urgency(subject, body, intent)
    summary_data = summarize_email(subject, body, intent)
    summary = summary_data.get("summary", "")
    suggested_subject = summary_data.get("suggested_subject", f"Re: {subject}")
    reply, _ = generate_reply(
        sender_name="",
        sender_email=sender,
        subject=subject,
        email_body=body,
        intent=intent,
        urgency=urgency,
        tone=tone,
        summary=summary,
    )

    return {
        "intent": intent,
        "urgency": urgency,
        "summary": summary,
        "suggested_subject": suggested_subject,
        "reply": reply,
        "is_spam": False,
    }
