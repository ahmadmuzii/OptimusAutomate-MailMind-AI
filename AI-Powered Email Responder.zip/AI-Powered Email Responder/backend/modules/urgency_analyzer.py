import json
import logging
from services.groq_service import create_chat_completion, is_available
from modules.prompt_builder import build_urgency_prompt, ALLOWED_URGENCIES

logger = logging.getLogger(__name__)

HIGH_KEYWORDS = ["urgent", "immediately", "asap", "deadline today", "critical", "emergency",
                 "security breach", "account compromised", "system outage", "legal deadline"]
MEDIUM_KEYWORDS = ["complaint", "refund", "support", "reschedule", "action required",
                   "leave request", "by next week", "within a few days"]


def analyze_urgency_llm(subject: str, body: str, intent: str) -> str | None:
    if not is_available():
        return None
    messages = build_urgency_prompt(subject, body, intent)
    try:
        content = create_chat_completion(
            messages=messages,
            temperature=0.1,
            max_tokens=100,
            response_format={"type": "json_object"},
        )
        data = json.loads(content)
        urgency = data.get("urgency", "").strip().title()
        return urgency if urgency in ALLOWED_URGENCIES else None
    except Exception as e:
        logger.warning(f"LLM urgency analysis failed: {e}")
        return None


def analyze_urgency_rule(subject: str, body: str, intent: str) -> str:
    text = (subject + " " + body).lower()
    if any(kw in text for kw in HIGH_KEYWORDS):
        return "High"
    if intent.title() in ["Complaint", "Support"]:
        return "Medium"
    if any(kw in text for kw in MEDIUM_KEYWORDS):
        return "Medium"
    return "Low"


def analyze_urgency(subject: str, body: str, intent: str) -> str:
    result = analyze_urgency_llm(subject, body, intent)
    if result:
        return result
    return analyze_urgency_rule(subject, body, intent)
