import json
import logging
from services.groq_service import create_chat_completion, is_available
from modules.prompt_builder import build_reply_prompt

logger = logging.getLogger(__name__)

TEMPLATES = {
    "Inquiry": "Hello,\n\nThank you for reaching out. Regarding your inquiry about {subject}, please find the information below:\n\n[Please provide the requested details here]\n\nIf you have any further questions, feel free to ask.\n\nBest regards",
    "Complaint": "Hello,\n\nThank you for bringing this to our attention. We sincerely apologize for the inconvenience caused. We take your concerns seriously and will look into this matter promptly.\n\nBest regards",
    "Support": "Hello,\n\nThank you for contacting support. We understand you are experiencing an issue with {subject}. Our team will review your case and get back to you shortly.\n\nBest regards",
    "Collaboration": "Hello,\n\nThank you for your proposal regarding {subject}. We appreciate your interest and will review the details. We will get back to you soon.\n\nBest regards",
    "Feedback": "Hello,\n\nThank you for your valuable feedback regarding {subject}. We appreciate you taking the time to share your thoughts.\n\nBest regards",
    "Request": "Hello,\n\nThank you for your request regarding {subject}. We have received it and will process it accordingly.\n\nBest regards",
    "Spam": "",
    "Other": "Hello,\n\nThank you for your message regarding {subject}. We will review it and respond accordingly.\n\nBest regards",
}


def generate_reply_groq(
    sender_name: str,
    sender_email: str,
    subject: str,
    email_body: str,
    tone: str,
    intent: str,
    urgency: str,
    previous_reply: str | None = None,
) -> str | None:
    if not is_available():
        return None
    messages = build_reply_prompt(
        sender_name=sender_name,
        sender_email=sender_email,
        subject=subject,
        email_body=email_body,
        tone=tone,
        intent=intent,
        urgency=urgency,
        previous_reply=previous_reply,
    )
    try:
        return create_chat_completion(
            messages=messages,
            temperature=0.8,
            max_tokens=800,
        )
    except Exception as e:
        logger.warning(f"Groq reply generation failed: {e}")
        return None


def generate_reply_rule(
    sender_name: str,
    sender_email: str,
    subject: str,
    email_body: str,
    tone: str,
    intent: str,
    urgency: str,
) -> str:
    greeting = "Hello"
    name = sender_name if sender_name and "@" not in sender_name else ""
    if name:
        greeting = f"Dear {name}"
    elif sender_email and "@" in sender_email:
        name_part = sender_email.split("@")[0].replace(".", " ").title()
        greeting = f"Dear {name_part}"

    body_preview = (email_body or "")[:200].strip()

    tone_closing = {
        "Professional": "Best regards",
        "Friendly": "Best regards",
        "Apologetic": "Sincerely",
        "Short": "Best regards",
    }.get(tone, "Best regards")

    template = TEMPLATES.get(intent.title(), TEMPLATES["Other"])
    if not template:
        return ""
    reply = template.format(sender=name or sender_email, subject=subject).strip()

    return f"{greeting},\n\nRegarding your message about \"{subject}\":\n\nI have reviewed your email. Based on the content: {body_preview}\n\n{reply}\n\n{tone_closing}"


def generate_reply(
    sender_name: str,
    sender_email: str,
    subject: str,
    email_body: str,
    intent: str,
    urgency: str,
    tone: str,
    summary: str = "",
    previous_reply: str | None = None,
) -> tuple[str, str]:
    result = generate_reply_groq(
        sender_name=sender_name,
        sender_email=sender_email,
        subject=subject,
        email_body=email_body,
        tone=tone,
        intent=intent,
        urgency=urgency,
        previous_reply=previous_reply,
    )
    if result:
        logger.info("Reply generated using Groq")
        return result, "groq"
    logger.warning("Groq failed, using fallback")
    fallback = generate_reply_rule(
        sender_name=sender_name,
        sender_email=sender_email,
        subject=subject,
        email_body=email_body,
        tone=tone,
        intent=intent,
        urgency=urgency,
    )
    return fallback, "fallback"
