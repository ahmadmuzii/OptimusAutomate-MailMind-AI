import os
import base64
import logging
from email.mime.text import MIMEText

from models import User, Draft
from services.gmail_service import get_gmail_service

logger = logging.getLogger(__name__)


def create_gmail_draft(user: User, draft: Draft) -> str:
    service = get_gmail_service(user.id)
    if not service:
        raise Exception("Gmail not connected. Please connect Gmail first.")

    mime_message = MIMEText(draft.body)
    mime_message["To"] = draft.recipient
    mime_message["Subject"] = draft.subject
    mime_message["From"] = "me"

    raw = base64.urlsafe_b64encode(mime_message.as_bytes()).decode("utf-8")

    gmail_draft = {"message": {"raw": raw}}
    created = service.users().drafts().create(userId="me", body=gmail_draft).execute()
    logger.info(f"Gmail draft created with id: {created.get('id')}")
    return created.get("id")
