import json
import logging
from services.groq_service import create_chat_completion, is_available

logger = logging.getLogger(__name__)

SPAM_TRIGGERS = [
    "buy now", "click here", "free money", "congratulations you won", "limited offer",
    "act now", "risk free", "no obligation", "exclusive deal", "earn money fast",
    "work from home", "make money", "double your", "increase your", "cash bonus",
]


def detect_spam_llm(subject: str, body: str) -> bool | None:
    if not is_available():
        return None
    messages = [
        {"role": "system", "content": "You are a spam detector. Return only valid JSON."},
        {"role": "user", "content": f"""Determine if this email is spam. Return true if it appears deceptive, promotional, irrelevant, malicious, or unsolicited.

Subject: {subject}
Body: {body}

Return: {{"is_spam": true/false}}"""},
    ]
    try:
        content = create_chat_completion(
            messages=messages,
            temperature=0.1,
            max_tokens=100,
            response_format={"type": "json_object"},
        )
        data = json.loads(content)
        return bool(data.get("is_spam", False))
    except Exception as e:
        logger.warning(f"LLM spam detection failed: {e}")
        return None


def detect_spam_rule(subject: str, body: str) -> bool:
    text = (subject + " " + body).lower()
    matches = sum(1 for trigger in SPAM_TRIGGERS if trigger in text)
    return matches >= 2


def detect_spam(subject: str, body: str) -> bool:
    result = detect_spam_llm(subject, body)
    if result is not None:
        return result
    return detect_spam_rule(subject, body)
