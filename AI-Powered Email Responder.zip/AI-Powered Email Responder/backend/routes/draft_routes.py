import logging
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import desc
from database import get_db
from models import User, Draft
from schemas import DraftCreate, DraftOut, DraftUpdate
from auth import get_current_user

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Drafts"])


@router.get("/api/drafts", response_model=list[DraftOut])
def list_drafts(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return (
        db.query(Draft)
        .filter(Draft.user_id == current_user.id)
        .order_by(desc(Draft.created_at))
        .all()
    )


@router.get("/api/drafts/{draft_id}", response_model=DraftOut)
def get_draft(
    draft_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    draft = (
        db.query(Draft)
        .filter(Draft.id == draft_id, Draft.user_id == current_user.id)
        .first()
    )
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")
    return draft


@router.post("/api/drafts", response_model=DraftOut, status_code=status.HTTP_201_CREATED)
def create_draft(
    data: DraftCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    draft = Draft(
        user_id=current_user.id,
        email_id=data.email_id,
        recipient=data.recipient,
        subject=data.subject,
        body=data.body,
        tone=data.tone,
        status="Local",
    )
    db.add(draft)
    db.commit()
    db.refresh(draft)
    return draft


@router.put("/api/drafts/{draft_id}", response_model=DraftOut)
def update_draft(
    draft_id: int,
    data: DraftUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    draft = (
        db.query(Draft)
        .filter(Draft.id == draft_id, Draft.user_id == current_user.id)
        .first()
    )
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")
    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(draft, key, value)
    db.commit()
    db.refresh(draft)
    return draft


@router.delete("/api/drafts/{draft_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_draft(
    draft_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    draft = (
        db.query(Draft)
        .filter(Draft.id == draft_id, Draft.user_id == current_user.id)
        .first()
    )
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")
    db.delete(draft)
    db.commit()


@router.post("/api/drafts/{draft_id}/create-gmail-draft")
def create_gmail_draft(
    draft_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    draft = (
        db.query(Draft)
        .filter(Draft.id == draft_id, Draft.user_id == current_user.id)
        .first()
    )
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")
    from services.gmail_service import push_draft_to_gmail
    try:
        gmail_draft_id = push_draft_to_gmail(current_user.id, draft, db)
        draft.gmail_draft_id = gmail_draft_id
        draft.status = "Gmail"
        db.commit()
        return {"draft_id": draft.id, "gmail_draft_id": gmail_draft_id, "status": "Gmail"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create Gmail draft: {str(e)}")
