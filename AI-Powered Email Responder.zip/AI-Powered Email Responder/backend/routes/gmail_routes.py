import os
import logging
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from database import get_db
from models import User
from schemas import GmailStatusOut as GmailStatus
from auth import get_current_user
from services.gmail_service import GmailService, oauth_states, FRONTEND_URL

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Gmail"])


def _get_gmail_service(current_user: User, db: Session) -> GmailService:
    return GmailService(current_user.id, db)


@router.get("/api/gmail/status", response_model=GmailStatus)
def gmail_status(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    svc = _get_gmail_service(current_user, db)
    conn = svc.get_connection()
    if not conn or not conn.is_connected:
        return GmailStatus(is_connected=False, imported_count=0)
    return GmailStatus(
        is_connected=True,
        gmail_email=conn.gmail_email,
        last_sync_at=conn.last_sync_at,
        imported_count=svc.count_imported(),
    )


@router.get("/api/gmail/connect")
def gmail_connect(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    svc = _get_gmail_service(current_user, db)
    auth_url = svc.get_auth_url()
    return {"auth_url": auth_url}


@router.get("/api/gmail/callback")
def gmail_callback(
    code: str | None = Query(None),
    state: str | None = Query(None),
    error: str | None = Query(None),
):
    if error or not code:
        logger.warning(f"Gmail OAuth error returned from Google: {error}")
        return RedirectResponse(
            f"{FRONTEND_URL}/integrations?gmail=error",
            status_code=303,
        )

    if not state or state not in oauth_states:
        logger.warning("Gmail OAuth callback: invalid or missing state")
        return RedirectResponse(
            f"{FRONTEND_URL}/integrations?gmail=error",
            status_code=303,
        )

    user_id = oauth_states.pop(state, None)
    if user_id is None:
        logger.warning("Gmail OAuth callback: state already consumed or invalid")
        return RedirectResponse(
            f"{FRONTEND_URL}/integrations?gmail=error",
            status_code=303,
        )

    db = next(get_db())
    try:
        svc = GmailService(user_id, db)
        svc.handle_callback(code)
        logger.info(f"Gmail connected for user {user_id}")
        return RedirectResponse(
            f"{FRONTEND_URL}/integrations?gmail=connected",
            status_code=303,
        )
    except Exception as e:
        logger.error(f"Gmail OAuth callback failed for user {user_id}: {e}")
        return RedirectResponse(
            f"{FRONTEND_URL}/integrations?gmail=error",
            status_code=303,
        )
    finally:
        db.close()


@router.post("/api/gmail/sync")
def gmail_sync(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    svc = _get_gmail_service(current_user, db)
    result = svc.sync_emails()
    return result


@router.post("/api/gmail/disconnect")
def gmail_disconnect(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    svc = _get_gmail_service(current_user, db)
    svc.disconnect()
    return {"message": "Gmail disconnected successfully"}


@router.post("/api/gmail/create-draft")
def gmail_create_draft(
    draft_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    from models import Draft

    draft = (
        db.query(Draft)
        .filter(Draft.id == draft_id, Draft.user_id == current_user.id)
        .first()
    )
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")

    svc = _get_gmail_service(current_user, db)
    gmail_draft_id = svc.create_draft(
        to=draft.recipient or "",
        subject=draft.subject or "",
        body=draft.body or "",
    )
    draft.gmail_draft_id = gmail_draft_id
    draft.status = "Gmail"
    db.commit()
    return {"gmail_draft_id": gmail_draft_id}
