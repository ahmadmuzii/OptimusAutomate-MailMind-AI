import logging
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import desc
from database import get_db
from models import User, Email, Draft
from schemas import EmailOut, EmailCreate, MailboxCounts, EmailAnalyzeResponse, ReplyGenerationRequest, ReplyGenerationResponse
from auth import get_current_user
from modules.email_processor import process_email
from modules.reply_generator import generate_reply as generate_reply_module

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Emails"])


@router.get("/api/emails", response_model=list[EmailOut])
def list_emails(
    folder: str | None = Query(None),
    search: str | None = Query(None),
    intent: str | None = Query(None),
    urgency: str | None = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Email).filter(Email.user_id == current_user.id).order_by(desc(Email.received_at))
    if folder == "inbox":
        query = query.filter(Email.is_spam == False)
    elif folder == "urgent":
        query = query.filter(Email.urgency == "High")
    elif folder == "spam":
        query = query.filter(Email.is_spam == True)
    if search:
        like = f"%{search}%"
        query = query.filter(
            Email.subject.ilike(like) | Email.body.ilike(like) | Email.sender_email.ilike(like)
        )
    if intent:
        query = query.filter(Email.intent.ilike(f"%{intent}%"))
    if urgency:
        query = query.filter(Email.urgency.ilike(f"%{urgency}%"))
    offset = (page - 1) * limit
    return query.offset(offset).limit(limit).all()


@router.get("/api/emails/{email_id}", response_model=EmailOut)
def get_email(
    email_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    if not email.is_read:
        email.is_read = True
        db.commit()
    return email


@router.post("/api/emails/manual", response_model=EmailOut, status_code=status.HTTP_201_CREATED)
def create_manual_email(
    data: EmailCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = Email(
        user_id=current_user.id,
        sender_email=data.sender_email,
        sender_name=data.sender_name,
        recipient=data.recipient,
        subject=data.subject,
        body=data.body,
        body_preview=data.body[:200] if data.body else None,
        source="manual",
    )
    db.add(email)
    db.commit()
    db.refresh(email)
    return email


@router.post("/api/emails/{email_id}/analyze", response_model=EmailAnalyzeResponse)
def analyze_email(
    email_id: int,
    tone: str = Query("Professional"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    try:
        result = process_email(
            sender=email.sender_email,
            subject=email.subject,
            body=email.body,
            tone=tone,
        )
    except Exception as e:
        logger.exception("Email processing failed")
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")
    email.intent = result["intent"]
    email.urgency = result["urgency"]
    email.summary = result["summary"]
    email.is_spam = result.get("is_spam", False)
    if result.get("is_spam"):
        email.spam_reason = "Detected as spam by AI"
    db.commit()
    return EmailAnalyzeResponse(
        email_id=email.id,
        intent=result["intent"],
        urgency=result["urgency"],
        summary=result["summary"],
        suggested_subject=result["suggested_subject"],
        reply=result["reply"],
    )


@router.post("/api/emails/{email_id}/generate-reply", response_model=ReplyGenerationResponse)
def generate_reply(
    email_id: int,
    body: ReplyGenerationRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    try:
        reply_text, source = generate_reply_module(
            sender_name=email.sender_name or "",
            sender_email=email.sender_email,
            subject=email.subject,
            email_body=email.body,
            intent=email.intent or "Other",
            urgency=email.urgency or "Low",
            tone=body.tone,
            previous_reply=body.previous_reply,
        )
    except Exception as e:
        logger.exception("Reply generation failed")
        raise HTTPException(status_code=500, detail=f"Reply generation failed: {str(e)}")
    return ReplyGenerationResponse(
        reply=reply_text,
        tone=body.tone,
        source=source,
    )


@router.put("/api/emails/{email_id}/read", response_model=EmailOut)
def toggle_read(
    email_id: int,
    is_read: bool = Query(True),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    email.is_read = is_read
    db.commit()
    return email


@router.put("/api/emails/{email_id}/spam", response_model=EmailOut)
def toggle_spam(
    email_id: int,
    is_spam: bool = Query(True),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    email.is_spam = is_spam
    db.commit()
    return email


@router.delete("/api/emails/{email_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_email(
    email_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    email = db.query(Email).filter(Email.id == email_id, Email.user_id == current_user.id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    db.delete(email)
    db.commit()


@router.get("/api/mailbox/counts", response_model=MailboxCounts)
def get_mailbox_counts(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    base = db.query(Email).filter(Email.user_id == current_user.id)
    inbox = base.filter(Email.is_spam == False).count()
    spam = base.filter(Email.is_spam == True).count()
    urgent = base.filter(Email.urgency == "High").count()
    drafts = db.query(Draft).filter(Draft.user_id == current_user.id).count()
    return MailboxCounts(inbox=inbox, drafts=drafts, urgent=urgent, spam=spam)
