import os
import secrets
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database import get_db
from models import User
from schemas import (
    SignupRequest, LoginRequest, TokenResponse, UserOut,
    UserUpdate, ChangePasswordRequest, ForgotPasswordRequest,
    ResetPasswordRequest, MessageOut,
)
from auth import hash_password, verify_password, create_access_token, get_current_user

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/auth", tags=["Authentication"])

reset_tokens: dict = {}


@router.post("/signup", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def signup(request: SignupRequest, db: Session = Depends(get_db)):
    if request.password != request.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    existing = db.query(User).filter(User.email == request.email).first()
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")

    user = User(
        full_name=request.full_name,
        email=request.email,
        password_hash=hash_password(request.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = create_access_token({"sub": str(user.id)})
    return TokenResponse(
        access_token=token,
        token_type="bearer",
        user=UserOut.model_validate(user),
    )


@router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == request.email, User.is_active == True).first()
    if not user or not verify_password(request.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token({"sub": str(user.id)})
    return TokenResponse(
        access_token=token,
        token_type="bearer",
        user=UserOut.model_validate(user),
    )


@router.get("/me", response_model=UserOut)
async def get_me(current_user: User = Depends(get_current_user)):
    return UserOut.model_validate(current_user)


@router.post("/logout", response_model=MessageOut)
async def logout(current_user: User = Depends(get_current_user)):
    return MessageOut(message="Logged out successfully")


@router.put("/profile", response_model=UserOut)
async def update_profile(
    update: UserUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if update.full_name is not None:
        current_user.full_name = update.full_name
    if update.default_tone is not None:
        current_user.default_tone = update.default_tone
    if update.preferred_reply_length is not None:
        current_user.preferred_reply_length = update.preferred_reply_length
    if update.auto_analyze is not None:
        current_user.auto_analyze = update.auto_analyze
    if update.notifications_enabled is not None:
        current_user.notifications_enabled = update.notifications_enabled
    current_user.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(current_user)
    return UserOut.model_validate(current_user)


@router.post("/change-password", response_model=MessageOut)
async def change_password(
    request: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not verify_password(request.current_password, current_user.password_hash):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    current_user.password_hash = hash_password(request.new_password)
    current_user.updated_at = datetime.now(timezone.utc)
    db.commit()
    return MessageOut(message="Password changed successfully")


@router.post("/forgot-password", response_model=MessageOut)
async def forgot_password(request: ForgotPasswordRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == request.email).first()
    if user:
        token = secrets.token_urlsafe(32)
        reset_tokens[token] = {"user_id": user.id, "expires": datetime.now(timezone.utc).timestamp() + 3600}
    return MessageOut(message="If the email exists, a reset link has been sent")


@router.post("/reset-password", response_model=MessageOut)
async def reset_password(request: ResetPasswordRequest, db: Session = Depends(get_db)):
    data = reset_tokens.get(request.token)
    if not data:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")
    if data["expires"] < datetime.now(timezone.utc).timestamp():
        del reset_tokens[request.token]
        raise HTTPException(status_code=400, detail="Reset token has expired")
    if request.new_password != request.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    user = db.query(User).filter(User.id == data["user_id"]).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.password_hash = hash_password(request.new_password)
    user.updated_at = datetime.now(timezone.utc)
    db.commit()
    del reset_tokens[request.token]
    return MessageOut(message="Password reset successfully")
