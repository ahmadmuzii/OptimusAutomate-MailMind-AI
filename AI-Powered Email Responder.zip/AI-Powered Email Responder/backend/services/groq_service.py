import os
import logging
from dotenv import load_dotenv
from groq import Groq

load_dotenv()

logger = logging.getLogger(__name__)

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
FALLBACK_MODEL = "mixtral-8x7b-32768"

_client = None
_available = False


def _get_client() -> Groq | None:
    global _client
    if _client is not None:
        return _client
    if not GROQ_API_KEY:
        logger.warning("GROQ_API_KEY is not set. LLM features will fall back to rule-based.")
        return None
    if GROQ_API_KEY.startswith("gsk_your"):
        logger.warning("GROQ_API_KEY still has placeholder value. LLM features will fall back.")
        return None
    try:
        _client = Groq(api_key=GROQ_API_KEY)
        logger.info("Groq client initialized.")
        return _client
    except Exception as e:
        logger.warning(f"Failed to initialize Groq client: {e}")
        return None


def is_available() -> bool:
    return _get_client() is not None


def create_chat_completion(
    messages: list[dict[str, str]],
    temperature: float = 0.7,
    max_tokens: int = 600,
    response_format: dict | None = None,
    model: str | None = None,
) -> str:
    client = _get_client()
    if not client:
        raise RuntimeError("Groq client not available")

    actual_model = model or GROQ_MODEL
    kwargs: dict = {
        "model": actual_model,
        "messages": messages,
        "temperature": temperature,
        "top_p": 0.95,
        "max_tokens": max_tokens,
    }
    if response_format:
        kwargs["response_format"] = response_format

    try:
        response = client.chat.completions.create(**kwargs)
    except Exception as e:
        err_msg = str(e).lower()
        if "model_not_found" in err_msg or "not found" in err_msg or "does not exist" in err_msg:
            if actual_model != FALLBACK_MODEL:
                logger.warning(f"Model '{actual_model}' not found, trying fallback '{FALLBACK_MODEL}'")
                kwargs["model"] = FALLBACK_MODEL
                try:
                    response = client.chat.completions.create(**kwargs)
                except Exception as e2:
                    raise RuntimeError(f"Groq API error (both models failed): {e2}") from e2
            else:
                raise RuntimeError(f"Groq API error: {e}") from e
        else:
            raise RuntimeError(f"Groq API error: {e}") from e

    content = response.choices[0].message.content
    if not content or not content.strip():
        raise RuntimeError("Groq returned an empty response")
    return content.strip()
