import os
import json
import logging
import base64
import secrets
from datetime import datetime, timezone
from typing import Optional
from fastapi import HTTPException
from sqlalchemy.orm import Session
from models import GmailConnection, Email

logger = logging.getLogger(__name__)

SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.compose",
]

REDIRECT_URI = os.getenv(
    "GMAIL_REDIRECT_URI",
    "http://localhost:8000/api/gmail/callback",
)

FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:3000")


def _get_google_credentials():
    from google.oauth2.credentials import Credentials
    return Credentials


def _get_google_request():
    from google.auth.transport.requests import Request
    return Request


def _get_google_build():
    from googleapiclient.discovery import build
    return build


def _get_google_flow():
    from google_auth_oauthlib.flow import Flow
    return Flow


def _create_google_flow():
    Flow = _get_google_flow()
    return Flow.from_client_secrets_file(
        _find_client_secret(),
        scopes=SCOPES,
        redirect_uri=REDIRECT_URI,
        autogenerate_code_verifier=False,
    )


def _find_client_secret() -> str:
    creds_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "credentials")
    env_path = os.getenv(
        "GMAIL_CLIENT_SECRET_FILE",
        os.path.join(creds_dir, "client_secret.json"),
    )
    if os.path.exists(env_path):
        return env_path
    for f in os.listdir(creds_dir):
        if f.endswith(".json"):
            return os.path.join(creds_dir, f)
    return env_path


# In-memory OAuth state store for demo. {state: user_id}
oauth_states: dict = {}


class GmailService:
    def __init__(self, user_id: int, db: Session):
        self.user_id = user_id
        self.db = db
        self._secret_file = _find_client_secret()

    def get_connection(self) -> Optional[GmailConnection]:
        return (
            self.db.query(GmailConnection)
            .filter(GmailConnection.user_id == self.user_id)
            .first()
        )

    def _get_credentials(self) -> Optional[object]:
        Credentials = _get_google_credentials()
        GoogleRequest = _get_google_request()
        conn = self.get_connection()
        if not conn or not conn.is_connected:
            return None
        creds = Credentials(
            token=conn.access_token,
            refresh_token=conn.refresh_token,
            token_uri="https://oauth2.googleapis.com/token",
            client_id=self._get_client_id(),
            client_secret=self._get_client_secret(),
            scopes=conn.scopes.split(",") if conn.scopes else SCOPES,
        )
        if creds.expired and creds.refresh_token:
            try:
                creds.refresh(GoogleRequest())
                conn.access_token = creds.token
                conn.token_expiry = creds.expiry
                self.db.commit()
            except Exception as e:
                logger.warning(f"Token refresh failed: {e}")
                return None
        return creds

    def _get_client_id(self) -> str:
        try:
            with open(self._secret_file) as f:
                data = json.load(f)
            return (
                data.get("installed", {}).get("client_id", "")
                or data.get("web", {}).get("client_id", "")
            )
        except (FileNotFoundError, json.JSONDecodeError):
            return ""

    def _get_client_secret(self) -> str:
        try:
            with open(self._secret_file) as f:
                data = json.load(f)
            return (
                data.get("installed", {}).get("client_secret", "")
                or data.get("web", {}).get("client_secret", "")
            )
        except (FileNotFoundError, json.JSONDecodeError):
            return ""

    def is_configured(self) -> bool:
        return os.path.exists(self._secret_file)

    def get_auth_url(self) -> str:
        if not self.is_configured():
            raise HTTPException(
                status_code=400,
                detail="Gmail not configured: client_secret.json not found",
            )
        state = secrets.token_urlsafe(32)
        oauth_states[state] = self.user_id
        flow = _create_google_flow()
        auth_url, _ = flow.authorization_url(
            access_type="offline",
            include_granted_scopes="true",
            prompt="consent",
            state=state,
        )
        return auth_url

    def handle_callback(self, code: str) -> dict:
        flow = _create_google_flow()
        flow.fetch_token(code=code)
        creds = flow.credentials
        gmail_email = self._get_gmail_email(creds)
        conn = self.get_connection()
        if conn:
            conn.access_token = creds.token
            conn.refresh_token = creds.refresh_token or conn.refresh_token
            conn.token_expiry = creds.expiry
            conn.gmail_email = gmail_email
            conn.scopes = ",".join(creds.scopes or SCOPES)
            conn.is_connected = True
        else:
            conn = GmailConnection(
                user_id=self.user_id,
                gmail_email=gmail_email,
                access_token=creds.token,
                refresh_token=creds.refresh_token or "",
                token_expiry=creds.expiry,
                scopes=",".join(creds.scopes or SCOPES),
                is_connected=True,
            )
            self.db.add(conn)
        self.db.commit()
        return {"status": "connected", "email": gmail_email}

    def _get_gmail_email(self, creds: object) -> str:
        build = _get_google_build()
        try:
            service = build("gmail", "v1", credentials=creds)
            profile = service.users().getProfile(userId="me").execute()
            return profile.get("emailAddress", "unknown@unknown.com")
        except Exception as e:
            logger.warning(f"Failed to get Gmail profile: {e}")
            return "unknown@unknown.com"

    def sync_emails(self, max_results: int = 50) -> dict:
        build = _get_google_build()
        creds = self._get_credentials()
        if not creds:
            raise HTTPException(status_code=401, detail="Gmail not connected")
        service = build("gmail", "v1", credentials=creds)
        results = (
            service.users()
            .messages()
            .list(userId="me", maxResults=max_results)
            .execute()
        )
        messages = results.get("messages", [])
        synced = 0
        for msg in messages:
            try:
                full = (
                    service.users()
                    .messages()
                    .get(userId="me", id=msg["id"])
                    .execute()
                )
                existing = (
                    self.db.query(Email)
                    .filter(
                        Email.gmail_message_id == msg["id"],
                        Email.user_id == self.user_id,
                    )
                    .first()
                )
                if existing:
                    continue
                headers = {
                    h["name"]: h["value"]
                    for h in full.get("payload", {}).get("headers", [])
                }
                subject = headers.get("Subject", "(No Subject)")
                sender = headers.get("From", "unknown@unknown.com")
                sender_name = None
                sender_email = sender
                if "<" in sender and ">" in sender:
                    parts = sender.split("<")
                    sender_name = parts[0].strip().strip('"')
                    sender_email = parts[1].rstrip(">")
                body_text = self._extract_body(full)
                internal_date = int(full.get("internalDate", "0"))
                received_at = (
                    datetime.fromtimestamp(internal_date / 1000, tz=timezone.utc)
                    if internal_date
                    else datetime.now(timezone.utc)
                )
                email = Email(
                    user_id=self.user_id,
                    gmail_message_id=msg["id"],
                    gmail_thread_id=full.get("threadId"),
                    sender_name=sender_name,
                    sender_email=sender_email,
                    recipient=headers.get("To"),
                    subject=subject,
                    body=body_text,
                    body_preview=body_text[:200] if body_text else None,
                    received_at=received_at,
                    is_read="UNREAD" not in full.get("labelIds", []),
                    source="gmail",
                )
                self.db.add(email)
                synced += 1
            except Exception as e:
                logger.warning(f"Failed to sync message {msg['id']}: {e}")
        conn = self.get_connection()
        if conn:
            conn.last_sync_at = datetime.now(timezone.utc)
        self.db.commit()
        return {"status": "success", "synced": synced, "total": len(messages)}

    def _extract_body(self, msg: dict) -> str:
        payload = msg.get("payload", {})
        parts = payload.get("parts", [])
        if not parts:
            data = payload.get("body", {}).get("data", "")
            if data:
                try:
                    return base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
                except Exception:
                    return "[Unable to decode email body]"
            return ""
        for part in parts:
            if part.get("mimeType") == "text/plain":
                data = part.get("body", {}).get("data", "")
                if data:
                    try:
                        return base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
                    except Exception:
                        pass
            if part.get("mimeType") == "text/html" and not any(
                p.get("mimeType") == "text/plain" for p in parts
            ):
                data = part.get("body", {}).get("data", "")
                if data:
                    try:
                        return base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
                    except Exception:
                        pass
        return ""

    def create_draft(self, to: str, subject: str, body: str) -> str:
        build = _get_google_build()
        creds = self._get_credentials()
        if not creds:
            raise HTTPException(status_code=401, detail="Gmail not connected")
        service = build("gmail", "v1", credentials=creds)
        message = (
            f"To: {to}\r\n"
            f"Subject: {subject}\r\n"
            f"Content-Type: text/plain; charset=UTF-8\r\n\r\n"
            f"{body}"
        )
        encoded = base64.urlsafe_b64encode(message.encode("utf-8")).decode("utf-8")
        draft = (
            service.users()
            .drafts()
            .create(userId="me", body={"message": {"raw": encoded}})
            .execute()
        )
        return draft.get("id", "")

    def disconnect(self):
        conn = self.get_connection()
        if conn:
            conn.is_connected = False
            conn.access_token = ""
            conn.refresh_token = ""
            conn.token_expiry = None
            conn.gmail_email = ""
            self.db.commit()

    def count_imported(self) -> int:
        return (
            self.db.query(Email)
            .filter(Email.user_id == self.user_id, Email.source == "gmail")
            .count()
        )


def push_draft_to_gmail(user_id: int, draft, db: Session) -> str:
    svc = GmailService(user_id, db)
    return svc.create_draft(draft.recipient, draft.subject, draft.body)
