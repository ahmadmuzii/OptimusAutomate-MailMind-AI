import os
import uuid
import logging
from fastapi import UploadFile, HTTPException
from sqlalchemy.orm import Session
from models import User
from database import SessionLocal

logger = logging.getLogger(__name__)

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads", "profile_pictures")
ALLOWED_TYPES = {"image/png", "image/jpg", "image/jpeg", "image/webp"}
MAX_SIZE = 5 * 1024 * 1024


def get_or_create_profile(user_id: int) -> User:
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        return user
    finally:
        db.close()


def update_profile(user_id: int, full_name: str | None = None, email: str | None = None) -> User:
    db = SessionLocal()
    try:
        user = get_or_create_profile(user_id)
        if full_name is not None:
            user.full_name = full_name
        if email is not None:
            existing = db.query(User).filter(User.email == email, User.id != user_id).first()
            if existing:
                raise HTTPException(status_code=409, detail="Email already in use")
            user.email = email
        db.commit()
        db.refresh(user)
        return user
    finally:
        db.close()


async def upload_picture(user_id: int, file: UploadFile) -> User:
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(status_code=400, detail="Only PNG, JPG, JPEG, and WebP are allowed.")
    contents = await file.read()
    if len(contents) > MAX_SIZE:
        raise HTTPException(status_code=400, detail="File size must be under 5 MB.")
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    ext = os.path.splitext(file.filename)[1] if file.filename else ".jpg"
    safe_name = f"{uuid.uuid4()}{ext}"
    file_path = os.path.join(UPLOAD_DIR, safe_name)
    with open(file_path, "wb") as f:
        f.write(contents)
    db = SessionLocal()
    try:
        user = get_or_create_profile(user_id)
        old_path = user.profile_picture
        if old_path:
            full_old = os.path.join(os.path.dirname(os.path.dirname(__file__)), old_path)
            if os.path.exists(full_old):
                try:
                    os.remove(full_old)
                except OSError:
                    pass
        user.profile_picture = f"uploads/profile_pictures/{safe_name}"
        db.commit()
        return user
    finally:
        db.close()


def delete_picture(user_id: int) -> User:
    db = SessionLocal()
    try:
        user = get_or_create_profile(user_id)
        if user.profile_picture:
            path = os.path.join(os.path.dirname(os.path.dirname(__file__)), user.profile_picture)
            if os.path.exists(path):
                try:
                    os.remove(path)
                except OSError:
                    pass
            user.profile_picture = None
            db.commit()
        return user
    finally:
        db.close()
