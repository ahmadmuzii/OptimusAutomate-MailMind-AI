from datetime import datetime, timezone
from sqlalchemy import (
    Column, String, Text, Boolean, DateTime, Integer, ForeignKey, UniqueConstraint
)
from sqlalchemy.orm import relationship
from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    full_name = Column(String(255), nullable=False)
    email = Column(String(254), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    profile_picture = Column(String(500), nullable=True)
    default_tone = Column(String(50), default="Professional")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    emails = relationship("Email", back_populates="user", cascade="all, delete-orphan")
    drafts = relationship("Draft", back_populates="user", cascade="all, delete-orphan")
    gmail_connection = relationship(
        "GmailConnection", uselist=False, back_populates="user", cascade="all, delete-orphan"
    )


class Email(Base):
    __tablename__ = "emails"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    gmail_message_id = Column(String(255), nullable=True, unique=True)
    gmail_thread_id = Column(String(255), nullable=True)
    sender_name = Column(String(255), nullable=True)
    sender_email = Column(String(254), nullable=False)
    recipient = Column(String(254), nullable=True)
    subject = Column(String(500), nullable=False)
    body = Column(Text, nullable=False)
    body_preview = Column(String(200), nullable=True)
    received_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    intent = Column(String(50), nullable=True)
    urgency = Column(String(20), nullable=True)
    summary = Column(Text, nullable=True)
    spam_reason = Column(String(255), nullable=True)
    is_spam = Column(Boolean, default=False)
    is_read = Column(Boolean, default=False)
    source = Column(String(50), default="manual")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    user = relationship("User", back_populates="emails")
    drafts = relationship("Draft", back_populates="email", cascade="all, delete-orphan")


class Draft(Base):
    __tablename__ = "drafts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    email_id = Column(Integer, ForeignKey("emails.id"), nullable=True)
    gmail_draft_id = Column(String(255), nullable=True)
    recipient = Column(String(254), nullable=False)
    subject = Column(String(500), nullable=False)
    body = Column(Text, nullable=False)
    tone = Column(String(50), default="Professional")
    status = Column(String(50), default="Local")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    user = relationship("User", back_populates="drafts")
    email = relationship("Email", back_populates="drafts")


class GmailConnection(Base):
    __tablename__ = "gmail_connections"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    gmail_email = Column(String(254), nullable=False)
    access_token = Column(Text, nullable=False)
    refresh_token = Column(Text, nullable=False)
    token_expiry = Column(DateTime, nullable=True)
    scopes = Column(String(500), nullable=True)
    last_history_id = Column(String(255), nullable=True)
    last_sync_at = Column(DateTime, nullable=True)
    is_connected = Column(Boolean, default=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    user = relationship("User", back_populates="gmail_connection")
