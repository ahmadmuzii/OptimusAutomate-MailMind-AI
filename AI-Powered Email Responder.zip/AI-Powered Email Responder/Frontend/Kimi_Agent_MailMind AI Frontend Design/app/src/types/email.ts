export type ToneType = 'Professional' | 'Friendly' | 'Apologetic' | 'Short';

export interface EmailFormData {
  sender: string;
  sender_name?: string;
  subject: string;
  email_body: string;
  tone: ToneType;
}
