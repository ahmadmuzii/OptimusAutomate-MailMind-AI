export interface AnalysisResult {
  email_id: number;
  intent: string;
  urgency: string;
  summary: string;
  suggested_subject: string;
  reply: string;
  is_spam?: boolean;
  spam_reason?: string;
  category?: string;
  requires_reply?: boolean;
  analysis_provider?: string;
  reply_provider?: string;
  reply_generated?: boolean;
}

export interface HealthResponse {
  status?: string;
  groq_api_configured?: boolean;
  configured?: boolean;
  version?: string;
  note?: string;
  provider?: string;
  model?: string | null;
  message?: string | null;
}

export interface EmailItem {
  id: number;
  user_id: number;
  gmail_message_id: string | null;
  gmail_thread_id: string | null;
  sender_name: string | null;
  sender_email: string;
  recipient: string | null;
  subject: string;
  body: string | null;
  body_loaded: boolean;
  body_preview: string | null;
  raw_html: string | null;
  clean_body: string | null;
  category: string | null;
  received_at: string | null;
  intent: string | null;
  urgency: string | null;
  summary: string | null;
  spam_reason: string | null;
  is_spam: boolean;
  is_read: boolean;
  source: string;
  created_at: string | null;
}

export interface MailboxCounts {
  inbox_total: number;
  inbox_unread: number;
  imported_total: number;
  inbox: number;
  drafts: number;
  urgent: number;
  spam: number;
}

export interface DraftData {
  id: number;
  user_id: number;
  email_id: number | null;
  gmail_draft_id: string | null;
  gmail_message_id: string | null;
  recipient: string;
  subject: string;
  body: string;
  tone: string;
  status: string;
  send_error: string | null;
  sent_at: string | null;
  created_at: string | null;
  updated_at: string | null;
}

export interface ProfileData {
  id: number;
  full_name: string | null;
  email: string | null;
  profile_picture: string | null;
}

export interface AuthUser {
  id: number;
  full_name: string;
  email: string;
  profile_picture: string | null;
  default_tone: string;
  preferred_reply_length: string;
  auto_analyze: boolean;
  notifications_enabled: boolean;
  auto_gmail_sync: boolean;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: AuthUser;
}

export interface SettingsData {
  default_tone: string;
  preferred_reply_length: string;
  auto_analyze: boolean;
  notifications_enabled: boolean;
}

export interface GmailStatus {
  is_connected: boolean;
  status: 'connected' | 'reauth_required' | 'disconnected' | 'error';
  gmail_email: string | null;
  last_sync_at: string | null;
  imported_count: number;
  last_error_code: string | null;
  last_error_message: string | null;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  pages: number;
}

export interface GmailSendResult {
  success: boolean;
  status: string;
  gmail_message_id: string | null;
  error: string | null;
}

export interface SyncLogEntry {
  id: number;
  user_id: number;
  started_at: string | null;
  completed_at: string | null;
  status: string;
  messages_fetched: number;
  messages_imported: number;
  error_message: string | null;
  trigger_type: string;
}
