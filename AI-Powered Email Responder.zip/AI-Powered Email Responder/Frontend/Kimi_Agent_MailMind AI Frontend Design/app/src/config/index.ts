export const config = {
  api: {
    baseUrl: import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000',
    timeout: 30_000,
  },
  app: {
    name: 'MailMind AI',
    version: '1.0.0',
  },
} as const;
