import { Routes, Route } from 'react-router';
import { Toaster } from '@/components/ui/sonner';
import { AuthProvider } from '@/context/AuthContext';
import { ProfileProvider } from '@/context/ProfileContext';
import { MailboxProvider } from '@/context/MailboxContext';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { AuthLayout } from '@/components/auth/AuthLayout';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import ErrorBoundary from '@/components/common/ErrorBoundary';
import LandingPage from '@/pages/public/LandingPage';
import SignupPage from '@/pages/auth/SignupPage';
import LoginPage from '@/pages/auth/LoginPage';
import ForgotPasswordPage from '@/pages/auth/ForgotPasswordPage';
import ResetPasswordPage from '@/pages/auth/ResetPasswordPage';
import DashboardPage from '@/pages/app/DashboardPage';
import InboxPage from '@/pages/app/InboxPage';
import DraftsPage from '@/pages/app/DraftsPage';
import UrgentPage from '@/pages/app/UrgentPage';
import SpamPage from '@/pages/app/SpamPage';
import ComposePage from '@/pages/app/ComposePage';
import ProfilePage from '@/pages/app/ProfilePage';
import SettingsPage from '@/pages/app/SettingsPage';
import IntegrationsPage from '@/pages/app/IntegrationsPage';
import NotFound from '@/pages/NotFound';

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<LandingPage />} />

        <Route element={<AuthLayout />}>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
        </Route>

        <Route
          path="/"
          element={
            <ProtectedRoute>
              <ProfileProvider>
                <MailboxProvider>
                  <ErrorBoundary>
                    <DashboardLayout />
                  </ErrorBoundary>
                </MailboxProvider>
              </ProfileProvider>
            </ProtectedRoute>
          }
        >
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="inbox" element={<ErrorBoundary><InboxPage /></ErrorBoundary>} />
          <Route path="drafts" element={<DraftsPage />} />
          <Route path="urgent" element={<UrgentPage />} />
          <Route path="spam" element={<SpamPage />} />
          <Route path="compose" element={<ComposePage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="settings" element={<SettingsPage />} />
          <Route path="integrations" element={<IntegrationsPage />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: 'white',
            border: '1px solid #e5e7eb',
            borderRadius: '12px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
          },
        }}
      />
    </AuthProvider>
  );
}
