import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

const GMAIL_ERROR_CODES = new Set([
  "GMAIL_REAUTH_REQUIRED",
  "GMAIL_PERMISSION_DENIED",
  "GMAIL_SYNC_FAILED",
  "GMAIL_RATE_LIMITED",
  "GMAIL_API_DISABLED",
  "GMAIL_TEMPORARILY_UNAVAILABLE",
]);

function createInterceptor() {
  return (error: any) => {
    if (error.code === "ECONNABORTED") {
      return Promise.reject(new Error("Request timed out. Please try again."));
    }
    if (!error.response) {
      return Promise.reject(
        new Error("Unable to connect to the server. Make sure the backend is running.")
      );
    }

    const status = error.response?.status;
    const code = error.response?.data?.error?.code;

    if (code && GMAIL_ERROR_CODES.has(code)) {
      return Promise.reject(error);
    }

    if (status === 401 && code === "APP_AUTH_REQUIRED") {
      localStorage.removeItem("access_token");
      window.location.href = "/login";
      return Promise.reject(error);
    }

    if (status === 401) {
      localStorage.removeItem("access_token");
      window.location.href = "/login";
    }

    return Promise.reject(error);
  };
}

describe("API interceptor", () => {
  let interceptor: (error: any) => Promise<any>;
  let originalLocation: Location;

  beforeEach(() => {
    interceptor = createInterceptor();
    originalLocation = window.location;
    vi.stubGlobal("location", { href: "" });
    localStorage.clear();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("should redirect to login for APP_AUTH_REQUIRED", async () => {
    const error = {
      response: {
        status: 401,
        data: { error: { code: "APP_AUTH_REQUIRED", message: "Session expired." } },
      },
    };

    await expect(interceptor(error)).rejects.toThrow();
    expect(localStorage.getItem("access_token")).toBeNull();
    expect(window.location.href).toBe("/login");
  });

  it("should NOT redirect to login for GMAIL_REAUTH_REQUIRED", async () => {
    const error = {
      response: {
        status: 409,
        data: {
          success: false,
          error: { code: "GMAIL_REAUTH_REQUIRED", message: "Reconnect Gmail." },
        },
      },
    };
    localStorage.setItem("access_token", "test-token");

    await expect(interceptor(error)).rejects.toBe(error);
    expect(localStorage.getItem("access_token")).toBe("test-token");
    expect(window.location.href).not.toBe("/login");
  });

  it("should NOT redirect to login for GMAIL_PERMISSION_DENIED", async () => {
    const error = {
      response: {
        status: 403,
        data: { error: { code: "GMAIL_PERMISSION_DENIED" } },
      },
    };
    localStorage.setItem("access_token", "test-token");

    await expect(interceptor(error)).rejects.toBe(error);
    expect(window.location.href).not.toBe("/login");
  });

  it("should NOT redirect to login for GMAIL_SYNC_FAILED", async () => {
    const error = {
      response: {
        status: 500,
        data: { error: { code: "GMAIL_SYNC_FAILED" } },
      },
    };
    localStorage.setItem("access_token", "test-token");

    await expect(interceptor(error)).rejects.toBe(error);
    expect(window.location.href).not.toBe("/login");
  });

  it("should redirect to login for plain 401 without error code", async () => {
    const error = {
      response: {
        status: 401,
        data: { detail: "Invalid token" },
      },
    };
    localStorage.setItem("access_token", "test-token");

    await expect(interceptor(error)).rejects.toThrow();
    expect(localStorage.getItem("access_token")).toBeNull();
    expect(window.location.href).toBe("/login");
  });

  it("should handle timeout errors without redirecting", async () => {
    const error = { code: "ECONNABORTED" };
    localStorage.setItem("access_token", "test-token");

    await expect(interceptor(error)).rejects.toThrow("timed out");
    expect(localStorage.getItem("access_token")).toBe("test-token");
    expect(window.location.href).not.toBe("/login");
  });

  it("should handle network errors without redirecting", async () => {
    const error = { code: "ERR_NETWORK", response: undefined };
    localStorage.setItem("access_token", "test-token");

    await expect(interceptor(error)).rejects.toThrow("Unable to connect");
    expect(localStorage.getItem("access_token")).toBe("test-token");
    expect(window.location.href).not.toBe("/login");
  });
});
