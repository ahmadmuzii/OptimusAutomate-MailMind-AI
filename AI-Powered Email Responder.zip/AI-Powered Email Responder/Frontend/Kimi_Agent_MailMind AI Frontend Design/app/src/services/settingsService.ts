import api from './api';
import type { SettingsData } from '@/types';

export const settingsService = {
  getSettings: () => api.get<SettingsData>('/api/settings'),

  updateSettings: (data: Partial<SettingsData>) => api.put<SettingsData>('/api/settings', data),

  changePassword: (data: { current_password: string; new_password: string; confirm_password: string }) =>
    api.put('/api/profile/password', data),
};
