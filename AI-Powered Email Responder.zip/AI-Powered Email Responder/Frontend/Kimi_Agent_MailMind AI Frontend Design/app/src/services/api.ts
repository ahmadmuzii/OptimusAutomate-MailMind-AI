import axios from 'axios';
import { config } from '@/config';

const GMAIL_ERROR_CODES = new Set([
  'GMAIL_REAUTH_REQUIRED',
  'GMAIL_PERMISSION_DENIED',
  'GMAIL_SYNC_FAILED',
  'GMAIL_RATE_LIMITED',
  'GMAIL_API_DISABLED',
  'GMAIL_TEMPORARILY_UNAVAILABLE',
]);

const api = axios.create({
  baseURL: config.api.baseUrl,
  timeout: config.api.timeout,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((cfg) => {
  const token = localStorage.getItem('access_token');
  if (token) {
    cfg.headers.Authorization = `Bearer ${token}`;
  }
  return cfg;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.code === 'ECONNABORTED') {
      return Promise.reject(new Error('Request timed out. Please try again.'));
    }
    if (!error.response) {
      return Promise.reject(new Error('Unable to connect to the server. Make sure the backend is running.'));
    }

    const status = error.response?.status;
    const code = error.response?.data?.error?.code;

    // Never redirect to login for Gmail-specific errors
    if (code && GMAIL_ERROR_CODES.has(code)) {
      return Promise.reject(error);
    }

    // Only redirect to login for explicit app auth failures
    if (status === 401 && code === 'APP_AUTH_REQUIRED') {
      localStorage.removeItem('access_token');
      window.location.href = '/login';
      return Promise.reject(error);
    }

    // Catch-all for 401 without a Gmail error code => app auth failure
    if (status === 401) {
      localStorage.removeItem('access_token');
      window.location.href = '/login';
    }

    return Promise.reject(error);
  },
);

export default api;
