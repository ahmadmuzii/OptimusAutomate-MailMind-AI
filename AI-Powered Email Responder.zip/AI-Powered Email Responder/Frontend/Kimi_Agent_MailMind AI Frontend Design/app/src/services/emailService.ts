import api from './api';
import { ENDPOINTS } from './endpoints';
import type { EmailItem, MailboxCounts, EmailFormData, AnalysisResult, ProfileData } from '@/types';

export async function fetchEmails(params?: {
  folder?: string;
  search?: string;
  intent?: string;
  urgency?: string;
  page?: number;
  limit?: number;
}): Promise<EmailItem[]> {
  const res = await api.get<EmailItem[]>(ENDPOINTS.emails, { params });
  return res.data;
}

export async function fetchEmail(id: number): Promise<EmailItem> {
  const res = await api.get<EmailItem>(`${ENDPOINTS.emails}/${id}`);
  return res.data;
}

export async function createManualEmail(data: { sender: string; sender_name?: string; subject: string; body: string }) {
  const res = await api.post(`${ENDPOINTS.emails}/manual`, data);
  return res.data;
}

export async function analyzeEmailApi(data: EmailFormData): Promise<AnalysisResult> {
  const res = await api.post<AnalysisResult>(ENDPOINTS.analyzeEmail, data);
  return res.data;
}

export async function analyzeExistingEmail(id: number, tone: string = 'Professional'): Promise<AnalysisResult> {
  const res = await api.post<AnalysisResult>(`${ENDPOINTS.emails}/${id}/analyze`, null, { params: { tone } });
  return res.data;
}

export interface GenerateReplyResult {
  reply: string;
  tone: string;
  source: string;
  reply_generated?: boolean;
  error_code?: string;
  message?: string;
  tone_applied?: boolean;
  model?: string | null;
  fallback_reason?: string | null;
}

export async function generateReply(id: number, tone: string = 'Professional', previousReply?: string): Promise<GenerateReplyResult> {
  const res = await api.post<GenerateReplyResult>(
    `${ENDPOINTS.emails}/${id}/generate-reply`,
    { tone, previous_reply: previousReply || null },
  );
  return res.data;
}

export async function markAsRead(id: number): Promise<void> {
  await api.put(`${ENDPOINTS.emails}/${id}/read`);
}

export async function markAsSpam(id: number, isSpam: boolean = true): Promise<void> {
  await api.put(`${ENDPOINTS.emails}/${id}/spam`, null, { params: { is_spam: isSpam } });
}

export async function deleteEmail(id: number): Promise<void> {
  await api.delete(`${ENDPOINTS.emails}/${id}`);
}

export async function fetchMailboxCounts(): Promise<MailboxCounts> {
  const res = await api.get<MailboxCounts>(ENDPOINTS.mailboxCounts);
  return res.data;
}

export async function fetchProfile(): Promise<ProfileData> {
  const res = await api.get(ENDPOINTS.profile);
  return res.data;
}

export async function updateProfile(data: { full_name?: string; email?: string }): Promise<ProfileData> {
  const res = await api.put(ENDPOINTS.profile, data);
  return res.data;
}

export async function uploadProfilePicture(file: File): Promise<ProfileData> {
  const form = new FormData();
  form.append('file', file);
  const res = await api.post(ENDPOINTS.profilePicture, form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return res.data;
}

export async function deleteProfilePicture(): Promise<ProfileData> {
  const res = await api.delete(ENDPOINTS.profilePicture);
  return res.data;
}
