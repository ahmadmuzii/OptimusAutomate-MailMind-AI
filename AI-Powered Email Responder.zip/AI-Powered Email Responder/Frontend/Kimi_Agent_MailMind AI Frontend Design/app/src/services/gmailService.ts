import api from './api';
import type { GmailStatus, SyncLogEntry, GmailSendResult } from '@/types';

export const gmailService = {
  async getStatus(): Promise<GmailStatus> {
    const res = await api.get<GmailStatus>('/api/gmail/status');
    return res.data;
  },

  async getConnectUrl(): Promise<string> {
    const res = await api.get<{ auth_url: string }>('/api/gmail/connect');
    return res.data.auth_url;
  },

  async sync(): Promise<{ status: string; synced: number; total: number }> {
    const res = await api.post('/api/gmail/sync');
    return res.data;
  },

  async disconnect(): Promise<void> {
    await api.post('/api/gmail/disconnect');
  },

  async createDraft(draftId: number): Promise<void> {
    await api.post(`/api/gmail/create-draft?draft_id=${draftId}`);
  },

  async sendEmail(draftId: number): Promise<GmailSendResult> {
    const res = await api.post<GmailSendResult>('/api/gmail/send', { draft_id: draftId });
    return res.data;
  },

  async getSyncHistory(): Promise<SyncLogEntry[]> {
    const res = await api.get<SyncLogEntry[]>('/api/gmail/sync-history');
    return res.data;
  },
};
