import api from './api';
import type { AuthResponse, AuthUser } from '@/types';

export const authService = {
  async signup(data: { full_name: string; email: string; password: string; confirm_password: string }) {
    const res = await api.post<AuthResponse>('/api/auth/signup', data);
    return res.data;
  },

  async login(data: { email: string; password: string }) {
    const res = await api.post<AuthResponse>('/api/auth/login', data);
    return res.data;
  },

  async getMe() {
    const res = await api.get<AuthUser>('/api/auth/me');
    return res.data;
  },

  async logout() {
    try {
      await api.post('/api/auth/logout');
    } catch {
      // ignore
    }
  },

  async forgotPassword(email: string) {
    const res = await api.post('/api/auth/forgot-password', { email });
    return res.data;
  },

  async resetPassword(data: { token: string; new_password: string; confirm_password: string }) {
    const res = await api.post('/api/auth/reset-password', data);
    return res.data;
  },

  async updateProfile(data: {
    full_name?: string;
    default_tone?: string;
    preferred_reply_length?: string;
    auto_analyze?: boolean;
    notifications_enabled?: boolean;
    auto_gmail_sync?: boolean;
  }) {
    const res = await api.put<AuthUser>('/api/auth/profile', data);
    return res.data;
  },

  async changePassword(data: { current_password: string; new_password: string }) {
    const res = await api.post('/api/auth/change-password', data);
    return res.data;
  },
};
