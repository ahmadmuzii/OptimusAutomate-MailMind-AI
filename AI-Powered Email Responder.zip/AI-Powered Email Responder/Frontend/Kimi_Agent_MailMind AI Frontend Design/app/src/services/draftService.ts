import api from './api';
import type { DraftData } from '@/types';

export const draftService = {
  async fetchDrafts() {
    const res = await api.get<DraftData[]>('/api/drafts');
    return res.data;
  },

  async fetchDraft(id: number) {
    const res = await api.get<DraftData>(`/api/drafts/${id}`);
    return res.data;
  },

  async createDraft(data: { email_id?: number; recipient: string; subject: string; body: string; tone?: string }) {
    const res = await api.post<DraftData>('/api/drafts', data);
    return res.data;
  },

  async updateDraft(id: number, data: { recipient?: string; subject?: string; body?: string; tone?: string; status?: string }) {
    const res = await api.put<DraftData>(`/api/drafts/${id}`, data);
    return res.data;
  },

  async deleteDraft(id: number) {
    await api.delete(`/api/drafts/${id}`);
  },

  async createGmailDraft(draftId: number) {
    const res = await api.post(`/api/drafts/${draftId}/create-gmail-draft`);
    return res.data;
  },
};
