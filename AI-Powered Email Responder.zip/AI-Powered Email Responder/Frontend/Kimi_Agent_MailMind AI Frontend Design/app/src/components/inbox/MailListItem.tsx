import { motion } from 'framer-motion';
import { format, formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import type { EmailItem } from '@/types';

interface MailListItemProps {
  email: EmailItem;
  isSelected: boolean;
  onSelect: () => void;
  onDoubleClick: () => void;
}

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  return parts[0]?.substring(0, 2).toUpperCase() || '?';
}

const AVATAR_COLORS = ['#2357D9', '#4F7CFF', '#0B1739', '#3A6AE6', '#6B8CFF', '#1A45B8'];

function getAvatarColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

function getPlainText(html: string): string {
  return html.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
}

function formatTime(dateStr: string | null): string {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  const now = new Date();
  const diffDays = (now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24);
  if (diffDays < 7) return formatDistanceToNow(date, { addSuffix: true });
  return format(date, 'MMM d');
}

const URGENCY_STYLES: Record<string, string> = {
  high: 'bg-red-50 text-red-700 border-red-200',
  medium: 'bg-amber-50 text-amber-700 border-amber-200',
  low: 'bg-gray-100 text-gray-600 border-gray-200',
};

const SOURCE_STYLES: Record<string, string> = {
  gmail: 'bg-[#EAF0FF] text-[#2357D9] border-[#2357D9]/20',
  manual: 'bg-[#F7F9FC] text-gray-500 border-gray-200',
};

export default function MailListItem({ email, isSelected, onSelect, onDoubleClick }: MailListItemProps) {
  const displayName = email.sender_name || email.sender_email;
  const plainBody = email.body ? getPlainText(email.body) : '';
  const bodyPreview = plainBody.slice(0, 80);
  const sourceKey = email.source?.toLowerCase() === 'gmail' ? 'gmail' : 'manual';

  return (
    <motion.div
      layout
      onClick={onSelect}
      onDoubleClick={onDoubleClick}
      className={cn(
        'group flex items-start gap-3 px-4 py-3.5 border-b border-[#EAF0FF] cursor-pointer transition-colors select-none',
        isSelected ? 'bg-[#EAF0FF] border-l-[3px] border-l-[#2357D9]' : 'bg-white border-l-[3px] border-l-transparent',
        !email.is_read && !isSelected && 'bg-white',
      )}
      animate={{
        backgroundColor: isSelected ? '#EAF0FF' : '#FFFFFF',
      }}
      transition={{ duration: 0.15 }}
    >
      {!email.is_read && (
        <span className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-4 rounded-r-full bg-[#2357D9]" />
      )}

      <div className="relative w-10 h-10 rounded-full flex items-center justify-center text-white text-xs font-semibold flex-shrink-0"
        style={{ backgroundColor: getAvatarColor(displayName) }}
      >
        {getInitials(displayName)}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          {!email.is_read && <span className="w-2 h-2 rounded-full bg-[#2357D9] flex-shrink-0" />}
          <span className={cn(
            'text-sm truncate',
            !email.is_read ? 'font-semibold text-[#0B1739]' : 'font-medium text-gray-600',
          )}>
            {displayName}
          </span>
        </div>

        <p className={cn(
          'text-sm truncate mb-0.5',
          !email.is_read ? 'font-semibold text-[#0B1739]' : 'text-gray-700',
        )}>
          {email.subject}
        </p>

        <p className="text-xs text-gray-400 truncate">
          {bodyPreview}{bodyPreview.length >= 80 ? '...' : ''}
        </p>
      </div>

      <div className="flex flex-col items-end gap-1.5 flex-shrink-0 min-w-[80px]">
        <span className="text-[11px] text-gray-400 whitespace-nowrap">
          {formatTime(email.received_at)}
        </span>

        <span className={cn(
          'text-[10px] font-medium px-1.5 py-0.5 rounded-full border',
          SOURCE_STYLES[sourceKey],
        )}>
          {email.source}
        </span>

        {email.intent && (
          <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-[#EAF0FF] text-[#2357D9]">
            {email.intent}
          </span>
        )}

        {email.urgency && (
          <span className={cn(
            'text-[10px] font-semibold px-1.5 py-0.5 rounded-full border',
            URGENCY_STYLES[email.urgency.toLowerCase()] || URGENCY_STYLES.low,
          )}>
            {email.urgency}
          </span>
        )}
      </div>
    </motion.div>
  );
}
