import { motion } from 'framer-motion';
import { ArrowLeft, Trash2, ShieldAlert, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import EmptyState from '@/components/common/EmptyState';
import type { EmailItem } from '@/types';

interface EmailReaderProps {
  email: EmailItem | null;
  loading?: boolean;
  error?: string | null;
  onBack: () => void;
  onSpam: () => void;
  onDelete: () => void;
}

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  return parts[0]?.substring(0, 2).toUpperCase() || '?';
}

const AVATAR_COLORS = ['#2357D9', '#4F7CFF', '#0B1739', '#3A6AE6', '#6B8CFF', '#1A45B8'];

function getAvatarColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

function getPlainText(html: string): string {
  return html
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

const URGENCY_STYLES: Record<string, string> = {
  high: 'bg-red-50 text-red-700 border-red-200',
  medium: 'bg-amber-50 text-amber-700 border-amber-200',
  low: 'bg-gray-100 text-gray-600 border-gray-200',
};

export default function EmailReader({ email, loading, error, onBack, onSpam, onDelete }: EmailReaderProps) {
  if (!email) {
    return (
      <div className="h-full flex items-center justify-center">
        <EmptyState
          icon={undefined}
          title="Select an email"
          message="Choose an email from the list to read it here."
        />
      </div>
    );
  }

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 size={24} className="text-[#2357D9] animate-spin" />
          <p className="text-sm text-gray-500">Loading message...</p>
        </div>
      </div>
    );
  }

  const displayName = email.sender_name || email.sender_email;
  const rawContent = email.clean_body || email.body || email.body_preview || '';
  const plainBody = rawContent ? getPlainText(rawContent) : '';

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.2 }}
      className="h-full flex flex-col"
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#EAF0FF] bg-white">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-gray-500 hover:text-[#0B1739] transition-colors lg:hidden"
        >
          <ArrowLeft size={16} />
          Back
        </button>

        <div className="flex items-center gap-2 ml-auto">
          <button
            onClick={onSpam}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 text-xs font-medium text-gray-600 hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-colors"
          >
            <ShieldAlert size={13} />
            Spam
          </button>
          <button
            onClick={onDelete}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 text-xs font-medium text-gray-600 hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-colors"
          >
            <Trash2 size={13} />
            Delete
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5">
        <div className="flex items-start gap-4">
          <div
            className="w-12 h-12 rounded-full flex items-center justify-center text-white text-sm font-semibold flex-shrink-0"
            style={{ backgroundColor: getAvatarColor(displayName) }}
          >
            {getInitials(displayName)}
          </div>

          <div className="flex-1 min-w-0">
            <h2 className="text-lg font-semibold text-[#0B1739] leading-snug">{email.subject}</h2>
            <p className="text-sm font-medium text-[#0B1739] mt-1">{displayName}</p>
            <p className="text-xs text-gray-500">{email.sender_email}</p>
            {email.recipient && (
              <p className="text-xs text-gray-400 mt-0.5">to {email.recipient}</p>
            )}
            <p className="text-xs text-gray-400 mt-1">
              {email.received_at
                ? format(new Date(email.received_at), 'EEEE, MMMM d, yyyy \'at\' h:mm a')
                : ''}
            </p>
          </div>
        </div>

        {(email.intent || email.urgency) && (
          <div className="flex flex-wrap items-center gap-2">
            {email.intent && (
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#EAF0FF] text-[#2357D9]">
                {email.intent}
              </span>
            )}
            {email.urgency && (
              <span className={cn(
                'text-xs font-semibold px-2.5 py-1 rounded-full border',
                URGENCY_STYLES[email.urgency.toLowerCase()] || URGENCY_STYLES.low,
              )}>
                {email.urgency}
              </span>
            )}
          </div>
        )}

        {email.summary && (
          <div className="bg-[#EAF0FF] rounded-xl p-4 border border-[#2357D9]/10">
            <p className="text-xs font-semibold uppercase tracking-wider text-[#2357D9] mb-1.5">AI Summary</p>
            <p className="text-sm text-[#0B1739] leading-relaxed">{email.summary}</p>
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 px-4 py-3 rounded-lg border border-red-200">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 flex-shrink-0" />
            {error}
          </div>
        )}

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-400 mb-2">Message</p>
          <div className="text-sm text-[#0B1739] bg-[#F7F9FC] rounded-xl p-4 whitespace-pre-wrap leading-relaxed max-h-80 overflow-y-auto border border-[#EAF0FF]">
            {plainBody || (
              <span className="text-gray-400 italic">No message content is available.</span>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
