import { AlertCircle, RefreshCw, ChevronDown } from 'lucide-react';
import MailListItem from './MailListItem';
import { InboxSkeleton } from '@/components/shared/LoadingSkeleton';
import EmptyState from '@/components/common/EmptyState';
import type { EmailItem } from '@/types';

interface MailListProps {
  emails: EmailItem[];
  loading: boolean;
  error: string | null;
  selectedId: number | null;
  onSelect: (id: number) => void;
  onRetry: () => void;
  hasMore?: boolean;
  onLoadMore?: () => void;
}

export default function MailList({
  emails,
  loading,
  error,
  selectedId,
  onSelect,
  onRetry,
  hasMore = false,
  onLoadMore,
}: MailListProps) {
  if (loading) {
    return <InboxSkeleton />;
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
        <div className="w-14 h-14 rounded-2xl bg-red-50 flex items-center justify-center mb-4">
          <AlertCircle size={28} className="text-red-400" />
        </div>
        <h3 className="text-base font-semibold text-[#0B1739] mb-1">Failed to load emails</h3>
        <p className="text-sm text-gray-500 max-w-xs mb-4">{error}</p>
        <button
          onClick={onRetry}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#2357D9] text-white text-sm font-medium hover:bg-[#1a45b8] transition-colors"
        >
          <RefreshCw size={14} />
          Retry
        </button>
      </div>
    );
  }

  if (emails.length === 0) {
    return (
      <EmptyState
        title="No emails found"
        message="There are no emails in this folder that match your criteria."
      />
    );
  }

  return (
    <div>
      <div className="divide-y divide-[#EAF0FF]">
        {emails.map((email) => (
          <MailListItem
            key={email.id}
            email={email}
            isSelected={selectedId === email.id}
            onSelect={() => onSelect(email.id)}
            onDoubleClick={() => onSelect(email.id)}
          />
        ))}
      </div>

      {hasMore && (
        <div className="px-4 py-3 text-center">
          <button
            onClick={onLoadMore}
            className="inline-flex items-center gap-1.5 px-5 py-2 rounded-xl border border-[#EAF0FF] text-sm font-medium text-[#2357D9] bg-white hover:bg-[#F7F9FC] transition-colors"
          >
            <ChevronDown size={14} />
            Load more
          </button>
        </div>
      )}
    </div>
  );
}
