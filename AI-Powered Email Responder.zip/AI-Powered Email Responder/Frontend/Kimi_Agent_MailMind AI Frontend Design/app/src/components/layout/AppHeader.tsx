import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router';
import { motion, AnimatePresence } from 'framer-motion';
import { RefreshCw, User, LogOut, Menu, Settings } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useProfile } from '@/context/ProfileContext';
import { gmailService } from '@/services/gmailService';
import { cn } from '@/lib/utils';

interface AppHeaderProps {
  title: string;
  onMenuToggle?: () => void;
}

export default function AppHeader({ title, onMenuToggle }: AppHeaderProps) {
  const { logout } = useAuth();
  const { profile } = useProfile();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [gmailConnected, setGmailConnected] = useState(false);
  const [gmailSyncing, setGmailSyncing] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    gmailService
      .getStatus()
      .then((status) => setGmailConnected(status.is_connected))
      .catch(() => setGmailConnected(false));
  }, []);

  const handleSync = async () => {
    setGmailSyncing(true);
    try {
      await gmailService.sync();
      setGmailConnected(true);
    } catch {
      // silent
    } finally {
      setGmailSyncing(false);
    }
  };

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)
    : 'U';

  const pictureUrl = profile?.profile_picture
    ? `http://localhost:8000/${profile.profile_picture}`
    : null;

  return (
    <header className="h-16 bg-white border-b border-[#E2E8F0] flex items-center justify-between px-4 lg:px-6">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenuToggle}
          className="lg:hidden p-2 rounded-lg hover:bg-[#F7F9FC] text-[#0B1739] transition-colors"
          aria-label="Toggle menu"
        >
          <Menu size={20} />
        </button>
        <h1 className="text-lg font-semibold text-[#0B1739]">{title}</h1>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={handleSync}
          disabled={gmailSyncing}
          className={cn(
            'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all',
            gmailConnected
              ? 'bg-[#EAF0FF] text-[#2357D9] hover:bg-[#D0E0FF]'
              : 'bg-[#F7F9FC] text-[#94A3B8] hover:bg-[#EAF0FF]',
          )}
        >
          <RefreshCw size={14} className={cn(gmailSyncing && 'animate-spin')} />
          <span className="hidden sm:inline">
            {gmailSyncing ? 'Syncing...' : gmailConnected ? 'Synced' : 'Disconnected'}
          </span>
        </button>

        <div
          className={cn(
            'w-2.5 h-2.5 rounded-full flex-shrink-0',
            gmailSyncing
              ? 'bg-amber-400 animate-pulse'
              : gmailConnected
                ? 'bg-emerald-500'
                : 'bg-gray-400',
          )}
        />

        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="w-9 h-9 rounded-full bg-gradient-to-br from-[#4F7CFF] to-[#2357D9] text-white flex items-center justify-center text-xs font-bold hover:opacity-90 transition-opacity overflow-hidden"
            aria-label="Profile menu"
          >
            {pictureUrl ? (
              <img src={pictureUrl} alt="" className="w-full h-full object-cover" />
            ) : (
              initials
            )}
          </button>

          <AnimatePresence>
            {dropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: -4, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -4, scale: 0.96 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 top-10 w-48 bg-white rounded-xl shadow-lg border border-[#E2E8F0] py-1 z-50 overflow-hidden"
              >
                <div className="px-4 py-2.5 border-b border-[#EAF0FF]">
                  <p className="text-sm font-semibold text-[#0B1739]">
                    {profile?.full_name || 'User'}
                  </p>
                  <p className="text-xs text-[#94A3B8] truncate">
                    {profile?.email || ''}
                  </p>
                </div>
                <Link
                  to="/profile"
                  onClick={() => setDropdownOpen(false)}
                  className="flex items-center gap-3 px-4 py-2.5 text-sm text-[#1E293B] hover:bg-[#F7F9FC] transition-colors"
                >
                  <User size={15} />
                  Profile
                </Link>
                <Link
                  to="/settings"
                  onClick={() => setDropdownOpen(false)}
                  className="flex items-center gap-3 px-4 py-2.5 text-sm text-[#1E293B] hover:bg-[#F7F9FC] transition-colors"
                >
                  <Settings size={15} />
                  Settings
                </Link>
                <hr className="my-1 border-[#EAF0FF]" />
                <button
                  onClick={() => { setDropdownOpen(false); logout(); }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors"
                >
                  <LogOut size={15} />
                  Logout
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
}
