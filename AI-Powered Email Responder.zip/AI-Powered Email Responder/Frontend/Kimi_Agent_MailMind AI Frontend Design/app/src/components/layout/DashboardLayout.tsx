import { useState } from 'react';
import { Outlet, useLocation } from 'react-router';
import { AnimatePresence, motion } from 'framer-motion';
import AppSidebar from './AppSidebar';
import AppHeader from './AppHeader';

const PAGE_TITLES: Record<string, string> = {
  '/inbox': 'Inbox',
  '/urgent': 'Urgent',
  '/spam': 'Spam',
  '/drafts': 'Drafts',
  '/compose': 'Compose',
  '/dashboard': 'Dashboard',
  '/integrations': 'Integrations',
  '/settings': 'Settings',
  '/profile': 'Profile',
};

export function DashboardLayout() {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const title =
    Object.entries(PAGE_TITLES).find(([path]) =>
      location.pathname.startsWith(path),
    )?.[1] || 'Dashboard';

  return (
    <div className="h-screen flex bg-[#F7F9FC] overflow-hidden">
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            key="sidebar-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 z-20 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      <div className="hidden lg:flex lg:shrink-0">
        <div className="w-60 h-screen">
          <AppSidebar />
        </div>
      </div>

      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            key="mobile-sidebar"
            initial={{ x: -280 }}
            animate={{ x: 0 }}
            exit={{ x: -280 }}
            transition={{ type: 'spring', stiffness: 350, damping: 30 }}
            className="fixed inset-y-0 left-0 z-30 w-60 h-screen lg:hidden"
          >
            <AppSidebar onItemClick={() => setSidebarOpen(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col min-w-0">
        <AppHeader
          title={title}
          onMenuToggle={() => setSidebarOpen((prev) => !prev)}
        />
        <main className="flex-1 overflow-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
