import { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'react-router';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Mail, AlertCircle, ShieldAlert, FileEdit, PlusCircle, LayoutDashboard,
  Puzzle, Settings, Zap, LogOut, User, ChevronDown,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useMailbox } from '@/context/MailboxContext';
import { useProfile } from '@/context/ProfileContext';
import { cn } from '@/lib/utils';

const NAV_ITEMS = [
  { id: 'inbox', label: 'Inbox', icon: Mail, path: '/inbox', countKey: 'inbox' as const },
  { id: 'urgent', label: 'Urgent', icon: AlertCircle, path: '/urgent', countKey: 'urgent' as const },
  { id: 'spam', label: 'Spam', icon: ShieldAlert, path: '/spam', countKey: 'spam' as const },
  { id: 'drafts', label: 'Drafts', icon: FileEdit, path: '/drafts', countKey: 'drafts' as const },
];

const OTHER_ITEMS = [
  { id: 'compose', label: 'Compose', icon: PlusCircle, path: '/compose' },
];

const BOTTOM_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' },
  { id: 'integrations', label: 'Integrations', icon: Puzzle, path: '/integrations' },
  { id: 'settings', label: 'Settings', icon: Settings, path: '/settings' },
];

interface AppSidebarProps {
  onItemClick?: () => void;
}

export default function AppSidebar({ onItemClick }: AppSidebarProps) {
  const location = useLocation();
  const { counts } = useMailbox();
  const { profile } = useProfile();
  const { logout } = useAuth();
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfileOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const isActive = (path: string) => {
    if (path === '/dashboard') return location.pathname === '/' || location.pathname === '/dashboard';
    return location.pathname.startsWith(path);
  };

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)
    : 'U';

  const pictureUrl = profile?.profile_picture
    ? `http://localhost:8000/${profile.profile_picture}`
    : null;

  function renderNavItem(
    item: { id: string; label: string; icon: React.ComponentType<{ size?: number }>; path: string; countKey?: keyof typeof counts },
  ) {
    const Icon = item.icon;
    const itemCount = item.countKey ? (counts[item.countKey] ?? 0) : 0;
    const active = isActive(item.path);

    return (
      <Link
        key={item.id}
        to={item.path}
        onClick={onItemClick}
        className={cn(
          'relative flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-150',
          active
            ? 'bg-[#2357D9]/15 text-[#4F7CFF]'
            : 'text-[#94A3B8] hover:bg-[#ffffff08] hover:text-[#E2E8F0]',
        )}
      >
        {active && (
          <motion.div
            layoutId="activeNavIndicator"
            className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-[#4F7CFF] rounded-full"
            transition={{ type: 'spring', stiffness: 400, damping: 35 }}
          />
        )}
        <Icon size={18} />
        <span className="flex-1 text-left">{item.label}</span>
        {itemCount > 0 && (
          <span
            className={cn(
              'text-xs font-semibold px-2 py-0.5 rounded-full min-w-[22px] text-center',
              active ? 'bg-[#4F7CFF]/20 text-[#4F7CFF]' : 'bg-[#ffffff10] text-[#94A3B8]',
            )}
          >
            {itemCount}
          </span>
        )}
      </Link>
    );
  }

  function renderLinkItem(item: { id: string; label: string; icon: React.ComponentType<{ size?: number }>; path: string }) {
    const Icon = item.icon;
    const active = isActive(item.path);

    return (
      <Link
        key={item.id}
        to={item.path}
        onClick={onItemClick}
        className={cn(
          'relative flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-150',
          active
            ? 'bg-[#2357D9]/15 text-[#4F7CFF]'
            : 'text-[#94A3B8] hover:bg-[#ffffff08] hover:text-[#E2E8F0]',
        )}
      >
        {active && (
          <motion.div
            layoutId="activeNavIndicator"
            className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-[#4F7CFF] rounded-full"
            transition={{ type: 'spring', stiffness: 400, damping: 35 }}
          />
        )}
        <Icon size={18} />
        <span className="flex-1 text-left">{item.label}</span>
      </Link>
    );
  }

  return (
    <aside className="w-60 bg-[#0B1739] flex flex-col h-full select-none">
      <div className="p-5 border-b border-[#ffffff12]">
        <Link to="/dashboard" className="flex items-center gap-2.5" onClick={onItemClick}>
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4F7CFF] to-[#2357D9] flex items-center justify-center shadow-sm">
            <Zap size={18} className="text-white" />
          </div>
          <span className="text-lg font-bold text-white tracking-tight">MailMind</span>
        </Link>
      </div>

      <nav className="flex-1 py-3 space-y-0.5 overflow-y-auto px-3">
        {NAV_ITEMS.map(renderNavItem)}

        <div className="my-2 border-t border-[#ffffff10]" />

        {OTHER_ITEMS.map(renderLinkItem)}

        <div className="my-2 border-t border-[#ffffff10]" />

        {BOTTOM_ITEMS.map(renderLinkItem)}
      </nav>

      <div className="relative p-4 border-t border-[#ffffff12]" ref={profileRef}>
        <button
          onClick={() => setProfileOpen(!profileOpen)}
          className="w-full flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-[#ffffff08] transition-colors text-left"
        >
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#4F7CFF] to-[#2357D9] text-white flex items-center justify-center text-xs font-bold overflow-hidden flex-shrink-0">
            {pictureUrl ? (
              <img src={pictureUrl} alt="" className="w-full h-full object-cover" />
            ) : (
              initials
            )}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-white truncate leading-tight">
              {profile?.full_name || 'User'}
            </p>
            <p className="text-xs text-[#94A3B8] truncate">
              {profile?.email || ''}
            </p>
          </div>
          <ChevronDown
            size={14}
            className={cn(
              'text-[#94A3B8] transition-transform duration-200 flex-shrink-0',
              profileOpen && 'rotate-180',
            )}
          />
        </button>

        <AnimatePresence>
          {profileOpen && (
            <motion.div
              initial={{ opacity: 0, y: -4, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -4, scale: 0.96 }}
              transition={{ duration: 0.15 }}
              className="absolute bottom-full left-2 right-2 mb-2 bg-[#1A2744] rounded-xl border border-[#ffffff12] shadow-xl py-1 overflow-hidden origin-bottom"
            >
              <Link
                to="/profile"
                onClick={() => { setProfileOpen(false); onItemClick?.(); }}
                className="flex items-center gap-3 px-4 py-2.5 text-sm text-[#E2E8F0] hover:bg-[#ffffff08] transition-colors"
              >
                <User size={15} />
                Profile
              </Link>
              <button
                onClick={() => { setProfileOpen(false); logout(); }}
                className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[#E2E8F0] hover:bg-[#ffffff08] transition-colors"
              >
                <LogOut size={15} />
                Logout
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </aside>
  );
}
