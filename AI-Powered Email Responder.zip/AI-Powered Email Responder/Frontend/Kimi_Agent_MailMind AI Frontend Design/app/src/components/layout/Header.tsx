import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router';
import { Settings, LogOut, User, Upload, Trash2 } from 'lucide-react';
import { useProfile } from '@/context/ProfileContext';
import { useMailbox } from '@/context/MailboxContext';
import { useAuth } from '@/context/AuthContext';
import ProfileModal from '@/components/profile/ProfileModal';

export default function Header() {
  const { profile, uploadPicture, removePicture } = useProfile();
  const { counts } = useMailbox();
  const { logout } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [pictureError, setPictureError] = useState<string | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)
    : 'U';

  const pictureUrl = profile?.profile_picture
    ? `http://localhost:8000/${profile.profile_picture}`
    : null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPictureError(null);
    const allowed = ['image/png', 'image/jpg', 'image/jpeg', 'image/webp'];
    if (!allowed.includes(file.type)) {
      setPictureError('Only PNG, JPG, JPEG, or WebP allowed.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setPictureError('Max file size is 5 MB.');
      return;
    }
    try {
      await uploadPicture(file);
      setDropdownOpen(false);
    } catch {
      setPictureError('Failed to upload image.');
    }
  };

  return (
    <>
      <header className="h-16 bg-white border-b border-[hsl(220,13%,88%)] flex items-center justify-between px-6">
        <div>
          <h2 className="text-lg font-bold text-[hsl(222,47%,18%)]">MailMind AI</h2>
          <p className="text-xs text-[hsl(220,9%,46%)]">
            Inbox: {counts.inbox} · Urgent: {counts.urgent} · Drafts: {counts.drafts}
          </p>
        </div>

        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="w-10 h-10 rounded-full bg-[hsl(220,60%,28%)] text-white flex items-center justify-center text-sm font-bold hover:opacity-90 transition-opacity overflow-hidden"
          >
            {pictureUrl ? (
              <img src={pictureUrl} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              initials
            )}
          </button>

          {dropdownOpen && (
            <div className="absolute right-0 top-12 w-56 bg-white rounded-xl shadow-lg border border-[hsl(220,13%,88%)] py-2 z-50">
              <div className="px-4 py-2 border-b border-[hsl(220,13%,88%)]">
                <p className="text-sm font-semibold text-[hsl(222,47%,18%)]">
                  {profile?.full_name || 'User'}
                </p>
                <p className="text-xs text-[hsl(220,9%,46%)]">{profile?.email || ''}</p>
              </div>

              <button
                onClick={() => { setProfileModalOpen(true); setDropdownOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[hsl(222,47%,18%)] hover:bg-[hsl(220,14%,93%)] transition-colors"
              >
                <User size={16} /> Profile
              </button>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[hsl(222,47%,18%)] hover:bg-[hsl(220,14%,93%)] transition-colors"
              >
                <Upload size={16} /> Upload Profile Picture
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".png,.jpg,.jpeg,.webp"
                className="hidden"
                onChange={handleFileUpload}
              />

              {pictureUrl && (
                <button
                  onClick={async () => { await removePicture(); setDropdownOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors"
                >
                  <Trash2 size={16} /> Remove Profile Picture
                </button>
              )}

              <hr className="my-1 border-[hsl(220,13%,88%)]" />

              <Link to="/settings" onClick={() => setDropdownOpen(false)} className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[hsl(222,47%,18%)] hover:bg-[hsl(220,14%,93%)] transition-colors">
                <Settings size={16} /> Settings
              </Link>
              <button onClick={() => { setDropdownOpen(false); logout(); }} className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[hsl(222,47%,18%)] hover:bg-[hsl(220,14%,93%)] transition-colors">
                <LogOut size={16} /> Logout
              </button>

              {pictureError && (
                <p className="px-4 py-2 text-xs text-red-600">{pictureError}</p>
              )}
            </div>
          )}
        </div>
      </header>

      {profileModalOpen && (
        <ProfileModal onClose={() => setProfileModalOpen(false)} />
      )}
    </>
  );
}
