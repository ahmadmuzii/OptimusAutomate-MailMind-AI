import { useState, useRef } from 'react';
import { X, Upload } from 'lucide-react';
import { useProfile } from '@/context/ProfileContext';
import { Button } from '@/components/ui/button';

interface ProfileModalProps {
  onClose: () => void;
}

export default function ProfileModal({ onClose }: ProfileModalProps) {
  const { profile, updateProfile, uploadPicture, removePicture, loading } = useProfile();
  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [email, setEmail] = useState(profile?.email || '');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const pictureUrl = profile?.profile_picture
    ? `http://localhost:8000/${profile.profile_picture}`
    : null;

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    const allowed = ['image/png', 'image/jpg', 'image/jpeg', 'image/webp'];
    if (!allowed.includes(file.type)) {
      setError('Only PNG, JPG, JPEG, or WebP allowed.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError('Max file size is 5 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => setPreviewUrl(ev.target?.result as string);
    reader.readAsDataURL(file);
    uploadPicture(file);
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    try {
      await updateProfile({ full_name: fullName, email });
      onClose();
    } catch {
      setError('Failed to save profile.');
    } finally {
      setSaving(false);
    }
  };

  const initials = (fullName || 'User')
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const displayUrl = previewUrl || pictureUrl;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md mx-4 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[hsl(220,13%,88%)]">
          <h2 className="text-lg font-bold text-[hsl(222,47%,18%)]">Profile</h2>
          <button onClick={onClose} className="text-[hsl(220,9%,46%)] hover:text-[hsl(222,47%,18%)]">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="flex flex-col items-center gap-3">
            <div className="w-24 h-24 rounded-full bg-[hsl(220,60%,28%)] text-white flex items-center justify-center text-2xl font-bold overflow-hidden">
              {displayUrl ? (
                <img src={displayUrl} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                initials
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                <Upload size={14} className="mr-1" /> Upload
              </Button>
              {profile?.profile_picture && (
                <Button variant="outline" size="sm" onClick={removePicture} className="text-red-600 border-red-200">
                  Remove
                </Button>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".png,.jpg,.jpeg,.webp"
              className="hidden"
              onChange={handleFileSelect}
            />
            {error && <p className="text-xs text-red-600">{error}</p>}
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)] block mb-1">
                Full Name
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full h-11 px-4 rounded-lg border border-[hsl(220,13%,88%)] text-sm focus:border-[hsl(220,60%,28%)] focus:ring-1 focus:ring-[hsl(220,60%,28%)]/20 outline-none transition-all"
                placeholder="Your full name"
              />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)] block mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-11 px-4 rounded-lg border border-[hsl(220,13%,88%)] text-sm focus:border-[hsl(220,60%,28%)] focus:ring-1 focus:ring-[hsl(220,60%,28%)]/20 outline-none transition-all"
                placeholder="your@email.com"
              />
            </div>
          </div>

          <div className="flex gap-3 justify-end pt-2">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={saving || loading}>
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
