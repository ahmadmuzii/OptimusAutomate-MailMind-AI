import { motion } from 'framer-motion';
import { UserPlus, Mail, Sparkles, CheckSquare } from 'lucide-react';

const STEPS = [
  {
    number: '01',
    icon: UserPlus,
    title: 'Create an account',
    description: 'Sign up with your email and secure password. No credit card required to get started.',
  },
  {
    number: '02',
    icon: Mail,
    title: 'Connect Gmail',
    description: 'Authorize MailMind via Google OAuth. We only request read and draft permissions.',
  },
  {
    number: '03',
    icon: Sparkles,
    title: 'Let MailMind analyze new messages',
    description: 'New emails are automatically analyzed for intent, urgency, and context. Summaries are generated instantly.',
  },
  {
    number: '04',
    icon: CheckSquare,
    title: 'Review and approve generated replies',
    description: 'Read the AI draft, adjust the tone, edit the content, then save or send — all under your control.',
  },
];

export default function HowItWorksSection() {
  return (
    <section className="py-20 sm:py-28 bg-white" id="how-it-works">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1739] leading-tight">
            How MailMind works
          </h2>
        </motion.div>

        <div className="max-w-4xl mx-auto grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {STEPS.map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="relative text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-[#EAF0FF] flex items-center justify-center mx-auto mb-4">
                  <Icon size={28} className="text-[#2357D9]" />
                </div>
                <span className="text-xs font-bold text-[#2357D9] tracking-widest">{step.number}</span>
                <h3 className="text-lg font-semibold text-[#0B1739] mt-1 mb-2">{step.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{step.description}</p>
                {index < STEPS.length - 1 && (
                  <div className="hidden lg:block absolute top-8 -right-4 w-8 h-0.5 bg-gray-200" />
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
