import { motion } from 'framer-motion';
import { Filter, Clock, MessageSquare } from 'lucide-react';

const PROBLEMS = [
  {
    icon: Filter,
    title: 'Important messages get buried',
    description: 'Promotions, newsletters, and spam push urgent client emails to the bottom of your inbox.',
  },
  {
    icon: Clock,
    title: 'Repetitive replies consume time',
    description: 'You spend hours writing the same kinds of responses to meeting requests, follow-ups, and status checks.',
  },
  {
    icon: MessageSquare,
    title: 'Generic AI answers miss the context',
    description: 'Most AI tools ignore your relationship history, writing style, and the specific urgency of each message.',
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.15 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

export default function ProblemSection() {
  return (
    <section className="py-20 sm:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1739] leading-tight">
            Email should not control your day.
          </h2>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="grid md:grid-cols-3 gap-6 lg:gap-8"
        >
          {PROBLEMS.map((problem) => (
            <motion.div
              key={problem.title}
              variants={cardVariants}
              className="group p-6 sm:p-8 rounded-2xl border border-gray-100 bg-[#F7F9FC] hover:border-[#4F7CFF]/30 hover:shadow-lg hover:shadow-[#4F7CFF]/5 transition-all duration-300"
            >
              <div className="w-10 h-10 rounded-lg bg-[#2357D9]/10 flex items-center justify-center mb-4 group-hover:bg-[#2357D9]/20 transition-colors">
                <problem.icon size={20} className="text-[#2357D9]" />
              </div>
              <h3 className="text-lg font-semibold text-[#0B1739] mb-2">{problem.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">{problem.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
