import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

const ITEMS = [
  'Google OAuth connection',
  'API keys kept on the backend',
  'Per-user account isolation',
  'Nothing sent without confirmation',
  'Private credentials excluded from Git',
  'User-controlled Gmail connection and disconnection',
];

export default function SecuritySection() {
  return (
    <section className="py-20 sm:py-28 bg-[#F7F9FC]" id="security">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1739] leading-tight mb-4">
              Your inbox stays <br className="hidden sm:block" />
              <span className="text-[#2357D9]">under your control.</span>
            </h2>
            <p className="text-gray-500 max-w-xl mx-auto">
              MailMind is built with a privacy-first architecture. Your credentials never leave your
              device unless encrypted, and every action requires your explicit approval.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-gray-200 p-6 sm:p-8 shadow-sm">
            <div className="grid sm:grid-cols-2 gap-4">
              {ITEMS.map((item) => (
                <div key={item} className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-50 flex items-center justify-center shrink-0 mt-0.5">
                    <Check size={12} className="text-emerald-600" />
                  </div>
                  <span className="text-sm text-gray-700">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
