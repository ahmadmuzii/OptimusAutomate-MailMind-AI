import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Save } from 'lucide-react';

const DEMO_EMAIL = {
  sender: 'Sarah Chen',
  senderEmail: 'sarah.chen@acmecorp.com',
  subject: 'Q3 Marketing Campaign Review',
  body: 'Hi team, I wanted to schedule a review of our Q3 marketing campaign materials before the launch next month. Could we find time this week to go over the creatives and finalize the budget allocation? Let me know your availability. Thanks!',
};

const INITIAL_REPLY = 'Thank you for reaching out. I appreciate the opportunity to review the Q3 marketing campaign materials. I am available this week on Wednesday or Thursday afternoon. Please let me know which time works best for you.';
const FRIENDLY_REPLY = 'Hey Sarah, thanks for looping me in on the Q3 campaign review! I\'d love to go over the creatives this week. Wednesday or Thursday afternoon both work for me — just let me know what time suits you best. Looking forward to it!';

export default function HeroEmailDemo() {
  const [emailVisible, setEmailVisible] = useState(false);
  const [analysisVisible, setAnalysisVisible] = useState(false);
  const [intent, setIntent] = useState('---');
  const [urgency, setUrgency] = useState('---');
  const [summary, setSummary] = useState('');
  const [replyText, setReplyText] = useState('');
  const [typingText, setTypingText] = useState('');
  const [tone, setTone] = useState('Professional');
  const [showSave, setShowSave] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) {
      setEmailVisible(true);
      setAnalysisVisible(true);
      setIntent('Meeting Request');
      setUrgency('Medium');
      setSummary('Sarah wants to schedule a Q3 campaign review meeting this week.');
      setReplyText(INITIAL_REPLY);
      setTone('Professional');
      setShowSave(true);
      setReady(true);
      return;
    }
  }, []);

  const runSequence = useCallback(() => {
    let cancelled = false;

    const t = setTimeout(() => {
      if (cancelled) return;
      setEmailVisible(true);

      setTimeout(() => {
        if (cancelled) return;
        setAnalysisVisible(true);

        setTimeout(() => {
          if (cancelled) return;
          setIntent('Meeting Request');

          setTimeout(() => {
            if (cancelled) return;
            setUrgency('Medium');

            setTimeout(() => {
              if (cancelled) return;
              setSummary('Sarah wants to schedule a Q3 campaign review meeting this week. She is available Wednesday or Thursday afternoon.');

              setTimeout(() => {
                if (cancelled) return;
                let i = 0;
                const fullText = INITIAL_REPLY;
                const typing = setInterval(() => {
                  if (cancelled) { clearInterval(typing); return; }
                  i++;
                  setTypingText(fullText.slice(0, i));
                  if (i >= fullText.length) {
                    clearInterval(typing);
                    setReplyText(fullText);
                  }
                }, 12);

                setTimeout(() => {
                  if (cancelled) return;
                  setTone('Friendly');

                  setTimeout(() => {
                    if (cancelled) return;
                    let j = 0;
                    const friendly = FRIENDLY_REPLY;
                    setTypingText('');
                    const typing2 = setInterval(() => {
                      if (cancelled) { clearInterval(typing2); return; }
                      j++;
                      setTypingText(friendly.slice(0, j));
                      if (j >= friendly.length) {
                        clearInterval(typing2);
                        setReplyText(friendly);
                        setShowSave(true);
                        setReady(true);
                      }
                    }, 10);
                  }, 800);
                }, 1800);
              }, 1600);
            }, 1400);
          }, 1000);
        }, 1200);
      }, 1400);
    }, 600);

    return () => { cancelled = true; clearTimeout(t); };
  }, []);

  useEffect(() => {
    const cleanup = runSequence();
    return cleanup;
  }, [runSequence]);

  return (
    <div className="relative w-full max-w-[520px] mx-auto" role="img" aria-label="Animated MailMind email demo preview">
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 bg-gray-50 border-b border-gray-100">
          <div className="w-3 h-3 rounded-full bg-red-400" />
          <div className="w-3 h-3 rounded-full bg-yellow-400" />
          <div className="w-3 h-3 rounded-full bg-green-400" />
          <span className="ml-2 text-xs text-gray-400 font-medium">MailMind - Inbox</span>
        </div>

        <div className="p-4 space-y-3">
          <AnimatePresence>
            {emailVisible && (
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-[#F7F9FC] rounded-xl p-4 border border-gray-100"
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#2357D9]/10 flex items-center justify-center text-[#2357D9] font-semibold text-xs shrink-0">
                    SC
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 text-xs text-gray-500 mb-0.5">
                      <span className="font-medium text-gray-700">{DEMO_EMAIL.sender}</span>
                      <span className="text-gray-400">&lt;{DEMO_EMAIL.senderEmail}&gt;</span>
                    </div>
                    <p className="text-sm font-semibold text-[#0B1739] mb-1">{DEMO_EMAIL.subject}</p>
                    <p className="text-xs text-gray-500 leading-relaxed line-clamp-3">{DEMO_EMAIL.body}</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {analysisVisible && (
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-xl border border-gray-100 divide-y divide-gray-50"
              >
                <div className="p-3 flex items-center gap-3">
                  <Sparkles size={14} className="text-[#2357D9]" />
                  <span className="text-xs font-medium text-gray-500">AI Analysis</span>
                </div>
                <div className="p-3 grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] font-medium text-gray-400 uppercase tracking-wider">Intent</span>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <motion.span
                        key={intent}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                          intent === 'Meeting Request'
                            ? 'bg-blue-50 text-[#2357D9] border border-blue-100'
                            : intent !== '---'
                            ? 'bg-purple-50 text-purple-700 border border-purple-100'
                            : 'bg-gray-50 text-gray-400'
                        }`}
                      >
                        {intent}
                      </motion.span>
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] font-medium text-gray-400 uppercase tracking-wider">Urgency</span>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <motion.span
                        key={urgency}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                          urgency === 'Medium'
                            ? 'bg-amber-50 text-amber-700 border border-amber-100'
                            : urgency !== '---'
                            ? 'bg-red-50 text-red-700 border border-red-100'
                            : 'bg-gray-50 text-gray-400'
                        }`}
                      >
                        {urgency}
                      </motion.span>
                    </div>
                  </div>
                </div>
                <AnimatePresence>
                  {summary && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="p-3"
                    >
                      <span className="text-[10px] font-medium text-gray-400 uppercase tracking-wider">Summary</span>
                      <p className="text-xs text-gray-600 mt-0.5 leading-relaxed">{summary}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {(typingText || replyText) && (
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-xl border border-gray-100"
              >
                <div className="p-3 flex items-center justify-between border-b border-gray-50">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-medium text-gray-400 uppercase tracking-wider">Reply</span>
                    <motion.span
                      key={tone}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                        tone === 'Friendly' ? 'bg-green-50 text-green-700' : 'bg-blue-50 text-blue-700'
                      }`}
                    >
                      {tone}
                    </motion.span>
                  </div>
                  <div className="flex items-center gap-1">
                    {['Professional', 'Friendly', 'Short', 'Apologetic'].map((t) => (
                      <button
                        key={t}
                        onClick={() => setTone(t)}
                        className={`text-[10px] px-2 py-0.5 rounded font-medium transition-colors ${
                          tone === t ? 'bg-[#2357D9] text-white' : 'text-gray-400 hover:text-gray-600'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="p-3">
                  <p className="text-xs text-gray-700 leading-relaxed min-h-[40px]">
                    {typingText || replyText}
                    {(typingText && typingText.length < (tone === 'Friendly' ? FRIENDLY_REPLY : INITIAL_REPLY).length) && (
                      <span className="inline-block w-0.5 h-3.5 bg-[#2357D9] ml-0.5 animate-pulse" />
                    )}
                  </p>
                </div>
                <AnimatePresence>
                  {showSave && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="p-3 border-t border-gray-50 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-1.5 text-[10px] font-medium text-emerald-600">
                        <Save size={12} />
                        Save Draft
                      </div>
                      {ready && (
                        <span className="text-[10px] font-medium text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                          Ready for review
                        </span>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
