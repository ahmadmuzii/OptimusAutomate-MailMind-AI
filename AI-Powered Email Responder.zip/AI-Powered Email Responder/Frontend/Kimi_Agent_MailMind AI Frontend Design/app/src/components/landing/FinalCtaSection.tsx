import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router';

export default function FinalCtaSection() {
  return (
    <section className="py-20 sm:py-28 bg-[#0B1739] relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[#2357D9]/10 via-transparent to-[#4F7CFF]/5" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#2357D9]/10 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white leading-tight mb-4">
            Spend less time writing email.
          </h2>
          <p className="text-lg text-blue-200/80 mb-10 max-w-xl mx-auto">
            Connect your inbox and let MailMind prepare the first draft while you stay in control.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/signup"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-white text-[#0B1739] text-sm font-bold hover:bg-blue-50 transition-all shadow-lg shadow-white/10"
            >
              Get started
              <ArrowRight size={16} />
            </Link>
            <a
              href="#product"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl border border-white/20 text-white text-sm font-semibold hover:bg-white/10 transition-all"
            >
              View product
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
