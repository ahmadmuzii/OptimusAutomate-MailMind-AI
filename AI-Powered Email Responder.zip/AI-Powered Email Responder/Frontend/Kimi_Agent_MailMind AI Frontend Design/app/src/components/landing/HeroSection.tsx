import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router';
import { ArrowRight, ChevronDown } from 'lucide-react';
import HeroEmailDemo from './HeroEmailDemo';

export default function HeroSection() {
  const [prefersReduced, setPrefersReduced] = useState(false);

  useEffect(() => {
    setPrefersReduced(window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-[#F7F9FC]">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMCAwaDQwdjQwSDB6IiBmaWxsPSJub25lIiBzdHJva2U9InJnYmEoMzUsIDg3LCAyMTcsIDAuMDMpIiBzdHJva2Utd2lkdGg9IjEiLz48L3N2Zz4=')] opacity-50" />
      <div className="absolute top-1/2 right-0 -translate-y-1/2 w-[500px] h-[500px] bg-[#4F7CFF]/10 rounded-full blur-[100px]" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#2357D9]/5 rounded-full blur-[80px]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-20 lg:py-0">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <motion.div
            initial={prefersReduced ? {} : { opacity: 0, x: -24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block text-xs font-semibold text-[#2357D9] bg-[#EAF0FF] px-3 py-1.5 rounded-full mb-6">
              AI-powered email productivity
            </span>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-[#0B1739] leading-[1.1] tracking-tight mb-6">
              Your inbox,<br />
              <span className="text-[#2357D9]">already understood.</span>
            </h1>

            <p className="text-base sm:text-lg text-gray-500 max-w-lg mb-8 leading-relaxed">
              MailMind reads every incoming email, identifies intent and urgency, summarizes the thread,
              and prepares a reply in your voice — so you review instead of writing from scratch.
            </p>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 mb-6">
              <Link
                to="/signup"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#2357D9] text-white text-sm font-bold hover:bg-[#1a45b8] transition-all shadow-lg shadow-[#2357D9]/20"
              >
                Connect your inbox
                <ArrowRight size={16} />
              </Link>
              <a
                href="#product"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border border-gray-200 text-gray-700 text-sm font-semibold hover:border-gray-300 hover:bg-gray-50 transition-all"
              >
                See how it works
              </a>
            </div>

            <p className="text-xs text-gray-400 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
              Nothing is sent without your approval.
            </p>
          </motion.div>

          <motion.div
            initial={prefersReduced ? {} : { opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <HeroEmailDemo />
          </motion.div>
        </div>
      </div>

      <motion.a
        href="#product"
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.5 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-gray-400 hover:text-[#2357D9] transition-colors"
      >
        <span className="text-[10px] font-medium uppercase tracking-wider">Scroll</span>
        <motion.div
          animate={prefersReduced ? {} : { y: [0, 6, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          <ChevronDown size={18} />
        </motion.div>
      </motion.a>
    </section>
  );
}
