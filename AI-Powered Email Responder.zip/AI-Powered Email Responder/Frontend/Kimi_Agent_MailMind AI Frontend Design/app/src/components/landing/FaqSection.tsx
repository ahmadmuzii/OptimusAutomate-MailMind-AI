import { motion } from 'framer-motion';

const FAQS = [
  {
    q: 'Does MailMind send emails automatically?',
    a: 'No. MailMind never sends anything without your explicit approval. Every draft is generated for you to review, edit, and then manually send. You remain in full control of your outgoing messages.',
  },
  {
    q: 'Can I use MailMind without connecting Gmail?',
    a: 'No, a Gmail connection via Google OAuth is required. MailMind needs access to read incoming messages to analyze them and generate drafts. We only request the minimum scopes needed — read and draft compose.',
  },
  {
    q: 'How are replies generated?',
    a: 'Replies are generated using Groq\'s LLM API. The email content, your relationship context with the sender, and the selected tone are all factored into the generated draft. No email data is used to train or improve the model.',
  },
  {
    q: 'Can I change the reply tone?',
    a: 'Yes. You can choose from Professional, Friendly, Apologetic, and Short tones before generating a draft. The tone can also be changed after generation to produce a new draft.',
  },
  {
    q: 'Can I disconnect Gmail?',
    a: 'Yes. You can disconnect your Gmail account at any time from the settings page. This revokes MailMind\'s access tokens and stops inbox polling immediately.',
  },
  {
    q: 'Are generated replies automatically saved?',
    a: 'Generated replies are saved as drafts in your Gmail account so you can find them later. They are also stored locally in the app until you dismiss or send them.',
  },
  {
    q: 'What happens if the AI service is unavailable?',
    a: 'If Groq\'s API is unreachable, MailMind will show a clear error message and queue the analysis for retry. Your inbox data remains safe and no drafts are lost. You can continue using the app normally once the service is restored.',
  },
];

export default function FaqSection() {
  return (
    <section className="py-20 sm:py-28 bg-[#F7F9FC]" id="faq">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1739] leading-tight">
            Frequently asked questions
          </h2>
        </motion.div>

        <div className="max-w-3xl mx-auto space-y-3">
          {FAQS.map((faq) => (
            <motion.div
              key={faq.q}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.4 }}
              className="bg-white rounded-xl border border-gray-200 overflow-hidden"
            >
              <details className="group">
                <summary className="flex items-center justify-between px-5 py-4 text-sm font-semibold text-[#0B1739] cursor-pointer hover:bg-gray-50 transition-colors list-none">
                  {faq.q}
                  <svg
                    className="w-4 h-4 text-gray-400 group-open:rotate-180 transition-transform shrink-0 ml-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                  </svg>
                </summary>
                <div className="px-5 pb-4">
                  <p className="text-sm text-gray-500 leading-relaxed">{faq.a}</p>
                </div>
              </details>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
