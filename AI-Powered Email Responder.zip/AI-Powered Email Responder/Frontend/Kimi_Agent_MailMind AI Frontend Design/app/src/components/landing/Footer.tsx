import { Link } from 'react-router';
import { Github } from 'lucide-react';

const currentYear = new Date().getFullYear();

const PRODUCT_LINKS = [
  { label: 'How it works', href: '#how-it-works' },
  { label: 'Features', href: '#features' },
  { label: 'Security', href: '#security' },
];

const ACCOUNT_LINKS = [
  { label: 'Login', href: '/login' },
  { label: 'Sign Up', href: '/signup' },
];

const LEGAL_LINKS = [
  { label: 'Privacy', href: '#' },
  { label: 'Terms', href: '#' },
];

export default function Footer() {
  return (
    <footer className="bg-[#0B1739] border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          <div className="sm:col-span-2 lg:col-span-1">
            <Link to="/" className="flex items-center gap-2.5 mb-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#2357D9] to-[#7357FF] flex items-center justify-center">
                <span className="text-white font-bold text-sm">M</span>
              </div>
              <span className="font-semibold text-white text-lg">MailMind AI</span>
            </Link>
            <p className="text-sm text-blue-200/60 leading-relaxed max-w-xs">
              AI-powered email productivity. MailMind analyzes, summarizes, and drafts replies so you can focus on what matters.
            </p>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-white uppercase tracking-widest mb-4">Product</h3>
            <ul className="space-y-2.5">
              {PRODUCT_LINKS.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-sm text-blue-200/60 hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-white uppercase tracking-widest mb-4">Account</h3>
            <ul className="space-y-2.5">
              {ACCOUNT_LINKS.map((link) => (
                <li key={link.label}>
                  <Link to={link.href} className="text-sm text-blue-200/60 hover:text-white transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-white uppercase tracking-widest mb-4">Legal</h3>
            <ul className="space-y-2.5">
              {LEGAL_LINKS.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-sm text-blue-200/60 hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href="#"
                  className="inline-flex items-center gap-1.5 text-sm text-blue-200/60 hover:text-white transition-colors"
                >
                  <Github size={14} />
                  GitHub
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 text-center sm:text-left">
          <p className="text-xs text-blue-200/40">
            &copy; {currentYear} MailMind AI. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
