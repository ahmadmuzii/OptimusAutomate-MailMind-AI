import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, Tags, FileText, Sliders, Sparkles, ChevronRight } from 'lucide-react';

type Tab = 'Prioritize' | 'Understand' | 'Reply';

const EMAILS = [
  {
    id: '1',
    sender: 'Sarah Chen',
    subject: 'Q3 Marketing Campaign Review',
    preview: 'Hi team, I wanted to schedule a review of our Q3 marketing campaign...',
    urgent: true,
    spam: false,
    time: '10:32 AM',
  },
  {
    id: '2',
    sender: 'Newsletter',
    subject: 'Your weekly AI digest',
    preview: 'Top stories in artificial intelligence this week...',
    urgent: false,
    spam: false,
    time: '9:15 AM',
  },
  {
    id: '3',
    sender: 'Security Alert',
    subject: 'Suspicious login attempt detected',
    preview: 'We noticed a new sign-in to your account from an unrecognized device...',
    urgent: true,
    spam: false,
    time: '8:47 AM',
  },
];

const UNDERSTAND_DATA = {
  intent: 'Meeting Request',
  urgency: 'Medium',
  summary: 'Sarah wants to schedule a Q3 campaign review meeting this week. She is available Wednesday or Thursday afternoon.',
};

const REPLY_DATA = {
  tones: ['Professional', 'Friendly', 'Apologetic', 'Short'],
  drafts: {
    Professional: 'Thank you for reaching out. I appreciate the opportunity to review the Q3 marketing campaign materials. I am available this week on Wednesday or Thursday afternoon. Please let me know which time works best for you.',
    Friendly: 'Hey Sarah, thanks for looping me in on the Q3 campaign review! Wednesday or Thursday afternoon both work for me — just let me know what time suits you best.',
    Apologetic: 'Apologies for the delay in responding. I would be happy to review the Q3 materials. I am available Wednesday or Thursday afternoon. Thank you for your patience.',
    Short: 'Available Wednesday or Thursday afternoon. Happy to review the Q3 materials. Let me know the time.',
  },
};

const TABS: { id: Tab; icon: typeof Sparkles; label: string }[] = [
  { id: 'Prioritize', icon: AlertTriangle, label: 'Prioritize' },
  { id: 'Understand', icon: FileText, label: 'Understand' },
  { id: 'Reply', icon: Sparkles, label: 'Reply' },
];

export default function ProductDemo() {
  const [activeTab, setActiveTab] = useState<Tab>('Prioritize');
  const [selectedEmail, setSelectedEmail] = useState(EMAILS[0]);
  const [replyTone, setReplyTone] = useState('Professional');

  const renderPrioritize = () => (
    <motion.div
      key="prioritize"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
    >
      <div className="space-y-1">
        {EMAILS.map((email) => (
          <button
            key={email.id}
            onClick={() => setSelectedEmail(email)}
            className={`w-full text-left p-3 rounded-lg transition-colors ${
              selectedEmail.id === email.id ? 'bg-[#EAF0FF]' : 'hover:bg-gray-50'
            }`}
          >
            <div className="flex items-center justify-between mb-0.5">
              <span className="text-sm font-semibold text-[#0B1739]">{email.sender}</span>
              <div className="flex items-center gap-1.5">
                {email.urgent && (
                  <span className="text-[10px] font-semibold text-red-600 bg-red-50 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                    <AlertTriangle size={10} />
                    Urgent
                  </span>
                )}
                {email.spam && (
                  <span className="text-[10px] font-semibold text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded-full">
                    Spam
                  </span>
                )}
                <span className="text-[11px] text-gray-400">{email.time}</span>
              </div>
            </div>
            <p className="text-sm font-medium text-gray-700 mb-0.5">{email.subject}</p>
            <p className="text-xs text-gray-400 truncate">{email.preview}</p>
          </button>
        ))}
      </div>
      <div className="mt-3 p-3 bg-amber-50 rounded-lg border border-amber-100">
        <div className="flex items-center gap-2 text-xs font-medium text-amber-700 mb-1">
          <AlertTriangle size={12} />
          Prioritization active
        </div>
        <p className="text-xs text-amber-600">
          Urgent emails are highlighted. Spam and low-priority messages are automatically filtered.
        </p>
      </div>
    </motion.div>
  );

  const renderUnderstand = () => (
    <motion.div
      key="understand"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-4"
    >
      <div className="grid grid-cols-2 gap-3">
        <div className="p-3 bg-[#EAF0FF] rounded-lg">
          <div className="flex items-center gap-1.5 text-[10px] font-medium text-[#2357D9] uppercase tracking-wider mb-1">
            <Tags size={12} />
            Intent
          </div>
          <span className="text-sm font-semibold text-[#0B1739]">{UNDERSTAND_DATA.intent}</span>
        </div>
        <div className="p-3 bg-amber-50 rounded-lg">
          <div className="flex items-center gap-1.5 text-[10px] font-medium text-amber-700 uppercase tracking-wider mb-1">
            <AlertTriangle size={12} />
            Urgency
          </div>
          <span className="text-sm font-semibold text-amber-800">{UNDERSTAND_DATA.urgency}</span>
        </div>
      </div>
      <div className="p-3 bg-white rounded-lg border border-gray-100">
        <div className="flex items-center gap-1.5 text-[10px] font-medium text-gray-400 uppercase tracking-wider mb-1">
          <FileText size={12} />
          Summary
        </div>
        <p className="text-sm text-gray-600 leading-relaxed">{UNDERSTAND_DATA.summary}</p>
      </div>
    </motion.div>
  );

  const renderReply = () => (
    <motion.div
      key="reply"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-4"
    >
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1.5 text-[10px] font-medium text-gray-400 uppercase tracking-wider">
          <Sliders size={12} />
          Tone
        </div>
        <div className="flex flex-wrap gap-1.5">
          {REPLY_DATA.tones.map((tone) => (
            <button
              key={tone}
              onClick={() => setReplyTone(tone)}
              className={`text-xs px-2.5 py-1 rounded-full font-medium transition-all ${
                replyTone === tone
                  ? 'bg-[#2357D9] text-white shadow-sm'
                  : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
              }`}
            >
              {tone}
            </button>
          ))}
        </div>
      </div>
      <div className="p-3 bg-white rounded-lg border border-gray-100 min-h-[80px]">
        <AnimatePresence mode="wait">
          <motion.p
            key={replyTone}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="text-sm text-gray-700 leading-relaxed"
          >
            {REPLY_DATA.drafts[replyTone as keyof typeof REPLY_DATA.drafts]}
          </motion.p>
        </AnimatePresence>
      </div>
      <div className="flex items-center gap-2 text-xs text-emerald-600 font-medium">
        <ChevronRight size={14} />
        Review, edit, save or send
      </div>
    </motion.div>
  );

  return (
    <section className="py-20 sm:py-28 bg-white" id="demo">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1739] leading-tight">
            See MailMind <span className="text-[#2357D9]">in action</span>
          </h2>
        </motion.div>

        <div className="max-w-[900px] mx-auto bg-[#F7F9FC] rounded-2xl border border-gray-200 shadow-xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 bg-white border-b border-gray-100">
            <div className="w-3 h-3 rounded-full bg-red-400" />
            <div className="w-3 h-3 rounded-full bg-yellow-400" />
            <div className="w-3 h-3 rounded-full bg-green-400" />
            <span className="ml-2 text-xs text-gray-400 font-medium">MailMind - Product Demo</span>
          </div>

          <div className="flex border-b border-gray-200 bg-white">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium transition-colors relative ${
                    activeTab === tab.id ? 'text-[#2357D9]' : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  <Icon size={15} />
                  {tab.label}
                  {activeTab === tab.id && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#2357D9]"
                    />
                  )}
                </button>
              );
            })}
          </div>

          <div className="grid md:grid-cols-[280px_1fr]">
            <div className="border-r border-gray-200 p-3 bg-white">
              {renderPrioritize()}
            </div>

            <div className="p-4 bg-white min-h-[280px]">
              <AnimatePresence mode="wait">
                {activeTab === 'Understand' && renderUnderstand()}
                {activeTab === 'Reply' && renderReply()}
                {activeTab === 'Prioritize' && (
                  <motion.div
                    key="prioritize-panel"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex items-center justify-center h-full text-sm text-gray-400"
                  >
                    Select an email from the inbox to analyze
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
