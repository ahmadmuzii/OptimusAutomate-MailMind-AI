import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Mail, RefreshCw, Search, Send, CheckSquare } from 'lucide-react';

const STEPS = [
  { icon: Mail, label: 'Connect Gmail' },
  { icon: RefreshCw, label: 'Sync messages' },
  { icon: Search, label: 'Analyze intent and urgency' },
  { icon: Send, label: 'Generate a reply' },
  { icon: CheckSquare, label: 'Review, edit, save or send' },
];

export default function SolutionSection() {
  const [progress, setProgress] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);
  const [prefersReduced, setPrefersReduced] = useState(false);

  useEffect(() => {
    setPrefersReduced(window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }, []);

  useEffect(() => {
    if (prefersReduced) {
      setProgress(100);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          let start = 0;
          const interval = setInterval(() => {
            start += 2;
            if (start > 100) {
              clearInterval(interval);
              start = 100;
            }
            setProgress(start);
          }, 30);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, [prefersReduced]);

  return (
    <section ref={sectionRef} className="py-20 sm:py-28 bg-[#F7F9FC]" id="product">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1739] leading-tight">
            MailMind handles the first draft. <br className="hidden sm:block" />
            <span className="text-[#2357D9]">You keep the final say.</span>
          </h2>
        </motion.div>

        <div className="relative max-w-5xl mx-auto">
          <div className="absolute top-8 left-8 right-8 h-0.5 bg-gray-200 rounded-full hidden md:block">
            <motion.div
              className="h-full bg-gradient-to-r from-[#2357D9] to-[#4F7CFF] rounded-full"
              style={{ width: `${progress}%` }}
              transition={{ duration: 0.1 }}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6 md:gap-4">
            {STEPS.map((step, index) => {
              const Icon = step.icon;
              const isActive = progress >= ((index + 1) / STEPS.length) * 100;
              return (
                <motion.div
                  key={step.label}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="relative flex flex-col items-center text-center"
                >
                  <motion.div
                    animate={
                      isActive
                        ? { scale: [1, 1.1, 1] }
                        : {}
                    }
                    transition={{ duration: 0.4 }}
                    className={`w-14 h-14 rounded-xl flex items-center justify-center mb-3 border-2 transition-all duration-500 ${
                      isActive
                        ? 'bg-[#2357D9] border-[#2357D9] text-white shadow-lg shadow-[#2357D9]/20'
                        : 'bg-white border-gray-200 text-gray-300'
                    }`}
                  >
                    <Icon size={22} />
                  </motion.div>
                  <span
                    className={`text-xs sm:text-sm font-medium leading-tight transition-colors duration-500 ${
                      isActive ? 'text-[#0B1739]' : 'text-gray-400'
                    }`}
                  >
                    {step.label}
                  </span>
                  {index < STEPS.length - 1 && (
                    <div className="md:hidden w-0.5 h-6 bg-gray-200 mt-2">
                      <motion.div
                        className="w-full bg-[#2357D9]"
                        style={{ height: `${Math.max(0, (progress - ((index + 1) / STEPS.length) * 100) * 3)}%` }}
                      />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
