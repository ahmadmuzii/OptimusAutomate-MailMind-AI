import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles } from 'lucide-react';

const INCOMING_EMAIL = {
  from: 'Sarah Chen <sarah.chen@acmecorp.com>',
  subject: 'Q3 Marketing Campaign Review',
  body: 'Hi team,\n\nI wanted to schedule a review of our Q3 marketing campaign materials before the launch next month. Could we find time this week to go over the creatives and finalize the budget allocation?\n\nLet me know your availability.\n\nThanks!',
};

const DRAFTS: Record<string, string> = {
  Professional:
    'Thank you for reaching out. I appreciate the opportunity to review the Q3 marketing campaign materials. I am available this week on Wednesday or Thursday afternoon. Please let me know which time works best for you.\n\nBest regards',
  Friendly:
    'Hey Sarah,\n\nThanks for looping me in on the Q3 campaign review! I\'d love to go over the creatives this week. Wednesday or Thursday afternoon both work for me — just let me know what time suits you best.\n\nLooking forward to it!',
  Apologetic:
    'Hi Sarah,\n\nApologies for the delay in responding to this. I would be very happy to review the Q3 materials. I am available Wednesday or Thursday afternoon. Please let me know what time works for you and I will be there.\n\nThank you for your patience,\n\nBest regards',
  Short: 'Available Wednesday or Thursday afternoon. Happy to review the Q3 campaign materials. Just let me know the time.',
};

const TONES = ['Professional', 'Friendly', 'Apologetic', 'Short'];

export default function AiShowcase() {
  const [selectedTone, setSelectedTone] = useState('Professional');
  const [prefersReduced, setPrefersReduced] = useState(false);

  useEffect(() => {
    setPrefersReduced(window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }, []);

  return (
    <section className="py-20 sm:py-28 bg-white" id="ai-showcase">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1739] leading-tight">
            AI replies that <span className="text-[#2357D9]">sound like you</span>
          </h2>
        </motion.div>

        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.5 }}
            className="p-5 rounded-2xl bg-[#F7F9FC] border border-gray-200"
          >
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2 h-2 rounded-full bg-green-400" />
              <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Incoming message</span>
            </div>
            <div className="space-y-2">
              <div className="text-xs text-gray-400">
                <span className="font-medium text-gray-600">From:</span> {INCOMING_EMAIL.from}
              </div>
              <div className="text-xs text-gray-400">
                <span className="font-medium text-gray-600">Subject:</span> {INCOMING_EMAIL.subject}
              </div>
              <div className="h-px bg-gray-200" />
              <pre className="text-sm text-gray-700 leading-relaxed font-sans whitespace-pre-wrap">
                {INCOMING_EMAIL.body}
              </pre>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.5 }}
            className="p-5 rounded-2xl bg-gradient-to-br from-[#EAF0FF] to-white border border-[#2357D9]/20"
          >
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={14} className="text-[#2357D9]" />
              <span className="text-xs font-semibold text-[#2357D9] uppercase tracking-wider">MailMind draft</span>
            </div>
            <div className="bg-white/80 rounded-lg p-4 min-h-[180px] border border-[#2357D9]/10">
              <AnimatePresence mode="wait">
                <motion.pre
                  key={selectedTone}
                  initial={prefersReduced ? {} : { opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={prefersReduced ? {} : { opacity: 0, y: -8 }}
                  transition={{ duration: 0.25 }}
                  className="text-sm text-gray-700 leading-relaxed font-sans whitespace-pre-wrap"
                >
                  {DRAFTS[selectedTone]}
                </motion.pre>
              </AnimatePresence>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-wrap items-center justify-center gap-3 mt-8"
        >
          <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">Tone:</span>
          {TONES.map((tone) => (
            <motion.button
              key={tone}
              onClick={() => setSelectedTone(tone)}
              animate={
                selectedTone === tone
                  ? { scale: 1.05 }
                  : { scale: 1 }
              }
              className={`text-sm px-4 py-2 rounded-full font-medium transition-all ${
                selectedTone === tone
                  ? 'bg-[#2357D9] text-white shadow-sm'
                  : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
              }`}
            >
              {tone}
            </motion.button>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
