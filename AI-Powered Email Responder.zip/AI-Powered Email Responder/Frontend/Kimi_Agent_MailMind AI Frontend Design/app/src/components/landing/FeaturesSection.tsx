import { motion } from 'framer-motion';
import {
  MessageSquare,
  Tag,
  AlertTriangle,
  FileText,
  Sliders,
  RefreshCw,
  FileEdit,
  Shield,
  ShieldAlert,
  Users,
  Clock,
  Lock,
} from 'lucide-react';

const FEATURES = [
  {
    icon: MessageSquare,
    title: 'Context-aware replies',
    description: 'Generates responses that reference the full conversation history and your writing patterns.',
  },
  {
    icon: Tag,
    title: 'Intent classification',
    description: 'Automatically categorizes incoming messages by purpose — meeting request, question, follow-up, and more.',
  },
  {
    icon: AlertTriangle,
    title: 'Urgency detection',
    description: 'Flags time-sensitive emails so you never miss an important deadline or client request.',
  },
  {
    icon: FileText,
    title: 'Email summaries',
    description: 'Condenses long threads into a few clear sentences so you can catch up in seconds.',
  },
  {
    icon: Sliders,
    title: 'Tone controls',
    description: 'Switch between Professional, Friendly, Apologetic, and Short tones before generating a draft.',
  },
  {
    icon: RefreshCw,
    title: 'Gmail synchronization',
    description: 'Syncs your Gmail inbox securely via OAuth so MailMind can analyze new messages in real time.',
  },
  {
    icon: FileEdit,
    title: 'Local and Gmail drafts',
    description: 'Drafts are saved both locally and to your Gmail account so you never lose progress.',
  },
  {
    icon: Shield,
    title: 'Human-approved sending',
    description: 'Nothing is sent to a recipient until you personally review and approve the final draft.',
  },
  {
    icon: ShieldAlert,
    title: 'Spam detection',
    description: 'Identifies and flags suspicious messages, phishing attempts, and unwanted bulk email.',
  },
  {
    icon: Users,
    title: 'Secure account separation',
    description: 'Each user\'s Gmail connection and drafts are isolated — no cross-account access is possible.',
  },
  {
    icon: Clock,
    title: 'Automatic inbox polling',
    description: 'Checks for new messages on a regular interval so you always see the latest analysis.',
  },
  {
    icon: Lock,
    title: 'Password-reset security',
    description: 'Password reset flows are protected by email verification and secure token expiration.',
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.05 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4 },
  },
};

export default function FeaturesSection() {
  return (
    <section className="py-20 sm:py-28 bg-[#F7F9FC]" id="features">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1739] leading-tight">
            Everything you need to <br className="hidden sm:block" />
            <span className="text-[#2357D9]">manage your inbox</span>
          </h2>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5"
        >
          {FEATURES.map((feature) => (
            <motion.div
              key={feature.title}
              variants={cardVariants}
              className="group p-5 rounded-xl bg-white border border-gray-100 hover:border-[#4F7CFF]/30 hover:shadow-md hover:shadow-[#4F7CFF]/5 transition-all duration-300 cursor-default"
            >
              <div className="w-9 h-9 rounded-lg bg-[#EAF0FF] flex items-center justify-center mb-3 group-hover:bg-[#2357D9] group-hover:text-white transition-all duration-300">
                <feature.icon size={18} className="text-[#2357D9] group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-sm font-semibold text-[#0B1739] mb-1">{feature.title}</h3>
              <p className="text-xs text-gray-500 leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
