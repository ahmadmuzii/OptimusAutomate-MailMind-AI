import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ToneSelectorProps {
  selected: string;
  onSelect: (tone: string) => void;
  disabled?: boolean;
}

const TONES = ['Professional', 'Friendly', 'Apologetic', 'Short'];

export default function ToneSelector({ selected, onSelect, disabled = false }: ToneSelectorProps) {
  return (
    <div className="inline-flex items-center bg-[#F7F9FC] rounded-lg p-0.5 border border-[#EAF0FF] relative">
      {TONES.map((tone) => (
        <button
          key={tone}
          onClick={() => onSelect(tone)}
          disabled={disabled}
          className={cn(
            'relative z-10 px-3 py-1.5 text-xs font-medium rounded-md transition-colors',
            selected === tone
              ? 'text-white'
              : 'text-gray-500 hover:text-[#0B1739]',
            disabled && 'opacity-50 cursor-not-allowed',
          )}
        >
          {tone}
          {selected === tone && (
            <motion.div
              layoutId="tone-indicator"
              className="absolute inset-0 bg-[#2357D9] rounded-md -z-10"
              transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            />
          )}
        </button>
      ))}
    </div>
  );
}
