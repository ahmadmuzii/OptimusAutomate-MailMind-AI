interface GenerationStatusProps {
  status: 'idle' | 'analyzing' | 'generating' | 'complete' | 'error';
  error?: string;
}

function ShimmerText({ children }: { children: React.ReactNode }) {
  return (
    <span className="relative inline-flex items-center gap-2">
      <span className="inline-block w-2 h-2 rounded-full bg-[#2357D9] animate-pulse" />
      <span className="text-sm text-gray-600">{children}</span>
      <style>{`
        @keyframes shimmer-move {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
        .shimmer-bg {
          background: linear-gradient(
            90deg,
            transparent 0%,
            rgba(37, 99, 235, 0.08) 50%,
            transparent 100%
          );
          background-size: 200% 100%;
          animation: shimmer-move 1.5s ease-in-out infinite;
        }
      `}</style>
      <span className="absolute inset-0 rounded shimmer-bg" />
    </span>
  );
}

export default function GenerationStatus({ status, error }: GenerationStatusProps) {
  if (status === 'idle' || status === 'complete') return null;

  return (
    <div className="flex items-center justify-center py-4">
      {status === 'analyzing' && (
        <ShimmerText>Understanding message...</ShimmerText>
      )}

      {status === 'generating' && (
        <ShimmerText>Preparing reply...</ShimmerText>
      )}

      {status === 'error' && error && (
        <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 px-4 py-2 rounded-lg border border-red-200">
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 flex-shrink-0" />
          {error}
        </div>
      )}
    </div>
  );
}
