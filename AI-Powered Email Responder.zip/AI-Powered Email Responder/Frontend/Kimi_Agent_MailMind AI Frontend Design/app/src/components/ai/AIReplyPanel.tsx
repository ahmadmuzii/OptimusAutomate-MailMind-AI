import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Send, Copy, Save, RotateCcw, Wand2, Ban } from 'lucide-react';
import { cn } from '@/lib/utils';
import ToneSelector from './ToneSelector';
import GenerationStatus from './GenerationStatus';
import type { AnalysisResult } from '@/types';

interface AIReplyPanelProps {
  analysisResult: AnalysisResult | null;
  loading: boolean;
  generating: boolean;
  selectedTone: string;
  replyText: string;
  replySource?: string;
  replyModel?: string | null;
  replyFallbackReason?: string | null;
  replyToneApplied?: boolean;
  onAnalyze: () => void;
  onToneChange: (tone: string) => void;
  onRegenerate: () => void;
  onCopy: () => void;
  onSaveDraft: () => void;
  onSend: () => void;
  error?: string;
}

const URGENCY_STYLES: Record<string, string> = {
  high: 'bg-red-50 text-red-700 border-red-200',
  medium: 'bg-amber-50 text-amber-700 border-amber-200',
  low: 'bg-gray-100 text-gray-600 border-gray-200',
};

function getProviderBadge(provider: string | undefined, context: 'analysis' | 'reply' = 'analysis'): { label: string; style: string } {
  if (provider === 'groq') {
    const label = context === 'reply' ? 'Generated with Groq' : 'Groq';
    return { label, style: 'bg-green-50 text-green-700 border-green-200' };
  }
  if (provider === 'local_rules') {
    const label = context === 'analysis' ? 'Local rules' : 'Local template';
    return { label, style: 'bg-amber-50 text-amber-700 border-amber-200' };
  }
  if (provider === 'none') return { label: 'None', style: 'bg-gray-100 text-gray-500 border-gray-200' };
  return { label: provider || 'Unknown', style: 'bg-gray-100 text-gray-500 border-gray-200' };
}

export default function AIReplyPanel({
  analysisResult,
  loading,
  generating,
  selectedTone,
  replyText,
  replySource = '',
  replyModel = null,
  replyFallbackReason = null,
  replyToneApplied = true,
  onAnalyze,
  onToneChange,
  onRegenerate,
  onCopy,
  onSaveDraft,
  onSend,
  error,
}: AIReplyPanelProps) {
  const hasAnalysis = !!analysisResult;
  const noReply = hasAnalysis && analysisResult.requires_reply === false;
  const isJobAlert = hasAnalysis && analysisResult.category === 'job_alert';
  const analysisProvider = analysisResult?.analysis_provider || '';
  const replyProvider = replySource || analysisResult?.reply_provider || '';

  return (
    <div className="flex flex-col h-full bg-white border-l border-[#EAF0FF]">
      <div className="flex items-center gap-2.5 px-4 py-3.5 border-b border-[#EAF0FF] bg-[#F7F9FC]">
        <div className="w-7 h-7 rounded-lg bg-[#2357D9] flex items-center justify-center">
          <Sparkles size={14} className="text-white" />
        </div>
        <span className="text-sm font-semibold text-[#0B1739]">AI Assistant</span>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {!hasAnalysis && !loading && (
          <div className="flex flex-col items-center text-center py-8">
            <div className="w-12 h-12 rounded-2xl bg-[#EAF0FF] flex items-center justify-center mb-3">
              <Wand2 size={22} className="text-[#2357D9]" />
            </div>
            <p className="text-sm font-medium text-[#0B1739] mb-1">AI-Powered Reply</p>
            <p className="text-xs text-gray-500 mb-4 max-w-[200px]">
              Analyze this email and generate a smart reply with the perfect tone.
            </p>
            <button
              onClick={onAnalyze}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#2357D9] text-white text-sm font-medium hover:bg-[#1a45b8] transition-colors"
            >
              <Sparkles size={15} />
              Analyze & Generate
            </button>
          </div>
        )}

        {(loading || generating) && (
          <GenerationStatus
            status={generating ? 'generating' : 'analyzing'}
            error={error}
          />
        )}

        <AnimatePresence mode="wait">
          {hasAnalysis && (
            <motion.div
              key="analysis-section"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
              className="space-y-4"
            >
              {/* Provider badges */}
              <div className="flex items-center gap-2">
                {analysisProvider && (
                  <span className={cn(
                    'text-[10px] font-medium px-2 py-0.5 rounded-full border',
                    getProviderBadge(analysisProvider).style,
                  )}>
                    Analysis: {getProviderBadge(analysisProvider).label}
                  </span>
                )}
                {replyProvider && replyProvider !== 'none' && (
                  <span className={cn(
                    'text-[10px] font-medium px-2 py-0.5 rounded-full border',
                    getProviderBadge(replyProvider, 'reply').style,
                  )}>
                    {getProviderBadge(replyProvider, 'reply').label}
                  </span>
                )}
                {replyModel && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full border bg-gray-50 text-gray-500 border-gray-200">
                    {replyModel}
                  </span>
                )}
              </div>

              {/* No reply state */}
              {noReply && (
                <div className="bg-gray-50 rounded-xl p-4 border border-gray-200 text-center">
                  <Ban size={20} className="text-gray-400 mx-auto mb-2" />
                  <p className="text-sm font-medium text-gray-700">
                    {isJobAlert ? 'Automated job-alert message' : 'No reply recommended'}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {analysisResult.spam_reason || (isJobAlert
                      ? 'This is an automated job-alert email and does not require a reply.'
                      : 'This appears to be a promotional or automated message.')}
                  </p>
                </div>
              )}

              {/* Category */}
              {analysisResult.category && (
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-1">Category</p>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#EAF0FF] text-[#2357D9]">
                    {analysisResult.category}
                  </span>
                </div>
              )}

              {(analysisResult.intent || analysisResult.urgency) && (
                <div className="flex flex-wrap items-center gap-2">
                  {analysisResult.intent && (
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#EAF0FF] text-[#2357D9]">
                      {analysisResult.intent}
                    </span>
                  )}
                  {analysisResult.urgency && (
                    <span className={cn(
                      'text-xs font-semibold px-2.5 py-1 rounded-full border',
                      URGENCY_STYLES[analysisResult.urgency.toLowerCase()] || URGENCY_STYLES.low,
                    )}>
                      {analysisResult.urgency}
                    </span>
                  )}
                </div>
              )}

              {analysisResult.summary && (
                <div className="bg-[#EAF0FF] rounded-xl p-3 border border-[#2357D9]/10">
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-[#2357D9] mb-1">Summary</p>
                  <p className="text-xs text-[#0B1739] leading-relaxed">{analysisResult.summary}</p>
                </div>
              )}

              {analysisResult.suggested_subject && (
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-1">Suggested Subject</p>
                  <p className="text-xs font-medium text-[#0B1739] bg-[#F7F9FC] rounded-lg px-3 py-2 border border-[#EAF0FF]">
                    {analysisResult.suggested_subject}
                  </p>
                </div>
              )}

              {(!noReply || isJobAlert) && (
                <>
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-2">Tone</p>
                    <ToneSelector
                      selected={selectedTone}
                      onSelect={onToneChange}
                      disabled={generating || isJobAlert}
                    />
                  </div>

                  <div className="relative">
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-2">Generated Reply</p>

                    <div className={cn(
                      'relative rounded-xl border transition-colors',
                      generating ? 'border-[#2357D9]/30' : 'border-[#EAF0FF]',
                    )}>
                      <AnimatePresence mode="popLayout">
                        <motion.div
                          key={replyText}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: generating ? 0.4 : 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <textarea
                            readOnly
                            value={replyText}
                            className={cn(
                              'w-full bg-[#F7F9FC] text-sm text-[#0B1739] rounded-xl p-4 resize-none outline-none leading-relaxed min-h-[140px]',
                              generating && 'cursor-wait',
                            )}
                            style={{ scrollbarWidth: 'thin' }}
                          />
                        </motion.div>
                      </AnimatePresence>

                      {generating && (
                        <div className="absolute inset-0 rounded-xl overflow-hidden pointer-events-none">
                          <style>{`
                            @keyframes shimmer-move {
                              0% { background-position: -200% 0; }
                              100% { background-position: 200% 0; }
                            }
                          `}</style>
                          <div
                            className="absolute inset-0"
                            style={{
                              background: 'linear-gradient(90deg, transparent 0%, rgba(37, 99, 235, 0.06) 50%, transparent 100%)',
                              backgroundSize: '200% 100%',
                              animation: 'shimmer-move 1.5s ease-in-out infinite',
                            }}
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={onRegenerate}
                      disabled={generating || isJobAlert}
                      className={cn(
                        'flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-medium transition-colors',
                        generating || isJobAlert
                          ? 'border-gray-200 text-gray-300 cursor-not-allowed'
                          : 'border-[#EAF0FF] text-gray-600 hover:bg-[#F7F9FC] hover:text-[#0B1739]',
                      )}
                    >
                      <RotateCcw size={13} className={generating ? 'animate-spin' : ''} />
                      Regenerate
                    </button>

                    <button
                      onClick={onCopy}
                      disabled={generating || isJobAlert}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-[#EAF0FF] text-xs font-medium text-gray-600 hover:bg-[#F7F9FC] hover:text-[#0B1739] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Copy size={13} />
                      Copy
                    </button>

                    <button
                      onClick={onSaveDraft}
                      disabled={generating || isJobAlert}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-[#EAF0FF] text-xs font-medium text-gray-600 hover:bg-[#F7F9FC] hover:text-[#0B1739] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Save size={13} />
                      Draft
                    </button>

                    <button
                      onClick={onSend}
                      disabled={generating || isJobAlert}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-[#2357D9] text-white text-xs font-medium hover:bg-[#1a45b8] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Send size={13} />
                      Send
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {error && !loading && !generating && (
          <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 px-4 py-3 rounded-lg border border-red-200">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 flex-shrink-0" />
            {error}
          </div>
        )}
      </div>
    </div>
  );
}
