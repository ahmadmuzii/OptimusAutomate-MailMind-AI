import { Outlet, Link } from 'react-router';
import { motion } from 'framer-motion';
import { Sparkles, Shield, Zap } from 'lucide-react';

const benefits = [
  { icon: Zap, text: 'AI-powered email analysis in seconds' },
  { icon: Sparkles, text: 'Context-aware reply generation' },
  { icon: Shield, text: 'Nothing sent without your approval' },
];

export function AuthLayout() {
  return (
    <div className="min-h-screen flex bg-white">
      <div className="hidden lg:flex lg:w-1/2 relative bg-gradient-to-br from-[#0B1739] via-[#0f1f3d] to-[#1a2d52] p-12 flex-col overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#2357D9]/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-[#7357FF]/15 rounded-full blur-[100px]" />

        <Link to="/" className="flex items-center gap-2.5 relative z-10">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#2357D9] to-[#7357FF] flex items-center justify-center shadow-lg">
            <span className="text-white font-bold text-sm">M</span>
          </div>
          <span className="font-semibold text-white text-lg">MailMind AI</span>
        </Link>

        <div className="flex-1 flex flex-col justify-center max-w-md mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-white leading-tight mb-3">
              Your inbox,<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#4F7CFF] to-[#7357FF]">
                already understood.
              </span>
            </h2>
            <p className="text-blue-200/60 text-sm leading-relaxed mb-8">
              Connect Gmail, identify what matters, and generate accurate replies that match your tone.
            </p>
          </motion.div>

          <div className="space-y-4">
            {benefits.map((item, i) => (
              <motion.div
                key={item.text}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.1, duration: 0.4 }}
                className="flex items-center gap-3"
              >
                <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                  <item.icon size={14} className="text-[#4F7CFF]" />
                </div>
                <span className="text-sm text-blue-200/80">{item.text}</span>
              </motion.div>
            ))}
          </div>
        </div>

        <p className="text-blue-200/30 text-xs relative z-10">
          &copy; {new Date().getFullYear()} MailMind AI
        </p>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-6 lg:p-12">
        <div className="lg:hidden flex items-center gap-2 mb-8">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#2357D9] to-[#7357FF] flex items-center justify-center">
            <span className="text-white font-bold text-xs">M</span>
          </div>
          <span className="font-semibold text-[#0B1739]">MailMind AI</span>
        </div>

        <div className="w-full max-w-sm">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Outlet />
          </motion.div>
        </div>
      </div>
    </div>
  );
}
