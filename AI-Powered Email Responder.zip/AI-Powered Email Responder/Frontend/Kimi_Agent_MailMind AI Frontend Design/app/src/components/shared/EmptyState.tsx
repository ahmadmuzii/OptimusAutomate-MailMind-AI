interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  message: string;
}

export default function EmptyState({ icon, title, message }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      {icon && <div className="mb-4 text-[hsl(220,9%,46%)]">{icon}</div>}
      <h3 className="text-lg font-semibold text-[hsl(222,47%,18%)] mb-1">{title}</h3>
      <p className="text-sm text-[hsl(220,9%,46%)] max-w-sm">{message}</p>
    </div>
  );
}
