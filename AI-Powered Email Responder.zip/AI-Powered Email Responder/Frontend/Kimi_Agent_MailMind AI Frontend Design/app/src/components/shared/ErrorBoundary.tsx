import { Component, type ReactNode, type ErrorInfo } from 'react';
import { Link } from 'react-router';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    console.error('[ErrorBoundary] Caught rendering error:', error);
    console.error('[ErrorBoundary] Component stack:', errorInfo.componentStack);
  }

  handleReload = (): void => {
    window.location.reload();
  };

  render(): ReactNode {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="flex items-center justify-center min-h-[60vh] p-8">
          <div className="bg-white rounded-xl border border-red-200 shadow-sm p-8 max-w-lg w-full text-center">
            <div className="h-14 w-14 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle size={28} className="text-red-500" />
            </div>
            <h2 className="text-lg font-semibold text-[#1a2332] mb-2">
              Something went wrong
            </h2>
            <p className="text-sm text-[#6b7280] mb-2">
              An unexpected error occurred while rendering this page.
            </p>
            {this.state.error && (
              <details className="text-left mb-4">
                <summary className="text-xs text-[#6b7280] cursor-pointer hover:text-[#1a2332]">
                  Error details
                </summary>
                <pre className="mt-2 text-xs bg-[#f5f6fa] border border-[#e5e7eb] rounded-lg p-3 overflow-auto max-h-32 text-red-600">
                  {this.state.error.message}
                </pre>
              </details>
            )}
            <div className="flex items-center justify-center gap-3">
              <Link
                to="/"
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium border border-[#e5e7eb] text-[#1a2332] hover:bg-[#f5f6fa] transition-colors"
              >
                <Home size={14} />
                Dashboard
              </Link>
              <button
                onClick={this.handleReload}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium bg-[#1e3a5f] text-white hover:bg-[#162d4a] transition-colors"
              >
                <RefreshCw size={14} />
                Reload Page
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
