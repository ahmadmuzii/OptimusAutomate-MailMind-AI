import { describe, it, expect } from "vitest"
import { render, screen } from "@testing-library/react"
import ErrorBanner from "./ErrorBanner"

describe("ErrorBanner", () => {
  it("should render with the provided message", () => {
    render(<ErrorBanner message="Backend not reachable" />)

    expect(screen.getByText(/error/i)).toBeInTheDocument()
    expect(screen.getByText("Backend not reachable")).toBeInTheDocument()
  })

  it("should update message when prop changes", () => {
    const { rerender } = render(<ErrorBanner message="First error" />)
    expect(screen.getByText("First error")).toBeInTheDocument()

    rerender(<ErrorBanner message="Second error" />)
    expect(screen.getByText("Second error")).toBeInTheDocument()
  })
})
