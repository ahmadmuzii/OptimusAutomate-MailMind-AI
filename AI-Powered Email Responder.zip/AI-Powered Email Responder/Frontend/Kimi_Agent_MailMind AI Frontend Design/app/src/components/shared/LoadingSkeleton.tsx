interface LoadingSkeletonProps {
  lines?: number;
}

export function LoadingSkeleton({ lines = 5 }: LoadingSkeletonProps) {
  return (
    <div className="space-y-4">
      {Array.from({ length: lines }).map((_, i) => (
        <div key={i} className="space-y-2">
          <div className="h-4 w-24 bg-[hsl(220,14%,93%)] rounded animate-pulse" />
          <div className="h-16 w-full bg-[hsl(220,14%,93%)] rounded-lg animate-pulse" />
        </div>
      ))}
    </div>
  );
}

export default LoadingSkeleton;

export function InboxSkeleton() {
  return (
    <div className="divide-y divide-[hsl(220,13%,88%)]">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="flex items-start gap-3 p-4 animate-pulse">
          <div className="w-10 h-10 rounded-full bg-[hsl(220,14%,88%)] flex-shrink-0" />
          <div className="flex-1 min-w-0 space-y-2 pt-1">
            <div className="h-3.5 w-28 bg-[hsl(220,14%,88%)] rounded" />
            <div className="h-3.5 w-48 bg-[hsl(220,14%,88%)] rounded" />
            <div className="h-3 w-36 bg-[hsl(220,14%,88%)] rounded" />
          </div>
          <div className="flex flex-col items-end gap-2 flex-shrink-0">
            <div className="h-3 w-12 bg-[hsl(220,14%,88%)] rounded" />
            <div className="h-4 w-14 bg-[hsl(220,14%,88%)] rounded-full" />
          </div>
        </div>
      ))}
    </div>
  );
}
