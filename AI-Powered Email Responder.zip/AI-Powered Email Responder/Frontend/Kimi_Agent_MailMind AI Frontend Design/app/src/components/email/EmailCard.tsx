import { cn } from '@/lib/utils';
import { URGENCY_COLORS } from '@/lib/constants';
import type { EmailItem } from '@/types';

interface EmailCardProps {
  email: EmailItem;
  isSelected: boolean;
  onClick: () => void;
}

export default function EmailCard({ email, isSelected, onClick }: EmailCardProps) {
  const receivedDate = email.received_at
    ? new Date(email.received_at).toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    : '';

  const getUrgencyColor = (u: string) => {
    const key = u.toLowerCase();
    if (key.includes('high')) return URGENCY_COLORS.high;
    if (key.includes('medium')) return URGENCY_COLORS.medium;
    return URGENCY_COLORS.low;
  };

  const bodyPreview = email.body
    ? (email.body.length > 120 ? email.body.slice(0, 120) + '...' : email.body)
    : (email.body_preview || '');

  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full text-left p-4 border-b border-[hsl(220,13%,88%)] transition-colors hover:bg-[hsl(220,20%,97%)]',
        isSelected && 'bg-[hsl(220,60%,28%)]/5 border-l-2 border-l-[hsl(220,60%,28%)]',
        !email.is_read && 'bg-[hsl(220,60%,28%)]/[0.02]',
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            {!email.is_read && <span className="w-2 h-2 rounded-full bg-[hsl(220,60%,28%)] flex-shrink-0" />}
            <span className={cn('text-sm font-medium truncate', !email.is_read ? 'text-[hsl(222,47%,18%)]' : 'text-[hsl(220,9%,46%)]')}>
              {email.sender_name || email.sender_email}
            </span>
          </div>
          <p className={cn('text-sm truncate mb-0.5', !email.is_read ? 'font-semibold text-[hsl(222,47%,18%)]' : 'text-[hsl(222,47%,18%)]')}>
            {email.subject}
          </p>
          <p className="text-xs text-[hsl(220,9%,46%)] truncate">{bodyPreview}</p>
        </div>
        <div className="flex flex-col items-end gap-1 flex-shrink-0">
          <span className="text-xs text-[hsl(220,9%,46%)] whitespace-nowrap">{receivedDate}</span>
          {email.intent && (
            <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-[hsl(220,60%,28%)]/10 text-[hsl(220,60%,28%)]">
              {email.intent}
            </span>
          )}
          {email.urgency && (
            <span className={cn('text-[10px] font-semibold px-1.5 py-0.5 rounded border', getUrgencyColor(email.urgency))}>
              {email.urgency}
            </span>
          )}
        </div>
      </div>
    </button>
  );
}
