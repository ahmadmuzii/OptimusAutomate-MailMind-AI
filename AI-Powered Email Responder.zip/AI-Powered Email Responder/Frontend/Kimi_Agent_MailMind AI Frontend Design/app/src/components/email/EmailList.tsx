import { Mail, AlertCircle, FileEdit, ShieldAlert } from 'lucide-react';
import { useMailbox } from '@/context/MailboxContext';
import EmailCard from './EmailCard';
import EmptyState from '@/components/shared/EmptyState';
import { LoadingSkeleton } from '@/components/shared/LoadingSkeleton';

const EMPTY_MESSAGES: Record<string, { title: string; message: string; icon: React.ReactNode }> = {
  inbox: {
    title: 'No incoming emails yet',
    message: 'When you receive or analyze emails, they will appear here.',
    icon: <Mail size={40} />,
  },
  urgent: {
    title: 'No urgent emails detected',
    message: 'High urgency emails will appear here.',
    icon: <AlertCircle size={40} />,
  },
  spam: {
    title: 'No spam emails detected',
    message: 'Emails classified as spam will appear here.',
    icon: <ShieldAlert size={40} />,
  },
  drafts: {
    title: 'No saved drafts yet',
    message: 'When you save a draft, it will appear here.',
    icon: <FileEdit size={40} />,
  },
};

export default function EmailList() {
  const { currentFolder, emails, selectedEmail, selectEmail, loadingEmails } = useMailbox();

  if (loadingEmails) {
    return (
      <div className="p-4">
        <LoadingSkeleton lines={5} />
      </div>
    );
  }

  if (emails.length === 0) {
    const empty = EMPTY_MESSAGES[currentFolder] || EMPTY_MESSAGES.inbox;
    return <EmptyState icon={empty.icon} title={empty.title} message={empty.message} />;
  }

  return (
    <div className="divide-y divide-[hsl(220,13%,88%)]">
      {emails.map((email) => (
        <EmailCard
          key={email.id}
          email={email}
          isSelected={selectedEmail?.id === email.id}
          onClick={() => selectEmail(email)}
        />
      ))}
    </div>
  );
}
