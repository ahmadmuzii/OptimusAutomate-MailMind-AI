import { ArrowLeft, Trash2 } from 'lucide-react';
import { useMailbox } from '@/context/MailboxContext';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { URGENCY_COLORS } from '@/lib/constants';

export default function EmailDetails() {
  const { selectedEmail, selectEmail, currentFolder, deleteDraft } = useMailbox();

  if (!selectedEmail) return null;

  const receivedDate = selectedEmail.received_at
    ? new Date(selectedEmail.received_at).toLocaleString('en-US', {
        dateStyle: 'full',
        timeStyle: 'short',
      })
    : '';

  const getUrgencyColor = (u: string) => {
    const key = u.toLowerCase();
    if (key.includes('high')) return URGENCY_COLORS.high;
    if (key.includes('medium')) return URGENCY_COLORS.medium;
    return URGENCY_COLORS.low;
  };

  const handleBack = () => {
    selectEmail(null);
  };

  const handleDeleteDraft = async () => {
    if (currentFolder === 'drafts') {
      await deleteDraft(selectedEmail.id);
      selectEmail(null);
    }
  };

  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={handleBack}
          className="flex items-center gap-2 text-sm text-[hsl(220,9%,46%)] hover:text-[hsl(222,47%,18%)] transition-colors"
        >
          <ArrowLeft size={16} /> Back
        </button>
        {currentFolder === 'drafts' && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleDeleteDraft}
            className="text-red-600 border-red-200 hover:bg-red-50"
          >
            <Trash2 size={14} className="mr-1" /> Delete Draft
          </Button>
        )}
      </div>

      <div className="space-y-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)] mb-1">From</p>
          <p className="text-sm font-medium text-[hsl(222,47%,18%)]">
            {selectedEmail.sender_name ? `${selectedEmail.sender_name} <${selectedEmail.sender_email}>` : selectedEmail.sender_email}
          </p>
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)] mb-1">Subject</p>
          <p className="text-sm font-medium text-[hsl(222,47%,18%)]">{selectedEmail.subject}</p>
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)] mb-1">Received</p>
          <p className="text-sm text-[hsl(220,9%,46%)]">{receivedDate}</p>
        </div>

        {selectedEmail.intent && (
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)] mb-1">Classification</p>
            <div className="flex gap-2">
              <span className="text-xs font-semibold px-2 py-1 rounded bg-[hsl(220,60%,28%)]/10 text-[hsl(220,60%,28%)]">
                {selectedEmail.intent}
              </span>
              {selectedEmail.urgency && (
                <span className={cn('text-xs font-semibold px-2 py-1 rounded border', getUrgencyColor(selectedEmail.urgency))}>
                  {selectedEmail.urgency}
                </span>
              )}
            </div>
          </div>
        )}

        {selectedEmail.summary && (
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)] mb-1">Summary</p>
            <p className="text-sm text-[hsl(222,47%,18%)] bg-[hsl(220,20%,97%)] rounded-lg p-3">{selectedEmail.summary}</p>
          </div>
        )}

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)] mb-1">Email Body</p>
          <div className="text-sm text-[hsl(222,47%,18%)] bg-[hsl(220,20%,97%)] rounded-lg p-4 whitespace-pre-wrap leading-relaxed max-h-80 overflow-y-auto">
            {selectedEmail.body}
          </div>
        </div>
      </div>
    </div>
  );
}
