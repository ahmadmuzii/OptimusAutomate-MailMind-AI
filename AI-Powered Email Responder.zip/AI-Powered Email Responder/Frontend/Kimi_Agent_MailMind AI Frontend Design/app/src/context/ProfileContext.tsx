import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import { fetchProfile, updateProfile as updateProfileApi, uploadProfilePicture, deleteProfilePicture } from '@/services/emailService';
import type { ProfileData } from '@/types';

export interface ProfileContextValue {
  profile: ProfileData | null;
  loading: boolean;
  updateProfile: (data: { full_name?: string; email?: string }) => Promise<void>;
  uploadPicture: (file: File) => Promise<void>;
  removePicture: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const ProfileContext = createContext<ProfileContextValue | null>(null);

export function ProfileProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(false);

  const refreshProfile = useCallback(async () => {
    try {
      const data = await fetchProfile();
      setProfile(data);
    } catch {
      // silently fail
    }
  }, []);

  const updateProfile = useCallback(async (data: { full_name?: string; email?: string }) => {
    setLoading(true);
    try {
      const result = await updateProfileApi(data);
      setProfile(result);
    } finally {
      setLoading(false);
    }
  }, []);

  const uploadPicture = useCallback(async (file: File) => {
    setLoading(true);
    try {
      const result = await uploadProfilePicture(file);
      setProfile(result);
    } finally {
      setLoading(false);
    }
  }, []);

  const removePicture = useCallback(async () => {
    setLoading(true);
    try {
      const result = await deleteProfilePicture();
      setProfile(result);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshProfile();
  }, [refreshProfile]);

  return (
    <ProfileContext.Provider value={{ profile, loading, updateProfile, uploadPicture, removePicture, refreshProfile }}>
      {children}
    </ProfileContext.Provider>
  );
}

export function useProfile() {
  const ctx = useContext(ProfileContext);
  if (!ctx) throw new Error('useProfile must be used within ProfileProvider');
  return ctx;
}
