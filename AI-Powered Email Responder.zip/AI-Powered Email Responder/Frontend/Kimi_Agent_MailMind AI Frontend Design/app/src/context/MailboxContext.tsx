import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import { fetchEmails, fetchMailboxCounts, analyzeEmailApi } from '@/services/emailService';
import { draftService } from '@/services/draftService';
import type { EmailItem, MailboxCounts, AnalysisResult, EmailFormData, DraftData } from '@/types';

function normalizeEmails(responseData: unknown): EmailItem[] {
  if (Array.isArray(responseData)) {
    return responseData;
  }
  if (responseData && typeof responseData === 'object') {
    const obj = responseData as Record<string, unknown>;
    if (Array.isArray(obj.emails)) return obj.emails;
    if (Array.isArray(obj.items)) return obj.items;
    if (Array.isArray(obj.data)) return obj.data;
  }
  return [];
}

export interface MailboxState {
  currentFolder: string;
  emails: EmailItem[];
  counts: MailboxCounts;
  drafts: DraftData[];
  selectedEmail: EmailItem | null;
  analysisResult: AnalysisResult | null;
  emailForm: EmailFormData;
  loadingEmails: boolean;
  loadingAnalysis: boolean;
  error: string | null;
  searchQuery: string;
  intentFilter: string;
  urgencyFilter: string;
  page: number;
}

export interface MailboxContextValue extends MailboxState {
  selectFolder: (folder: string) => void;
  selectEmail: (email: EmailItem | null) => void;
  setEmailForm: (data: EmailFormData) => void;
  clearEmailForm: () => void;
  analyzeEmail: (data: EmailFormData) => Promise<void>;
  saveDraft: (recipient: string, subject: string, body: string, tone?: string) => Promise<void>;
  updateDraft: (id: number, data: Partial<{ recipient: string; subject: string; body: string; tone: string }>) => Promise<void>;
  deleteDraft: (id: number) => Promise<void>;
  clearAnalysis: () => void;
  refreshCounts: () => Promise<void>;
  refreshEmails: () => Promise<void>;
  setSearchQuery: (q: string) => void;
  setIntentFilter: (f: string) => void;
  setUrgencyFilter: (f: string) => void;
  setPage: (p: number) => void;
}

const defaultForm: EmailFormData = { sender: '', subject: '', email_body: '', tone: 'Professional' };

const MailboxContext = createContext<MailboxContextValue | null>(null);

export function MailboxProvider({ children }: { children: ReactNode }) {
  const [currentFolder, setCurrentFolder] = useState('inbox');
  const [emails, setEmails] = useState<EmailItem[]>([]);
  const [counts, setCounts] = useState<MailboxCounts>({ inbox: 0, drafts: 0, urgent: 0, spam: 0 });
  const [drafts, setDrafts] = useState<DraftData[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<EmailItem | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [emailForm, setEmailForm] = useState<EmailFormData>(defaultForm);
  const [loadingEmails, setLoadingEmails] = useState(false);
  const [loadingAnalysis, setLoadingAnalysis] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [intentFilter, setIntentFilter] = useState('all');
  const [urgencyFilter, setUrgencyFilter] = useState('all');
  const [page, setPage] = useState(1);

  const refreshCounts = useCallback(async () => {
    try {
      const data = await fetchMailboxCounts();
      setCounts(data);
    } catch {
      // silently fail
    }
  }, []);

  const loadEmails = useCallback(async (folder: string, search?: string, intent?: string, urgency?: string, p?: number) => {
    setLoadingEmails(true);
    setError(null);
    try {
      if (folder === 'drafts') {
        const draftItems = await draftService.fetchDrafts();
        setDrafts(draftItems);
        setEmails([]);
      } else {
        const params: Record<string, string | number> = {};
        if (folder !== 'inbox') params.folder = folder;
        if (search) params.search = search;
        if (intent && intent !== 'all') params.intent = intent;
        if (urgency && urgency !== 'all') params.urgency = urgency;
        if (p) params.page = p;
        const data = await fetchEmails(params);
        setEmails(normalizeEmails(data));
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load emails');
    } finally {
      setLoadingEmails(false);
    }
  }, []);

  const selectFolder = useCallback((folder: string) => {
    setCurrentFolder(folder);
    setSelectedEmail(null);
    setAnalysisResult(null);
    setEmailForm(defaultForm);
    setSearchQuery('');
    setIntentFilter('all');
    setUrgencyFilter('all');
    setPage(1);
    loadEmails(folder);
    refreshCounts();
  }, [loadEmails, refreshCounts]);

  const selectEmail = useCallback((email: EmailItem | null) => {
    setSelectedEmail(email);
    if (email) {
      setEmailForm({
        sender: email.sender_email || email.sender_name || '',
        subject: email.subject,
        email_body: email.body || email.body_preview || '',
        tone: 'Professional',
      });
      if (email.intent && email.urgency) {
        setAnalysisResult({
          email_id: email.id,
          intent: email.intent,
          urgency: email.urgency,
          summary: email.summary || '',
          suggested_subject: `Re: ${email.subject}`,
          reply: '',
        });
      } else {
        setAnalysisResult(null);
      }
    }
  }, []);

  const refreshEmails = useCallback(async () => {
    await loadEmails(currentFolder, searchQuery, intentFilter, urgencyFilter, page);
  }, [currentFolder, searchQuery, intentFilter, urgencyFilter, page, loadEmails]);

  const analyzeEmail = useCallback(async (data: EmailFormData) => {
    setLoadingAnalysis(true);
    setError(null);
    try {
      const result = await analyzeEmailApi(data);
      setAnalysisResult(result);
      refreshCounts();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to analyze email';
      setError(msg);
      throw err;
    } finally {
      setLoadingAnalysis(false);
    }
  }, [refreshCounts]);

  const saveDraftFn = useCallback(async (recipient: string, subject: string, body: string, tone = 'Professional') => {
    try {
      await draftService.createDraft({ recipient, subject, body, tone });
      if (currentFolder === 'drafts') {
        loadEmails('drafts');
      }
      refreshCounts();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to save draft';
      setError(msg);
    }
  }, [currentFolder, loadEmails, refreshCounts]);

  const updateDraftFn = useCallback(async (id: number, data: Partial<{ recipient: string; subject: string; body: string; tone: string }>) => {
    try {
      await draftService.updateDraft(id, data);
      if (currentFolder === 'drafts') {
        loadEmails('drafts');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to update draft';
      setError(msg);
    }
  }, [currentFolder, loadEmails]);

  const deleteDraftFn = useCallback(async (id: number) => {
    try {
      await draftService.deleteDraft(id);
      if (currentFolder === 'drafts') {
        loadEmails('drafts');
      }
      refreshCounts();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to delete draft';
      setError(msg);
    }
  }, [currentFolder, loadEmails, refreshCounts]);

  const clearAnalysis = useCallback(() => {
    setAnalysisResult(null);
  }, []);

  useEffect(() => {
    refreshCounts();
    loadEmails(currentFolder);
  }, []);

  return (
    <MailboxContext.Provider
      value={{
        currentFolder,
        emails,
        counts,
        drafts,
        selectedEmail,
        analysisResult,
        emailForm,
        loadingEmails,
        loadingAnalysis,
        error,
        searchQuery,
        intentFilter,
        urgencyFilter,
        page,
        selectFolder,
        selectEmail,
        setEmailForm,
        clearEmailForm: () => setEmailForm(defaultForm),
        analyzeEmail,
        saveDraft: saveDraftFn,
        updateDraft: updateDraftFn,
        deleteDraft: deleteDraftFn,
        clearAnalysis,
        refreshCounts,
        refreshEmails,
        setSearchQuery: (q: string) => { setSearchQuery(q); setPage(1); },
        setIntentFilter: (f: string) => { setIntentFilter(f); setPage(1); },
        setUrgencyFilter: (f: string) => { setUrgencyFilter(f); setPage(1); },
        setPage,
      }}
    >
      {children}
    </MailboxContext.Provider>
  );
}

export function useMailbox() {
  const ctx = useContext(MailboxContext);
  if (!ctx) throw new Error('useMailbox must be used within MailboxProvider');
  return ctx;
}
