import { Link } from 'react-router';
import { ArrowLeft, Brain } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[hsl(220,20%,97%)] flex items-center justify-center p-4">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[hsl(210,100%,50%)] to-[hsl(220,60%,35%)] flex items-center justify-center mx-auto mb-6 shadow-lg shadow-blue-500/20">
          <Brain size={32} className="text-white" />
        </div>
        <h1 className="text-4xl font-bold text-[hsl(222,47%,18%)] mb-2">404</h1>
        <p className="text-[hsl(220,9%,46%)] mb-8">This page doesn't exist or has been moved.</p>
        <Link to="/">
          <Button className="h-11 px-6 bg-[hsl(220,60%,28%)] hover:bg-[hsl(220,60%,23%)] text-white rounded-lg font-semibold">
            <ArrowLeft size={18} className="mr-2" />Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}
