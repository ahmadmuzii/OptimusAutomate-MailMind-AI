import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileEdit, Copy, Trash2, Send, ChevronDown, ChevronUp, ExternalLink, Save } from 'lucide-react';
import { toast } from 'sonner';
import { draftService } from '@/services/draftService';
import { gmailService } from '@/services/gmailService';
import EmptyState from '@/components/common/EmptyState';
import ConfirmationModal from '@/components/common/ConfirmationModal';
import { CardSkeleton } from '@/components/common/LoadingSkeleton';
import type { DraftData } from '@/types';

const statusConfig: Record<string, { label: string; classes: string }> = {
  local: { label: 'Local', classes: 'bg-amber-50 text-amber-700 border-amber-200' },
  gmail: { label: 'Gmail', classes: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  sent: { label: 'Sent', classes: 'bg-green-50 text-green-700 border-green-200' },
  failed: { label: 'Failed', classes: 'bg-red-50 text-red-700 border-red-200' },
};

export default function DraftsPage() {
  const [drafts, setDrafts] = useState<DraftData[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState({ recipient: '', subject: '', body: '' });
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<DraftData | null>(null);
  const [sendTarget, setSendTarget] = useState<DraftData | null>(null);
  const [sending, setSending] = useState(false);

  const loadDrafts = async () => {
    setLoading(true);
    try {
      const data = await draftService.fetchDrafts();
      setDrafts(data);
    } catch {
      toast.error('Failed to load drafts');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadDrafts(); }, []);

  const handleCopy = (body: string) => {
    navigator.clipboard.writeText(body);
    toast.success('Body copied to clipboard');
  };

  const handleStartEdit = (draft: DraftData) => {
    setEditingId(draft.id);
    setEditForm({ recipient: draft.recipient, subject: draft.subject, body: draft.body });
  };

  const handleSaveEdit = async (id: number) => {
    setSaving(true);
    try {
      await draftService.updateDraft(id, editForm);
      toast.success('Draft updated');
      setEditingId(null);
      loadDrafts();
    } catch {
      toast.error('Failed to update draft');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await draftService.deleteDraft(deleteTarget.id);
      toast.success('Draft deleted');
      setDeleteTarget(null);
      loadDrafts();
    } catch {
      toast.error('Failed to delete draft');
    }
  };

  const handleCreateGmailDraft = async (id: number) => {
    try {
      await draftService.createGmailDraft(id);
      toast.success('Gmail draft created');
      loadDrafts();
    } catch {
      toast.error('Failed to create Gmail draft');
    }
  };

  const handleSend = async () => {
    if (!sendTarget) return;
    setSending(true);
    try {
      await gmailService.sendEmail(sendTarget.id);
      toast.success('Email sent successfully');
      setSendTarget(null);
      loadDrafts();
    } catch {
      toast.error('Failed to send email');
    } finally {
      setSending(false);
    }
  };

  const formatDate = (d: string | null) => {
    if (!d) return '';
    return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  if (loading) return <div className="max-w-4xl mx-auto"><CardSkeleton count={5} /></div>;

  if (drafts.length === 0) {
    return (
      <div className="max-w-4xl mx-auto">
        <EmptyState icon={FileEdit} title="No drafts" message="Your saved drafts will appear here" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#0B1739]">Drafts</h1>
          <p className="text-sm text-gray-500 mt-1">{drafts.length} draft{drafts.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      <AnimatePresence mode="popLayout">
        {drafts.map((draft, idx) => (
          <motion.div
            key={draft.id}
            layout
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97 }}
            transition={{ delay: idx * 0.03, duration: 0.25 }}
            className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
          >
            <div
              className="flex items-center justify-between p-4 cursor-pointer hover:bg-[#F7F9FC] transition-colors"
              onClick={() => setExpandedId(expandedId === draft.id ? null : draft.id)}
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <div className="h-9 w-9 rounded-xl bg-[#EAF0FF] flex items-center justify-center shrink-0">
                  <FileEdit size={18} className="text-[#2357D9]" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-[#0B1739] truncate">{draft.subject || 'No subject'}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium shrink-0 ${statusConfig[draft.status]?.classes || statusConfig.local.classes}`}>
                      {statusConfig[draft.status]?.label || 'Local'}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 truncate mt-0.5">To: {draft.recipient}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[11px] text-gray-400 hidden sm:block">{formatDate(draft.updated_at || draft.created_at)}</span>
                {expandedId === draft.id ? <ChevronUp size={16} className="text-gray-400" /> : <ChevronDown size={16} className="text-gray-400" />}
              </div>
            </div>

            <AnimatePresence>
              {expandedId === draft.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2, ease: 'easeInOut' }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 border-t border-gray-50 pt-4">
                    {editingId === draft.id ? (
                      <div className="space-y-3">
                        <div>
                          <label className="block text-xs font-medium text-gray-500 mb-1">Recipient</label>
                          <input
                            type="email"
                            value={editForm.recipient}
                            onChange={(e) => setEditForm({ ...editForm, recipient: e.target.value })}
                            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] focus:border-transparent bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-500 mb-1">Subject</label>
                          <input
                            type="text"
                            value={editForm.subject}
                            onChange={(e) => setEditForm({ ...editForm, subject: e.target.value })}
                            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] focus:border-transparent bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-500 mb-1">Body</label>
                          <textarea
                            rows={5}
                            value={editForm.body}
                            onChange={(e) => setEditForm({ ...editForm, body: e.target.value })}
                            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] focus:border-transparent bg-white resize-none"
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleSaveEdit(draft.id)}
                            disabled={saving}
                            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#2357D9] text-white rounded-xl text-sm font-medium hover:bg-[#1a45b8] transition disabled:opacity-50"
                          >
                            <Save size={14} /> {saving ? 'Saving...' : 'Save'}
                          </button>
                          <button
                            onClick={() => setEditingId(null)}
                            className="px-4 py-2 rounded-xl text-sm font-medium bg-gray-100 text-gray-600 hover:bg-gray-200 transition"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="grid grid-cols-2 gap-4 mb-3 text-sm">
                          <div>
                            <span className="text-xs text-gray-400 block">To</span>
                            <span className="text-[#0B1739] font-medium">{draft.recipient}</span>
                          </div>
                          <div>
                            <span className="text-xs text-gray-400 block">Subject</span>
                            <span className="text-[#0B1739] font-medium">{draft.subject || 'No subject'}</span>
                          </div>
                        </div>
                        <div className="bg-[#F7F9FC] rounded-xl p-4 mb-3">
                          <p className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">{draft.body}</p>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <button
                            onClick={() => handleStartEdit(draft)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-[#EAF0FF] text-[#2357D9] hover:bg-[#d4e2ff] transition"
                          >
                            <FileEdit size={13} /> Edit
                          </button>
                          <button
                            onClick={() => handleCopy(draft.body)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-gray-100 text-gray-600 hover:bg-gray-200 transition"
                          >
                            <Copy size={13} /> Copy
                          </button>
                          <button
                            onClick={() => handleCreateGmailDraft(draft.id)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-gray-100 text-gray-600 hover:bg-gray-200 transition"
                          >
                            <ExternalLink size={13} /> Gmail Draft
                          </button>
                          <button
                            onClick={() => setSendTarget(draft)}
                            disabled={draft.status === 'sent'}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-[#2357D9] text-white hover:bg-[#1a45b8] transition disabled:opacity-40"
                          >
                            <Send size={13} /> Send
                          </button>
                          <button
                            onClick={() => setDeleteTarget(draft)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-red-50 text-red-600 hover:bg-red-100 transition ml-auto"
                          >
                            <Trash2 size={13} /> Delete
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </AnimatePresence>

      <ConfirmationModal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Draft"
        message={`Are you sure you want to delete "${deleteTarget?.subject || 'this draft'}"? This action cannot be undone.`}
        confirmLabel="Delete"
        variant="danger"
      />

      <ConfirmationModal
        open={!!sendTarget}
        onClose={() => setSendTarget(null)}
        onConfirm={handleSend}
        title="Send Email"
        message={`Send "${sendTarget?.subject || 'this draft'}" via Gmail?`}
        confirmLabel={sending ? 'Sending...' : 'Send'}
        variant="success"
        loading={sending}
      />
    </div>
  );
}
