import { useState, useCallback } from 'react';
import { Search, ArrowLeft } from 'lucide-react';
import { useMailbox } from '@/context/MailboxContext';
import { fetchEmail, markAsRead, markAsSpam, deleteEmail, generateReply, analyzeExistingEmail } from '@/services/emailService';
import { draftService } from '@/services/draftService';
import { gmailService } from '@/services/gmailService';
import MailList from '@/components/inbox/MailList';
import EmailReader from '@/components/inbox/EmailReader';
import AIReplyPanel from '@/components/ai/AIReplyPanel';
import ConfirmationModal from '@/components/common/ConfirmationModal';
import { toast } from 'sonner';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import type { EmailItem, AnalysisResult } from '@/types';

const INTENT_OPTIONS = [
  { value: 'all', label: 'All Intents' },
  { value: 'Meeting Request', label: 'Meeting Request' },
  { value: 'Question', label: 'Question' },
  { value: 'Inquiry', label: 'Inquiry' },
  { value: 'Complaint', label: 'Complaint' },
  { value: 'Support', label: 'Support' },
  { value: 'Feedback', label: 'Feedback' },
];

const URGENCY_OPTIONS = [
  { value: 'all', label: 'All Urgency' },
  { value: 'High', label: 'High' },
  { value: 'Medium', label: 'Medium' },
  { value: 'Low', label: 'Low' },
];

export default function InboxPage() {
  const {
    emails, loadingEmails, error,
    searchQuery, intentFilter, urgencyFilter,
    refreshEmails, refreshCounts,
    setSearchQuery, setIntentFilter, setUrgencyFilter,
  } = useMailbox();

  const [selectedEmail, setSelectedEmail] = useState<EmailItem | null>(null);
  const [emailLoading, setEmailLoading] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [loadingAnalysis, setLoadingAnalysis] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [selectedTone, setSelectedTone] = useState('Professional');
  const [replyText, setReplyText] = useState('');
  const [replySource, setReplySource] = useState<string>('');
  const [replyModel, setReplyModel] = useState<string | null>(null);
  const [replyFallbackReason, setReplyFallbackReason] = useState<string | null>(null);
  const [replyToneApplied, setReplyToneApplied] = useState(true);
  const [showSendConfirm, setShowSendConfirm] = useState(false);
  const [sending, setSending] = useState(false);
  const [showMobilePanel, setShowMobilePanel] = useState<'list' | 'reader' | 'ai'>('list');
  const [readerTab, setReaderTab] = useState<'reader' | 'ai'>('reader');
  const [localSearch, setLocalSearch] = useState(searchQuery);

  const handleSearch = useCallback(() => {
    setSearchQuery(localSearch);
    refreshEmails();
  }, [localSearch, setSearchQuery, refreshEmails]);

  const handleFilterChange = useCallback((filterType: 'intent' | 'urgency', value: string) => {
    if (filterType === 'intent') {
      setIntentFilter(value);
    } else {
      setUrgencyFilter(value);
    }
    refreshEmails();
  }, [setIntentFilter, setUrgencyFilter, refreshEmails]);

  const handleSelectEmail = async (email: EmailItem) => {
    setAnalysisResult(null);
    setReplyText('');
    setReplySource('');
    setReplyModel(null);
    setReplyFallbackReason(null);
    setReplyToneApplied(true);
    setShowMobilePanel('reader');
    setReaderTab('reader');
    setEmailLoading(true);
    setEmailError(null);

    if (!email.is_read) {
      markAsRead(email.id).catch(() => {});
    }

    try {
      const fullEmail = await fetchEmail(email.id);
      setSelectedEmail(fullEmail);
    } catch {
      setEmailError('Failed to load email body.');
      setSelectedEmail(email);
      toast.error('Could not load email body');
    } finally {
      setEmailLoading(false);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedEmail) return;
    setLoadingAnalysis(true);
    try {
      const result = await analyzeExistingEmail(selectedEmail.id);
      setAnalysisResult(result);
      if (result.reply && result.reply_generated !== false) {
        setReplyText(result.reply);
      } else {
        setReplyText('');
      }
      toast.success('Email analyzed successfully');
    } catch {
      toast.error('Failed to analyze email');
    } finally {
      setLoadingAnalysis(false);
    }
  };

  const handleGenerateReply = async (tone?: string) => {
    if (!selectedEmail) return;
    const currentTone = tone || selectedTone;
    setGenerating(true);
    try {
      const result = await generateReply(selectedEmail.id, currentTone, replyText || undefined);
      setReplySource(result.source || '');
      setReplyModel(result.model ?? null);
      setReplyFallbackReason(result.fallback_reason ?? null);
      setReplyToneApplied(result.tone_applied ?? true);
      if (result.reply_generated === false) {
        setReplyText('');
        if (result.message) {
          toast.info(result.message);
        }
      } else {
        setReplyText(result.reply);
        setSelectedTone(result.tone || currentTone);
        toast.success('Reply generated');
      }
    } catch {
      toast.error('Failed to generate reply');
    } finally {
      setGenerating(false);
    }
  };

  const handleRegenerate = () => handleGenerateReply(selectedTone);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(replyText);
      toast.success('Reply copied to clipboard');
    } catch {
      toast.error('Failed to copy');
    }
  };

  const handleSaveDraft = async () => {
    if (!selectedEmail || !replyText) return;
    try {
      await draftService.createDraft({
        email_id: selectedEmail.id,
        recipient: selectedEmail.sender_email,
        subject: `Re: ${selectedEmail.subject}`,
        body: replyText,
        tone: selectedTone,
      });
      await refreshCounts();
      toast.success('Draft saved');
    } catch {
      toast.error('Failed to save draft');
    }
  };

  const handleSend = async () => {
    if (!selectedEmail || !replyText) return;
    setSending(true);
    try {
      const draft = await draftService.createDraft({
        email_id: selectedEmail.id,
        recipient: selectedEmail.sender_email,
        subject: `Re: ${selectedEmail.subject}`,
        body: replyText,
        tone: selectedTone,
      });
      await gmailService.sendEmail(draft.id);
      toast.success('Email sent successfully');
      setShowSendConfirm(false);
      setReplyText('');
    } catch {
      toast.error('Failed to send email');
    } finally {
      setSending(false);
    }
  };

  const handleMarkSpam = async () => {
    if (!selectedEmail) return;
    try {
      await markAsSpam(selectedEmail.id);
      toast.success('Email marked as spam');
      setSelectedEmail(null);
      setAnalysisResult(null);
      setReplyText('');
      refreshEmails();
    } catch {
      toast.error('Failed to mark as spam');
    }
  };

  const handleDelete = async () => {
    if (!selectedEmail) return;
    try {
      await deleteEmail(selectedEmail.id);
      toast.success('Email deleted');
      setSelectedEmail(null);
      setAnalysisResult(null);
      setReplyText('');
      refreshEmails();
    } catch {
      toast.error('Failed to delete email');
    }
  };

  const filtersAndSearch = (
    <div className="p-3 border-b border-[#EAF0FF] space-y-2 bg-white">
      <div className="relative">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
        <input
          placeholder="Search emails..."
          value={localSearch}
          onChange={(e) => setLocalSearch(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') handleSearch(); }}
          className="w-full h-9 pl-9 pr-3 text-sm rounded-lg bg-[#F7F9FC] border border-[#EAF0FF] text-[#0B1739] placeholder-gray-400 outline-none focus:border-[#2357D9] focus:ring-1 focus:ring-[#2357D9]/20 transition-colors"
        />
      </div>
      <div className="flex items-center gap-2">
        <Select value={intentFilter} onValueChange={(v) => handleFilterChange('intent', v)}>
          <SelectTrigger className="h-8 text-xs flex-1">
            <SelectValue placeholder="Intent" />
          </SelectTrigger>
          <SelectContent>
            {INTENT_OPTIONS.map((o) => (
              <SelectItem key={o.value} value={o.value} className="text-xs">{o.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={urgencyFilter} onValueChange={(v) => handleFilterChange('urgency', v)}>
          <SelectTrigger className="h-8 text-xs flex-1">
            <SelectValue placeholder="Urgency" />
          </SelectTrigger>
          <SelectContent>
            {URGENCY_OPTIONS.map((o) => (
              <SelectItem key={o.value} value={o.value} className="text-xs">{o.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );

  const mobileTopBar = (
    <div className="flex items-center border-b border-[#EAF0FF] bg-white">
      <button
        onClick={() => setShowMobilePanel('list')}
        className="flex items-center gap-1.5 px-3 py-3 text-sm font-medium text-gray-500 hover:text-[#0B1739] transition-colors"
      >
        <ArrowLeft size={16} />
        Back
      </button>
      <div className="flex flex-1 justify-center pr-12">
        <div className="flex bg-[#F7F9FC] rounded-lg p-0.5">
          <button
            onClick={() => setReaderTab('reader')}
            className={`px-4 py-1.5 text-xs font-medium rounded-md transition-colors ${
              readerTab === 'reader' ? 'bg-white text-[#0B1739] shadow-sm' : 'text-gray-500'
            }`}
          >
            Email
          </button>
          <button
            onClick={() => setReaderTab('ai')}
            className={`px-4 py-1.5 text-xs font-medium rounded-md transition-colors ${
              readerTab === 'ai' ? 'bg-white text-[#0B1739] shadow-sm' : 'text-gray-500'
            }`}
          >
            AI Reply
          </button>
        </div>
      </div>
    </div>
  );

  const mailListPanel = (
    <div className="flex flex-col h-full">
      {filtersAndSearch}
      <div className="flex-1 overflow-y-auto min-h-0">
        <MailList
          emails={emails}
          loading={loadingEmails}
          error={error}
          selectedId={selectedEmail?.id ?? null}
          onSelect={(id) => {
            const email = emails.find((e) => e.id === id);
            if (email) handleSelectEmail(email);
          }}
          onRetry={refreshEmails}
        />
      </div>
    </div>
  );

  const readerPanel = (
    <EmailReader
      email={selectedEmail}
      loading={emailLoading}
      error={emailError}
      onBack={() => {
        setSelectedEmail(null);
        setEmailError(null);
      }}
      onSpam={handleMarkSpam}
      onDelete={handleDelete}
    />
  );

  const aiPanel = selectedEmail && (
    <AIReplyPanel
      analysisResult={analysisResult}
      loading={loadingAnalysis}
      generating={generating}
      selectedTone={selectedTone}
      replyText={replyText}
      replySource={replySource}
      replyModel={replyModel}
      replyFallbackReason={replyFallbackReason}
      replyToneApplied={replyToneApplied}
      onAnalyze={handleAnalyze}
      onToneChange={(tone) => {
        setSelectedTone(tone);
        handleGenerateReply(tone);
      }}
      onRegenerate={handleRegenerate}
      onCopy={handleCopy}
      onSaveDraft={handleSaveDraft}
      onSend={() => setShowSendConfirm(true)}
    />
  );

  return (
    <div className="h-[calc(100vh-4rem)] flex bg-[#F7F9FC]">
      {/* Mobile (< lg): single panel */}
      <div className="lg:hidden w-full flex flex-col">
        {showMobilePanel === 'list' ? (
          mailListPanel
        ) : selectedEmail ? (
          <>
            {mobileTopBar}
            <div className="flex-1 overflow-hidden">
              {readerTab === 'reader' ? readerPanel : aiPanel}
            </div>
          </>
        ) : (
          mailListPanel
        )}
      </div>

      {/* Desktop (lg+): 3 columns */}
      <div className="hidden lg:flex w-full min-h-0">
        <div className="w-[400px] shrink-0 border-r border-[#EAF0FF] bg-white flex flex-col overflow-hidden min-h-0">
          {mailListPanel}
        </div>
        <div className="flex-1 min-w-0 border-r border-[#EAF0FF] bg-white overflow-hidden min-h-0">
          {readerPanel}
        </div>
        <div className="w-[400px] shrink-0 bg-white overflow-hidden min-h-0">
          {aiPanel}
        </div>
      </div>

      {/* Send Confirmation Modal */}
      <ConfirmationModal
        open={showSendConfirm}
        onClose={() => setShowSendConfirm(false)}
        onConfirm={handleSend}
        title="Send Email"
        message="Are you sure you want to send this AI-generated reply?"
        confirmLabel="Send"
        loading={sending}
      />
    </div>
  );
}
