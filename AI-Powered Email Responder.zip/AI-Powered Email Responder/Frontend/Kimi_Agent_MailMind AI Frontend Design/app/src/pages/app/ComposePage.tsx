import { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Save, Sparkles, Loader2, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router';
import { toast } from 'sonner';
import { analyzeEmailApi } from '@/services/emailService';
import { draftService } from '@/services/draftService';
import { gmailService } from '@/services/gmailService';
import { TONE_OPTIONS } from '@/lib/constants';
import ConfirmationModal from '@/components/common/ConfirmationModal';

export default function ComposePage() {
  const [recipient, setRecipient] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [tone, setTone] = useState('Professional');
  const [generatedBody, setGeneratedBody] = useState('');
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showSendConfirm, setShowSendConfirm] = useState(false);
  const [sending, setSending] = useState(false);

  const handleGenerate = async () => {
    if (!recipient || !subject || !body) {
      toast.error('Please fill in recipient, subject, and body first');
      return;
    }
    setGenerating(true);
    try {
      const result = await analyzeEmailApi({
        sender: recipient,
        subject,
        email_body: body,
        tone: tone as 'Professional' | 'Friendly' | 'Apologetic' | 'Short',
      });
      setGeneratedBody(result.reply);
      toast.success('AI reply generated');
    } catch {
      toast.error('Failed to generate AI reply');
    } finally {
      setGenerating(false);
    }
  };

  const handleSaveDraft = async () => {
    if (!recipient || !subject) {
      toast.error('Recipient and subject are required');
      return;
    }
    setSaving(true);
    try {
      await draftService.createDraft({
        recipient,
        subject,
        body: generatedBody || body,
        tone,
      });
      toast.success('Draft saved');
      setRecipient('');
      setSubject('');
      setBody('');
      setGeneratedBody('');
    } catch {
      toast.error('Failed to save draft');
    } finally {
      setSaving(false);
    }
  };

  const handleSendConfirm = async () => {
    setSending(true);
    try {
      const draft = await draftService.createDraft({
        recipient,
        subject,
        body: generatedBody || body,
        tone,
      });
      await gmailService.sendEmail(draft.id);
      toast.success('Email sent successfully');
      setShowSendConfirm(false);
      setRecipient('');
      setSubject('');
      setBody('');
      setGeneratedBody('');
    } catch {
      toast.error('Failed to send email');
    } finally {
      setSending(false);
    }
  };

  const clearForm = () => {
    setGeneratedBody('');
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6">
        <Link to="/dashboard" className="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-[#0B1739] transition mb-2">
          <ArrowLeft size={14} /> Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold text-[#0B1739]">Compose Email</h1>
        <p className="text-sm text-gray-500 mt-1">Create a new email with AI assistance</p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5"
      >
        <div>
          <label className="block text-sm font-medium text-[#0B1739] mb-1.5">Recipient</label>
          <input
            type="email"
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
            placeholder="email@example.com"
            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] focus:border-transparent bg-white transition"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-[#0B1739] mb-1.5">Subject</label>
          <input
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Email subject"
            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] focus:border-transparent bg-white transition"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-[#0B1739] mb-1.5">Body</label>
          <textarea
            rows={8}
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Write your email content here..."
            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] focus:border-transparent bg-white resize-none transition"
          />
        </div>

        {generatedBody && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="bg-[#EAF0FF] rounded-xl p-4 border border-blue-100"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-[#2357D9] uppercase tracking-wide">AI Generated Reply</span>
              <button onClick={clearForm} className="text-xs text-gray-400 hover:text-gray-600 transition">Clear</button>
            </div>
            <p className="text-sm text-gray-800 whitespace-pre-wrap leading-relaxed">{generatedBody}</p>
          </motion.div>
        )}

        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-[#0B1739]">Tone:</span>
          <select
            value={tone}
            onChange={(e) => setTone(e.target.value)}
            className="px-4 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] bg-white transition"
          >
            {TONE_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-3 pt-2 border-t border-gray-100">
          <button
            onClick={handleGenerate}
            disabled={generating}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium bg-[#EAF0FF] text-[#2357D9] hover:bg-[#d4e2ff] transition disabled:opacity-50"
          >
            {generating ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />}
            {generating ? 'Generating...' : 'Generate AI Reply'}
          </button>
          <button
            onClick={handleSaveDraft}
            disabled={saving}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium bg-gray-100 text-gray-700 hover:bg-gray-200 transition disabled:opacity-50"
          >
            <Save size={15} /> {saving ? 'Saving...' : 'Save Draft'}
          </button>
          <button
            onClick={() => setShowSendConfirm(true)}
            disabled={!recipient || !subject}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium bg-[#2357D9] text-white hover:bg-[#1a45b8] transition disabled:opacity-40 ml-auto"
          >
            <Send size={15} /> Send
          </button>
        </div>
      </motion.div>

      <ConfirmationModal
        open={showSendConfirm}
        onClose={() => !sending && setShowSendConfirm(false)}
        onConfirm={handleSendConfirm}
        title="Send Email"
        message="This email will be saved as a draft and sent via Gmail. Continue?"
        confirmLabel={sending ? 'Sending...' : 'Send'}
        variant="success"
        loading={sending}
      />
    </div>
  );
}
