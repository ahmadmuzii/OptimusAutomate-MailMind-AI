import { useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Mail, Zap, CheckCircle2, XCircle, RefreshCw, Link2, Link2Off, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { gmailService } from '@/services/gmailService';
import api from '@/services/api';
import { ENDPOINTS } from '@/services/endpoints';
import type { GmailStatus, HealthResponse } from '@/types';

export default function IntegrationsPage() {
  const [gmailStatus, setGmailStatus] = useState<GmailStatus | null>(null);
  const [aiStatus, setAiStatus] = useState<HealthResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [disconnecting, setDisconnecting] = useState(false);

  const loadStatus = useCallback(async () => {
    setLoading(true);
    try {
      const [gmail, healthRes] = await Promise.all([
        gmailService.getStatus().catch(() => null),
        api.get<HealthResponse>(ENDPOINTS.aiHealth).catch(() => null),
      ]);
      setGmailStatus(gmail);
      if (healthRes?.data) {
        setAiStatus({
          ...healthRes.data,
          groq_api_configured: healthRes.data.groq_api_configured ?? healthRes.data.configured ?? false,
        });
      }
    } catch {
      toast.error('Failed to load integration status');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStatus();
  }, [loadStatus]);

  const handleConnect = useCallback(async () => {
    try {
      const url = await gmailService.getConnectUrl();
      window.open(url, '_blank', 'width=600,height=700');
    } catch {
      toast.error('Failed to get connection URL');
    }
  }, []);

  const getApiErrorCode = (error: any): string | null => {
    return error?.response?.data?.error?.code || null;
  };

  const getApiErrorMessage = (error: any): string | null => {
    return (
      error?.response?.data?.error?.message ||
      error?.response?.data?.detail ||
      error?.message ||
      null
    );
  };

  const handleSync = useCallback(async () => {
    setSyncing(true);
    try {
      const result = await gmailService.sync();
      toast.success(`Synced ${result.synced} emails`);
      loadStatus();
    } catch (err: any) {
      const code = getApiErrorCode(err);
      const message = getApiErrorMessage(err);

      if (code === 'GMAIL_REAUTH_REQUIRED') {
        toast.error(message || 'Reconnect Gmail to continue syncing.');
        loadStatus();
        return;
      }

      toast.error(message || 'Gmail sync failed.');
    } finally {
      setSyncing(false);
    }
  }, [loadStatus]);

  const handleDisconnect = async () => {
    setDisconnecting(true);
    try {
      await gmailService.disconnect();
      setGmailStatus(null);
      toast.success('Gmail disconnected');
      loadStatus();
    } catch {
      toast.error('Failed to disconnect');
    } finally {
      setDisconnecting(false);
    }
  };

  const formatTime = (d: string | null) => {
    if (!d) return 'Never';
    return new Date(d).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const container = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.08 } },
  };

  const itemAnim = {
    hidden: { opacity: 0, y: 16 },
    show: { opacity: 1, y: 0 },
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto space-y-6">
        {Array.from({ length: 2 }).map((_, i) => (
          <div key={i} className="bg-white rounded-2xl border border-gray-100 p-6 animate-pulse space-y-4">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-gray-100" />
              <div className="space-y-2">
                <div className="h-4 w-24 bg-gray-100 rounded" />
                <div className="h-3 w-32 bg-gray-50 rounded" />
              </div>
            </div>
            <div className="h-3 w-2/3 bg-gray-50 rounded" />
            <div className="h-3 w-1/2 bg-gray-50 rounded" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[#0B1739]">Integrations</h1>
        <p className="text-sm text-gray-500 mt-1">Connect your accounts and services</p>
      </div>

      <motion.div variants={itemAnim} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <div className="flex items-start gap-4">
          <div className={`h-14 w-14 rounded-2xl flex items-center justify-center shrink-0 ${
            gmailStatus?.status === 'connected' ? 'bg-emerald-50' :
            gmailStatus?.status === 'reauth_required' ? 'bg-amber-50' :
            'bg-red-50'
          }`}>
            <Mail size={28} className={
              gmailStatus?.status === 'connected' ? 'text-emerald-600' :
              gmailStatus?.status === 'reauth_required' ? 'text-amber-500' :
              'text-red-400'
            } />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-1">
              <h2 className="text-lg font-bold text-[#0B1739]">Gmail</h2>
              <span className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full border ${
                gmailStatus?.status === 'connected' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                gmailStatus?.status === 'reauth_required' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                'bg-red-50 text-red-600 border-red-200'
              }`}>
                {gmailStatus?.status === 'connected' ? <CheckCircle2 size={12} /> :
                 gmailStatus?.status === 'reauth_required' ? <AlertTriangle size={12} /> :
                 <XCircle size={12} />}
                {gmailStatus?.status === 'connected' ? 'Connected' :
                 gmailStatus?.status === 'reauth_required' ? 'Reconnect Required' :
                 'Disconnected'}
              </span>
            </div>

            {gmailStatus?.status === 'connected' ? (
              <div className="space-y-2 mt-3 text-sm">
                <p className="text-gray-600">
                  <span className="font-medium text-[#0B1739]">Email:</span> {gmailStatus.gmail_email || 'N/A'}
                </p>
                <p className="text-gray-600">
                  <span className="font-medium text-[#0B1739]">Last Sync:</span> {formatTime(gmailStatus.last_sync_at)}
                </p>
                <p className="text-gray-600">
                  <span className="font-medium text-[#0B1739]">Imported:</span> {gmailStatus.imported_count || 0} emails
                </p>
              </div>
            ) : gmailStatus?.status === 'reauth_required' ? (
              <div className="space-y-2 mt-3 text-sm">
                <p className="text-amber-700 bg-amber-50 rounded-lg p-3 border border-amber-200">
                  {gmailStatus.last_error_message || 'Your Gmail authorization has expired or was revoked. Reconnect Gmail to continue syncing.'}
                </p>
                {gmailStatus.gmail_email && (
                  <p className="text-gray-600">
                    <span className="font-medium text-[#0B1739]">Email:</span> {gmailStatus.gmail_email}
                  </p>
                )}
                <p className="text-gray-600">
                  <span className="font-medium text-[#0B1739]">Last Sync:</span> {formatTime(gmailStatus.last_sync_at)}
                </p>
              </div>
            ) : (
              <p className="text-sm text-gray-500 mt-2">Connect your Gmail account to import and analyze emails automatically.</p>
            )}

            <div className="flex items-center gap-2 mt-4">
              {gmailStatus?.status === 'connected' ? (
                <>
                  <button
                    onClick={handleSync}
                    disabled={syncing}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium bg-[#EAF0FF] text-[#2357D9] hover:bg-[#d4e2ff] transition disabled:opacity-50"
                  >
                    <RefreshCw size={14} className={syncing ? 'animate-spin' : ''} />
                    {syncing ? 'Syncing...' : 'Sync'}
                  </button>
                  <button
                    onClick={handleDisconnect}
                    disabled={disconnecting}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium bg-red-50 text-red-600 hover:bg-red-100 transition disabled:opacity-50"
                  >
                    <Link2Off size={14} /> {disconnecting ? 'Disconnecting...' : 'Disconnect'}
                  </button>
                </>
              ) : gmailStatus?.status === 'reauth_required' ? (
                <>
                  <button
                    onClick={handleConnect}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium bg-[#2357D9] text-white hover:bg-[#1a45b8] transition shadow-sm"
                  >
                    <Link2 size={14} /> Reconnect Gmail
                  </button>
                  <button
                    onClick={handleDisconnect}
                    disabled={disconnecting}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium bg-red-50 text-red-600 hover:bg-red-100 transition disabled:opacity-50"
                  >
                    <Link2Off size={14} /> {disconnecting ? 'Disconnecting...' : 'Disconnect'}
                  </button>
                </>
              ) : (
                <button
                  onClick={handleConnect}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium bg-[#2357D9] text-white hover:bg-[#1a45b8] transition shadow-sm"
                >
                  <Link2 size={14} /> Connect
                </button>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      <motion.div variants={itemAnim} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <div className="flex items-start gap-4">
          <div className={`h-14 w-14 rounded-2xl flex items-center justify-center shrink-0 ${aiStatus?.groq_api_configured ? 'bg-emerald-50' : 'bg-amber-50'}`}>
            <Zap size={28} className={aiStatus?.groq_api_configured ? 'text-emerald-600' : 'text-amber-500'} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-1">
              <h2 className="text-lg font-bold text-[#0B1739]">Groq AI</h2>
              <span className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full border ${aiStatus?.groq_api_configured ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-amber-50 text-amber-700 border-amber-200'}`}>
                {aiStatus?.groq_api_configured ? <CheckCircle2 size={12} /> : <XCircle size={12} />}
                {aiStatus?.groq_api_configured ? 'Configured' : 'Not Configured'}
              </span>
            </div>

            {aiStatus?.groq_api_configured ? (
              <div className="space-y-2 mt-3 text-sm">
                <p className="text-gray-600">
                  <span className="font-medium text-[#0B1739]">Status:</span> {aiStatus.status || 'Active'}
                </p>
                <p className="text-gray-600">
                  <span className="font-medium text-[#0B1739]">Version:</span> {aiStatus.version || 'N/A'}
                </p>
                <p className="text-xs text-gray-400 mt-2">API key is stored securely on the backend.</p>
              </div>
            ) : (
              <div className="mt-3">
                <p className="text-sm text-gray-500">Groq AI is not configured. Add your API key in the backend environment variables to enable AI-powered email analysis and reply generation.</p>
                <p className="text-xs text-gray-400 mt-2">API key is stored securely on the backend.</p>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
