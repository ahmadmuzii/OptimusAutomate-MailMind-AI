import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, Send, FileEdit, ChevronDown, ChevronUp, Sparkles, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useMailbox } from '@/context/MailboxContext';
import { generateReply } from '@/services/emailService';
import { draftService } from '@/services/draftService';
import { TONE_OPTIONS, URGENCY_COLORS } from '@/lib/constants';
import EmptyState from '@/components/common/EmptyState';
import { CardSkeleton } from '@/components/common/LoadingSkeleton';
import type { EmailItem } from '@/types';

export default function UrgentPage() {
  const { emails, loadingEmails, refreshEmails } = useMailbox();
  const [urgentEmails, setUrgentEmails] = useState<EmailItem[]>([]);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [replyingId, setReplyingId] = useState<number | null>(null);
  const [replyTone, setReplyTone] = useState('Professional');
  const [generatedReply, setGeneratedReply] = useState('');
  const [generating, setGenerating] = useState(false);
  const [savingDraft, setSavingDraft] = useState(false);

  useEffect(() => {
    refreshEmails();
  }, []);

  useEffect(() => {
    const urgent = emails.filter((e) => e.urgency === 'High' || e.urgency === 'high');
    setUrgentEmails(urgent);
  }, [emails]);

  const handleGenerateReply = async (email: EmailItem) => {
    setGenerating(true);
    setReplyingId(email.id);
    try {
      const result = await generateReply(email.id, replyTone);
      setGeneratedReply(result.reply);
      toast.success('AI reply generated');
    } catch {
      toast.error('Failed to generate reply');
    } finally {
      setGenerating(false);
    }
  };

  const handleSaveDraft = async (email: EmailItem) => {
    setSavingDraft(true);
    try {
      await draftService.createDraft({
        email_id: email.id,
        recipient: email.sender_email,
        subject: `Re: ${email.subject}`,
        body: generatedReply || email.body || '',
        tone: replyTone,
      });
      toast.success('Draft saved');
      setReplyingId(null);
      setExpandedId(null);
    } catch {
      toast.error('Failed to save draft');
    } finally {
      setSavingDraft(false);
    }
  };

  const formatTime = (d: string | null) => {
    if (!d) return '';
    return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  if (loadingEmails) return <div className="max-w-4xl mx-auto"><CardSkeleton count={4} /></div>;

  if (urgentEmails.length === 0) {
    return (
      <div className="max-w-4xl mx-auto">
        <EmptyState icon={AlertCircle} title="No urgent messages" message="You're all caught up! No high-priority emails." />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-[#0B1739]">Urgent</h1>
        <p className="text-sm text-gray-500 mt-1">{urgentEmails.length} high-priority message{urgentEmails.length !== 1 ? 's' : ''}</p>
      </div>

      <AnimatePresence mode="popLayout">
        {urgentEmails.map((email, idx) => (
          <motion.div
            key={email.id}
            layout
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97 }}
            transition={{ delay: idx * 0.04, duration: 0.25 }}
            className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
          >
            <div
              className="p-4 cursor-pointer hover:bg-[#F7F9FC] transition-colors"
              onClick={() => setExpandedId(expandedId === email.id ? null : email.id)}
            >
              <div className="flex items-start gap-3">
                <div className="h-9 w-9 rounded-xl bg-red-50 flex items-center justify-center shrink-0">
                  <AlertCircle size={18} className="text-red-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-[#0B1739]">{email.sender_name || email.sender_email}</p>
                    {email.urgency && (
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${URGENCY_COLORS[email.urgency.toLowerCase()] || ''}`}>
                        {email.urgency}
                      </span>
                    )}
                    {email.intent && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#EAF0FF] text-[#2357D9] font-medium">
                        {email.intent}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-800 font-medium mt-0.5">{email.subject}</p>
                  <p className="text-xs text-gray-400 truncate mt-1">{email.body_preview || email.body?.slice(0, 120)}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="text-[11px] text-gray-400">{formatTime(email.received_at || email.created_at)}</span>
                    {expandedId === email.id ? <ChevronUp size={14} className="text-gray-400" /> : <ChevronDown size={14} className="text-gray-400" />}
                  </div>
                </div>
              </div>
            </div>

            <AnimatePresence>
              {expandedId === email.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 border-t border-gray-50">
                    <div className="bg-[#F7F9FC] rounded-xl p-4 my-3">
                      <p className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">{email.body || email.body_preview || ''}</p>
                    </div>

                    {replyingId === email.id && (
                      <div className="space-y-3 mb-3">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-medium text-gray-500">Tone:</span>
                          <select
                            value={replyTone}
                            onChange={(e) => setReplyTone(e.target.value)}
                            className="px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] bg-white"
                          >
                            {TONE_OPTIONS.map((opt) => (
                              <option key={opt.value} value={opt.value}>{opt.label}</option>
                            ))}
                          </select>
                        </div>
                        {generatedReply && (
                          <div className="bg-[#EAF0FF] rounded-xl p-4 border border-blue-100">
                            <p className="text-sm text-gray-800 whitespace-pre-wrap leading-relaxed">{generatedReply}</p>
                          </div>
                        )}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleGenerateReply(email)}
                            disabled={generating}
                            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium bg-[#2357D9] text-white hover:bg-[#1a45b8] transition disabled:opacity-50"
                          >
                            {generating ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                            {generating ? 'Generating...' : 'Generate Reply'}
                          </button>
                          {generatedReply && (
                            <button
                              onClick={() => handleSaveDraft(email)}
                              disabled={savingDraft}
                              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium bg-gray-100 text-gray-700 hover:bg-gray-200 transition disabled:opacity-50"
                            >
                              <FileEdit size={14} /> {savingDraft ? 'Saving...' : 'Save as Draft'}
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {replyingId !== email.id && (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => { e.stopPropagation(); setReplyingId(email.id); setGeneratedReply(''); }}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-[#2357D9] text-white hover:bg-[#1a45b8] transition"
                        >
                          <Send size={13} /> Generate Reply
                        </button>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
