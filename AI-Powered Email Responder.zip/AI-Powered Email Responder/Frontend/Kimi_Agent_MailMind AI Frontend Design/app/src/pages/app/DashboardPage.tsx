import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { motion } from 'framer-motion';
import { Mail, AlertCircle, FileEdit, ShieldAlert, RefreshCw, PlusCircle, ExternalLink, Zap, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useMailbox } from '@/context/MailboxContext';
import { fetchEmails } from '@/services/emailService';
import { gmailService } from '@/services/gmailService';
import api from '@/services/api';
import { ENDPOINTS } from '@/services/endpoints';
import type { EmailItem, GmailStatus, HealthResponse } from '@/types';

const statCards = [
  { label: 'Inbox', valueKey: 'inbox' as const, icon: Mail, color: 'from-blue-500 to-blue-600', bgLight: 'bg-blue-50', path: '/inbox' },
  { label: 'Urgent', valueKey: 'urgent' as const, icon: AlertCircle, color: 'from-red-500 to-red-600', bgLight: 'bg-red-50', path: '/urgent' },
  { label: 'Drafts', valueKey: 'drafts' as const, icon: FileEdit, color: 'from-amber-500 to-amber-600', bgLight: 'bg-amber-50', path: '/drafts' },
  { label: 'Spam', valueKey: 'spam' as const, icon: ShieldAlert, color: 'from-gray-500 to-gray-600', bgLight: 'bg-gray-50', path: '/spam' },
];

export default function DashboardPage() {
  const { user } = useAuth();
  const { counts, refreshCounts } = useMailbox();
  const [recentEmails, setRecentEmails] = useState<EmailItem[]>([]);
  const [gmailStatus, setGmailStatus] = useState<GmailStatus | null>(null);
  const [aiStatus, setAiStatus] = useState<HealthResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    setLoading(true);
    try {
      const [emailData, gmailData, healthData] = await Promise.all([
        fetchEmails({ folder: 'inbox', limit: 5 }).catch(() => [] as EmailItem[]),
        gmailService.getStatus().catch(() => null),
        api.get<HealthResponse>(ENDPOINTS.aiHealth).then(r => r.data).catch(() => null),
      ]);
      setRecentEmails(emailData);
      setGmailStatus(gmailData);
      setAiStatus(healthData);
      await refreshCounts();
    } catch {
    } finally {
      setLoading(false);
    }
  };

  const handleSync = async () => {
    setSyncing(true);
    try {
      await gmailService.sync();
      await loadDashboard();
    } catch {
    } finally {
      setSyncing(false);
    }
  };

  const formatTime = (dateStr: string | null) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const container = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.06 } },
  };

  const itemAnim = {
    hidden: { opacity: 0, y: 16 },
    show: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' as const } },
  };

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="max-w-6xl mx-auto space-y-6">
      <motion.div variants={itemAnim} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#0B1739]">
            Welcome, {user?.full_name?.split(' ')[0] || 'User'}
          </h1>
          <p className="text-gray-500 text-sm mt-1">Here's your email overview</p>
        </div>
        <div className="flex items-center gap-2">
          {gmailStatus?.is_connected && (
            <button
              onClick={handleSync}
              disabled={syncing}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-medium text-[#0B1739] hover:bg-gray-50 transition disabled:opacity-50"
            >
              <RefreshCw size={16} className={syncing ? 'animate-spin' : ''} />
              {syncing ? 'Syncing...' : 'Sync Gmail'}
            </button>
          )}
          <Link
            to="/compose"
            className="flex items-center gap-2 px-4 py-2 bg-[#2357D9] text-white rounded-xl text-sm font-medium hover:bg-[#1a45b8] transition shadow-sm"
          >
            <PlusCircle size={16} />
            Compose
          </Link>
        </div>
      </motion.div>

      <motion.div variants={itemAnim} className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card) => (
          <Link key={card.label} to={card.path} className="group bg-white rounded-2xl border border-gray-100 p-5 hover:shadow-lg hover:border-gray-200 transition-all duration-200">
            <div className="flex items-center justify-between mb-4">
              <div className={`h-11 w-11 rounded-xl ${card.bgLight} flex items-center justify-center group-hover:scale-110 transition-transform duration-200`}>
                <card.icon size={22} className="text-[#2357D9]" />
              </div>
              <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">{card.label}</span>
            </div>
            <p className="text-3xl font-bold text-[#0B1739]">{counts[card.valueKey]}</p>
            <div className={`mt-3 h-1 w-full rounded-full bg-gradient-to-r ${card.color} opacity-30`} />
          </Link>
        ))}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div variants={itemAnim} className="bg-white rounded-2xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between p-5 border-b border-gray-100">
            <h2 className="font-semibold text-[#0B1739]">Recent Emails</h2>
            <Link to="/inbox" className="text-sm font-medium text-[#2357D9] hover:text-[#1a45b8] transition">View All</Link>
          </div>
          <div className="divide-y divide-gray-50">
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="p-4 animate-pulse space-y-2">
                  <div className="h-3 w-1/3 bg-gray-100 rounded" />
                  <div className="h-3 w-2/3 bg-gray-50 rounded" />
                </div>
              ))
            ) : recentEmails.length === 0 ? (
              <div className="py-12 text-center">
                <Mail size={32} className="mx-auto text-gray-200 mb-2" />
                <p className="text-gray-400 text-sm">No emails yet</p>
              </div>
            ) : (
              recentEmails.map((email) => (
                <Link key={email.id} to="/inbox" className="flex items-start gap-3 p-4 hover:bg-[#F7F9FC] transition-colors group">
                  <div className={`w-2 h-2 rounded-full mt-2 shrink-0 ${email.is_read ? 'bg-transparent' : 'bg-[#2357D9]'}`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-[#0B1739] truncate">
                        {email.sender_name || email.sender_email}
                      </p>
                      {email.intent && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#EAF0FF] text-[#2357D9] font-medium shrink-0">
                          {email.intent}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-700 truncate">{email.subject}</p>
                    <p className="text-xs text-gray-400 truncate mt-0.5">{email.body_preview || email.body?.slice(0, 90)}</p>
                  </div>
                  <span className="text-[11px] text-gray-400 shrink-0 mt-1">{formatTime(email.received_at || email.created_at)}</span>
                </Link>
              ))
            )}
          </div>
        </motion.div>

        <motion.div variants={itemAnim} className="space-y-4">
          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className={`h-10 w-10 rounded-xl flex items-center justify-center ${gmailStatus?.is_connected ? 'bg-emerald-50' : 'bg-red-50'}`}>
                <Mail size={20} className={gmailStatus?.is_connected ? 'text-emerald-600' : 'text-red-500'} />
              </div>
              <div>
                <h3 className="font-semibold text-[#0B1739] text-sm">Gmail Connection</h3>
                <span className={`inline-flex items-center gap-1 text-xs font-medium mt-0.5 ${gmailStatus?.is_connected ? 'text-emerald-600' : 'text-red-500'}`}>
                  {gmailStatus?.is_connected ? <CheckCircle2 size={12} /> : <XCircle size={12} />}
                  {gmailStatus?.is_connected ? 'Connected' : 'Disconnected'}
                </span>
              </div>
            </div>
            {gmailStatus?.is_connected && (
              <div className="space-y-2 text-sm text-gray-500">
                <div className="flex items-center gap-2">
                  <Clock size={14} className="text-gray-400" />
                  <span>Last sync: {gmailStatus.last_sync_at ? formatTime(gmailStatus.last_sync_at) : 'Never'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail size={14} className="text-gray-400" />
                  <span>{gmailStatus.imported_count || 0} emails imported</span>
                </div>
              </div>
            )}
            {!gmailStatus?.is_connected && (
              <Link to="/integrations" className="inline-flex items-center gap-1.5 mt-2 text-sm font-medium text-[#2357D9] hover:text-[#1a45b8] transition">
                <ExternalLink size={14} /> Configure
              </Link>
            )}
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className={`h-10 w-10 rounded-xl flex items-center justify-center ${aiStatus?.groq_api_configured ? 'bg-emerald-50' : 'bg-amber-50'}`}>
                <Zap size={20} className={aiStatus?.groq_api_configured ? 'text-emerald-600' : 'text-amber-500'} />
              </div>
              <div>
                <h3 className="font-semibold text-[#0B1739] text-sm">AI Configuration</h3>
                <span className={`inline-flex items-center gap-1 text-xs font-medium mt-0.5 ${aiStatus?.groq_api_configured ? 'text-emerald-600' : 'text-amber-500'}`}>
                  {aiStatus?.groq_api_configured ? <CheckCircle2 size={12} /> : <XCircle size={12} />}
                  {aiStatus?.groq_api_configured ? 'Groq Configured' : 'Not Configured'}
                </span>
              </div>
            </div>
            {aiStatus?.groq_api_configured && (
              <p className="text-sm text-gray-500">AI email analysis and reply generation is active</p>
            )}
            {!aiStatus?.groq_api_configured && (
              <Link to="/integrations" className="inline-flex items-center gap-1.5 mt-2 text-sm font-medium text-[#2357D9] hover:text-[#1a45b8] transition">
                <ExternalLink size={14} /> Configure
              </Link>
            )}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
