import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Save, Loader2, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';
import { settingsService } from '@/services/settingsService';
import { TONE_OPTIONS } from '@/lib/constants';
import type { SettingsData } from '@/types';

const LENGTH_OPTIONS = [
  { value: 'Short', label: 'Short (1-2 sentences)' },
  { value: 'Medium', label: 'Medium (3-5 sentences)' },
  { value: 'Long', label: 'Long (detailed)' },
];

export default function SettingsPage() {
  const [settings, setSettings] = useState<SettingsData>({
    default_tone: 'Professional',
    preferred_reply_length: 'Medium',
    auto_analyze: true,
    notifications_enabled: true,
  });
  const [autoGmailSync, setAutoGmailSync] = useState(true);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [passwordForm, setPasswordForm] = useState({ current_password: '', new_password: '', confirm_password: '' });
  const [showPasswords, setShowPasswords] = useState(false);
  const [changingPassword, setChangingPassword] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const res = await settingsService.getSettings();
      setSettings(res.data);
    } catch {
      toast.error('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = async () => {
    setSaving(true);
    try {
      const res = await settingsService.updateSettings({
        default_tone: settings.default_tone,
        preferred_reply_length: settings.preferred_reply_length,
        auto_analyze: settings.auto_analyze,
        notifications_enabled: settings.notifications_enabled,
      });
      setSettings(res.data);
      toast.success('Settings saved');
    } catch {
      toast.error('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async () => {
    if (passwordForm.new_password !== passwordForm.confirm_password) {
      toast.error('Passwords do not match');
      return;
    }
    if (passwordForm.new_password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    setChangingPassword(true);
    try {
      await settingsService.changePassword({
        current_password: passwordForm.current_password,
        new_password: passwordForm.new_password,
        confirm_password: passwordForm.confirm_password,
      });
      toast.success('Password changed successfully');
      setPasswordForm({ current_password: '', new_password: '', confirm_password: '' });
    } catch {
      toast.error('Failed to change password');
    } finally {
      setChangingPassword(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto space-y-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="bg-white rounded-2xl border border-gray-100 p-6 animate-pulse space-y-3">
            <div className="h-5 w-1/3 bg-gray-100 rounded" />
            <div className="h-4 w-2/3 bg-gray-50 rounded" />
            <div className="h-10 w-full bg-gray-50 rounded-xl" />
          </div>
        ))}
      </div>
    );
  }

  const container = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.06 } },
  };

  const item = {
    hidden: { opacity: 0, y: 12 },
    show: { opacity: 1, y: 0 },
  };

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[#0B1739]">Settings</h1>
        <p className="text-sm text-gray-500 mt-1">Manage your preferences and account</p>
      </div>

      <motion.div variants={item} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
        <h2 className="font-semibold text-[#0B1739]">Reply Preferences</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">Default Tone</label>
            <select
              value={settings.default_tone}
              onChange={(e) => setSettings({ ...settings, default_tone: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] bg-white transition"
            >
              {TONE_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">Preferred Reply Length</label>
            <select
              value={settings.preferred_reply_length}
              onChange={(e) => setSettings({ ...settings, preferred_reply_length: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] bg-white transition"
            >
              {LENGTH_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>
        </div>
      </motion.div>

      <motion.div variants={item} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
        <h2 className="font-semibold text-[#0B1739]">Gmail Sync</h2>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-700">Auto Gmail Sync</p>
            <p className="text-xs text-gray-400 mt-0.5">Automatically sync emails from Gmail</p>
          </div>
          <button
            onClick={() => setAutoGmailSync(!autoGmailSync)}
            className={`relative w-11 h-6 rounded-full transition-colors duration-200 ${autoGmailSync ? 'bg-[#2357D9]' : 'bg-gray-200'}`}
          >
            <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform duration-200 ${autoGmailSync ? 'translate-x-5' : 'translate-x-0'}`} />
          </button>
        </div>
      </motion.div>

      <motion.div variants={item} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
        <h2 className="font-semibold text-[#0B1739]">Notifications</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-700">Push Notifications</p>
              <p className="text-xs text-gray-400 mt-0.5">Receive alerts for urgent emails</p>
            </div>
            <button
              onClick={() => setSettings({ ...settings, notifications_enabled: !settings.notifications_enabled })}
              className={`relative w-11 h-6 rounded-full transition-colors duration-200 ${settings.notifications_enabled ? 'bg-[#2357D9]' : 'bg-gray-200'}`}
            >
              <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform duration-200 ${settings.notifications_enabled ? 'translate-x-5' : 'translate-x-0'}`} />
            </button>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-700">Auto Analyze</p>
              <p className="text-xs text-gray-400 mt-0.5">Automatically analyze incoming emails</p>
            </div>
            <button
              onClick={() => setSettings({ ...settings, auto_analyze: !settings.auto_analyze })}
              className={`relative w-11 h-6 rounded-full transition-colors duration-200 ${settings.auto_analyze ? 'bg-[#2357D9]' : 'bg-gray-200'}`}
            >
              <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform duration-200 ${settings.auto_analyze ? 'translate-x-5' : 'translate-x-0'}`} />
            </button>
          </div>
        </div>
      </motion.div>

      <motion.div variants={item} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
        <h2 className="font-semibold text-[#0B1739]">Appearance</h2>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-700">Theme</p>
            <p className="text-xs text-gray-400 mt-0.5">Coming soon</p>
          </div>
          <select
            disabled
            className="w-32 px-3 py-2 rounded-xl border border-gray-200 text-sm bg-gray-50 text-gray-400 cursor-not-allowed"
          >
            <option>Light</option>
          </select>
        </div>
      </motion.div>

      <motion.div variants={item} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
        <h2 className="font-semibold text-[#0B1739]">Account Security</h2>
        <div className="space-y-4">
          {(['current_password', 'new_password', 'confirm_password'] as const).map((field) => (
            <div key={field}>
              <label className="block text-sm font-medium text-gray-600 mb-1.5 capitalize">
                {field.replace(/_/g, ' ')}
              </label>
              <div className="relative">
                <input
                  type={showPasswords ? 'text' : 'password'}
                  value={passwordForm[field]}
                  onChange={(e) => setPasswordForm({ ...passwordForm, [field]: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#4F7CFF] bg-white transition pr-10"
                  placeholder={`Enter ${field.replace(/_/g, ' ')}`}
                />
                {field === 'new_password' && (
                  <button
                    type="button"
                    onClick={() => setShowPasswords(!showPasswords)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPasswords ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                )}
              </div>
            </div>
          ))}
          <button
            onClick={handleChangePassword}
            disabled={changingPassword || !passwordForm.current_password || !passwordForm.new_password || !passwordForm.confirm_password}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium bg-[#2357D9] text-white hover:bg-[#1a45b8] transition disabled:opacity-40"
          >
            {changingPassword ? <Loader2 size={15} className="animate-spin" /> : null}
            {changingPassword ? 'Changing...' : 'Change Password'}
          </button>
        </div>
      </motion.div>

      <motion.div variants={item} className="flex justify-end pb-8">
        <button
          onClick={handleSaveSettings}
          disabled={saving}
          className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-medium bg-[#2357D9] text-white hover:bg-[#1a45b8] transition disabled:opacity-50 shadow-sm"
        >
          {saving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
          {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </motion.div>
    </motion.div>
  );
}
