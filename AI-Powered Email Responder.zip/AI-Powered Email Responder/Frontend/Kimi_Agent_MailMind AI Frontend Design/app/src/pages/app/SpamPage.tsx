import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldAlert, Mail, Trash2, RefreshCw, AlertTriangle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { fetchEmails, markAsSpam, deleteEmail } from '@/services/emailService';
import EmptyState from '@/components/common/EmptyState';
import { CardSkeleton } from '@/components/common/LoadingSkeleton';
import type { EmailItem } from '@/types';

export default function SpamPage() {
  const [spamEmails, setSpamEmails] = useState<EmailItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [processingIds, setProcessingIds] = useState<Set<number>>(new Set());

  const loadSpam = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchEmails({ folder: 'spam' });
      setSpamEmails(data);
    } catch {
      setError('Failed to load spam emails');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadSpam(); }, []);

  const handleNotSpam = async (id: number) => {
    setProcessingIds((prev) => new Set(prev).add(id));
    try {
      await markAsSpam(id, false);
      setSpamEmails((prev) => prev.filter((e) => e.id !== id));
      toast.success('Moved to inbox');
    } catch {
      toast.error('Failed to move email');
    } finally {
      setProcessingIds((prev) => { const n = new Set(prev); n.delete(id); return n; });
    }
  };

  const handleDelete = async (id: number) => {
    setProcessingIds((prev) => new Set(prev).add(id));
    try {
      await deleteEmail(id);
      setSpamEmails((prev) => prev.filter((e) => e.id !== id));
      toast.success('Email deleted');
    } catch {
      toast.error('Failed to delete email');
    } finally {
      setProcessingIds((prev) => { const n = new Set(prev); n.delete(id); return n; });
    }
  };

  if (loading) return <div className="max-w-4xl mx-auto"><CardSkeleton count={4} /></div>;

  if (error) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl border border-red-100 p-8 text-center">
          <AlertTriangle size={36} className="mx-auto text-red-300 mb-3" />
          <p className="text-sm font-medium text-red-600 mb-1">Failed to load</p>
          <p className="text-xs text-gray-500 mb-4">{error}</p>
          <button
            onClick={loadSpam}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium bg-[#2357D9] text-white hover:bg-[#1a45b8] transition"
          >
            <RefreshCw size={14} /> Retry
          </button>
        </div>
      </div>
    );
  }

  if (spamEmails.length === 0) {
    return (
      <div className="max-w-4xl mx-auto">
        <EmptyState icon={ShieldAlert} title="No spam messages" message="Your spam folder is clean." />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-[#0B1739]">Spam</h1>
        <p className="text-sm text-gray-500 mt-1">{spamEmails.length} spam message{spamEmails.length !== 1 ? 's' : ''}</p>
      </div>

      <AnimatePresence mode="popLayout">
        {spamEmails.map((email, idx) => {
          const isProcessing = processingIds.has(email.id);
          return (
            <motion.div
              key={email.id}
              layout
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.15 } }}
              transition={{ delay: idx * 0.03, duration: 0.25 }}
              className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4"
            >
              <div className="flex items-start gap-3">
                <div className="h-9 w-9 rounded-xl bg-red-50 flex items-center justify-center shrink-0">
                  <ShieldAlert size={18} className="text-red-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-[#0B1739]">{email.sender_name || email.sender_email}</p>
                    {email.spam_reason && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-50 text-red-600 border border-red-200 font-medium truncate max-w-[160px]">
                        {email.spam_reason}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mt-0.5">{email.subject}</p>
                  <p className="text-xs text-gray-400 truncate mt-1">{email.body_preview || email.body?.slice(0, 100)}</p>
                  <div className="flex items-center gap-2 mt-3">
                    <button
                      onClick={() => handleNotSpam(email.id)}
                      disabled={isProcessing}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition disabled:opacity-50"
                    >
                      {isProcessing ? <Loader2 size={12} className="animate-spin" /> : <Mail size={12} />}
                      Not Spam
                    </button>
                    <button
                      onClick={() => handleDelete(email.id)}
                      disabled={isProcessing}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-red-50 text-red-600 hover:bg-red-100 transition disabled:opacity-50"
                    >
                      <Trash2 size={12} /> Delete
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
