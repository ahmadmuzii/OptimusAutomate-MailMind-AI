import { Sparkles } from 'lucide-react';
import AppLayout from '@/components/layout/AppLayout';
import ErrorBanner from '@/components/shared/ErrorBanner';
import EmailForm from '@/features/email-analysis/components/EmailForm';
import ResultPanel from '@/features/email-analysis/components/ResultPanel';
import { useEmailAnalysis } from '@/features/email-analysis/hooks/useEmailAnalysis';

export default function Home() {
  const { result, loading, error, analyze } = useEmailAnalysis();

  return (
    <AppLayout>
      <div className="max-w-7xl mx-auto">
        {error && <ErrorBanner message={error} />}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          <div className="xl:col-span-7">
            <div className="bg-white rounded-xl border border-[hsl(220,13%,88%)] shadow-sm p-6">
              <div className="mb-6">
                <div className="flex items-center gap-2">
                  <Sparkles size={20} className="text-[hsl(220,60%,28%)]" />
                  <h3 className="text-lg font-bold text-[hsl(222,47%,18%)]">Compose Email</h3>
                </div>
                <p className="text-sm text-[hsl(220,9%,46%)] mt-1">
                  Enter the email details and let AI generate the perfect reply
                </p>
              </div>
              <EmailForm onSubmit={analyze} loading={loading} />
            </div>
          </div>
          <div className="xl:col-span-5">
            <div className="sticky" style={{ top: '5.5rem' }}>
              <ResultPanel result={result} loading={loading} />
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
