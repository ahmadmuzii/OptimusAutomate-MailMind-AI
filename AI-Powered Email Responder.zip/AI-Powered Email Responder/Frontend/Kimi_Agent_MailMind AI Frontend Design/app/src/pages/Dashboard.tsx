import { useMailbox } from '@/context/MailboxContext';
import Sidebar from '@/components/layout/Sidebar';
import Header from '@/components/layout/Header';
import EmailList from '@/components/email/EmailList';
import EmailDetails from '@/components/email/EmailDetails';
import EmailForm from '@/features/email-analysis/components/EmailForm';
import AnalysisPanel from '@/features/email-analysis/components/AnalysisPanel';
import ErrorBanner from '@/components/shared/ErrorBanner';

export default function Dashboard() {
  const { selectedEmail, emailForm, analyzeEmail, loadingAnalysis, error } = useMailbox();

  const handleSubmit = async (data: typeof emailForm) => {
    try {
      await analyzeEmail(data);
    } catch {
      // error is handled by context
    }
  };

  return (
    <div className="h-screen flex bg-[hsl(220,25%,95%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <div className="flex-1 flex overflow-hidden">
          {/* Email List / Details */}
          <div className="w-[380px] flex-shrink-0 bg-white border-r border-[hsl(220,13%,88%)] overflow-y-auto">
            {selectedEmail ? <EmailDetails /> : <EmailList />}
          </div>

          {/* Main Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {error && <ErrorBanner message={error} />}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <div>
                <h2 className="text-lg font-bold text-[hsl(222,47%,18%)] mb-4">Compose Reply</h2>
                <EmailForm onSubmit={handleSubmit} loading={loadingAnalysis} />
              </div>
              <div>
                <AnalysisPanel />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
