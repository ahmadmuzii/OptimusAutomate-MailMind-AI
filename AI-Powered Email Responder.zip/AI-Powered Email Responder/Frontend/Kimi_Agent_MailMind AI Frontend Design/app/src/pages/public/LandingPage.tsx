import MarketingNavbar from '@/components/landing/MarketingNavbar';
import HeroSection from '@/components/landing/HeroSection';
import SocialProofSection from '@/components/landing/SocialProofSection';
import ProblemSection from '@/components/landing/ProblemSection';
import SolutionSection from '@/components/landing/SolutionSection';
import ProductDemo from '@/components/landing/ProductDemo';
import FeaturesSection from '@/components/landing/FeaturesSection';
import AiShowcase from '@/components/landing/AiShowcase';
import SecuritySection from '@/components/landing/SecuritySection';
import HowItWorksSection from '@/components/landing/HowItWorksSection';
import FaqSection from '@/components/landing/FaqSection';
import FinalCtaSection from '@/components/landing/FinalCtaSection';
import Footer from '@/components/landing/Footer';

export default function LandingPage() {
  return (
    <main>
      <MarketingNavbar />
      <HeroSection />
      <SocialProofSection />
      <ProblemSection />
      <SolutionSection />
      <ProductDemo />
      <FeaturesSection />
      <AiShowcase />
      <SecuritySection />
      <HowItWorksSection />
      <FaqSection />
      <FinalCtaSection />
      <Footer />
    </main>
  );
}
