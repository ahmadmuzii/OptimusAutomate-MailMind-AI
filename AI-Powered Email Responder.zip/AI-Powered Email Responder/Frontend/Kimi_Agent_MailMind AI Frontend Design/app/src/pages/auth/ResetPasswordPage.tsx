import { useState, useEffect } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router';
import { Lock, Eye, EyeOff, Loader2, CheckCircle2, XCircle, ArrowLeft } from 'lucide-react';
import { authService } from '@/services/authService';

export default function ResetPasswordPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token') || '';

  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (!token) {
      setError('Missing reset token. Please use the link from your email.');
    }
  }, [token]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      setError('Missing reset token');
      return;
    }
    if (newPassword.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    setError('');
    try {
      await authService.resetPassword({
        token,
        new_password: newPassword,
        confirm_password: confirmPassword,
      });
      setSuccess(true);
      setTimeout(() => navigate('/login'), 3000);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to reset password';
      if (msg.includes('expired') || msg.includes('Invalid')) {
        setError('This reset link has expired or is invalid. Please request a new one.');
      } else {
        setError(msg);
      }
    } finally {
      setLoading(false);
    }
  };

  if (!token && !error) return null;

  return (
    <div>
      {success ? (
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle2 size={24} className="text-green-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-[#0B1739] mb-2">Password Reset</h1>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <p className="text-green-700 text-sm">Password reset successfully! Redirecting to login...</p>
          </div>
          <Link
            to="/login"
            className="inline-flex items-center gap-1.5 text-sm text-[#2357D9] hover:text-[#1a45b0] font-medium"
          >
            <ArrowLeft size={14} />
            Back to Login
          </Link>
        </div>
      ) : error && !token ? (
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
              <XCircle size={24} className="text-red-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-[#0B1739] mb-2">Invalid Link</h1>
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <p className="text-red-700 text-sm">{error}</p>
          </div>
          <Link
            to="/forgot-password"
            className="inline-flex items-center gap-1.5 text-sm text-[#2357D9] hover:text-[#1a45b0] font-medium"
          >
            Request a new reset link
          </Link>
        </div>
      ) : (
        <>
          <h1 className="text-2xl font-bold text-[#0B1739] mb-1">Set New Password</h1>
          <p className="text-gray-500 text-sm mb-8">Enter your new password below.</p>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="new-password" className="block text-sm font-medium text-gray-700 mb-1.5">New Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                <input
                  id="new-password"
                  type={showPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Min. 8 characters"
                  className="w-full pl-10 pr-10 py-2.5 border border-gray-200 rounded-lg text-[#0B1739] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#2357D9] focus:border-[#2357D9] transition text-sm bg-white"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div>
              <label htmlFor="confirm-password" className="block text-sm font-medium text-gray-700 mb-1.5">Confirm Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                <input
                  id="confirm-password"
                  type={showConfirm ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter your password"
                  className="w-full pl-10 pr-10 py-2.5 border border-gray-200 rounded-lg text-[#0B1739] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#2357D9] focus:border-[#2357D9] transition text-sm bg-white"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">{error}</div>
            )}

            <button
              type="submit"
              disabled={loading || !token}
              className="w-full py-2.5 bg-[#2357D9] hover:bg-[#1a45b0] disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg transition text-sm flex items-center justify-center gap-2"
            >
              {loading ? <><Loader2 size={16} className="animate-spin" /> Resetting...</> : 'Reset password'}
            </button>
          </form>

          <p className="text-center mt-8">
            <Link to="/login" className="inline-flex items-center gap-1.5 text-sm text-[#2357D9] hover:text-[#1a45b0] font-medium">
              <ArrowLeft size={14} />
              Back to Login
            </Link>
          </p>
        </>
      )}
    </div>
  );
}
