import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Mail, Lock, User, Eye, EyeOff, Loader2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

export default function SignupPage() {
  const navigate = useNavigate();
  const { signup, error, clearError, loading } = useAuth();
  const [form, setForm] = useState({ full_name: '', email: '', password: '', confirm_password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!form.full_name.trim()) errs.full_name = 'Full name is required';
    if (!form.email.trim()) errs.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) errs.email = 'Invalid email format';
    if (!form.password) errs.password = 'Password is required';
    else if (form.password.length < 8) errs.password = 'Must be at least 8 characters';
    if (!form.confirm_password) errs.confirm_password = 'Please confirm your password';
    else if (form.password !== form.confirm_password) errs.confirm_password = 'Passwords do not match';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    if (!validate()) return;
    try {
      await signup(form.full_name, form.email, form.password);
      navigate('/dashboard');
    } catch {
      // error handled by context
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-[#0B1739] mb-1">Create Account</h1>
      <p className="text-gray-500 text-sm mb-8">Sign up for MailMind AI</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="full_name" className="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
          <div className="relative">
            <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              id="full_name"
              type="text"
              value={form.full_name}
              onChange={(e) => setForm({ ...form, full_name: e.target.value })}
              placeholder="John Doe"
              className={`w-full pl-10 pr-4 py-2.5 border rounded-lg text-[#0B1739] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#2357D9] focus:border-[#2357D9] transition text-sm bg-white ${errors.full_name ? 'border-red-300' : 'border-gray-200'}`}
            />
          </div>
          {errors.full_name && <p className="text-red-600 text-xs mt-1">{errors.full_name}</p>}
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1.5">Email</label>
          <div className="relative">
            <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              id="email"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="you@example.com"
              className={`w-full pl-10 pr-4 py-2.5 border rounded-lg text-[#0B1739] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#2357D9] focus:border-[#2357D9] transition text-sm bg-white ${errors.email ? 'border-red-300' : 'border-gray-200'}`}
            />
          </div>
          {errors.email && <p className="text-red-600 text-xs mt-1">{errors.email}</p>}
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
          <div className="relative">
            <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              id="password"
              type={showPassword ? 'text' : 'password'}
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              placeholder="At least 8 characters"
              className={`w-full pl-10 pr-10 py-2.5 border rounded-lg text-[#0B1739] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#2357D9] focus:border-[#2357D9] transition text-sm bg-white ${errors.password ? 'border-red-300' : 'border-gray-200'}`}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {errors.password && <p className="text-red-600 text-xs mt-1">{errors.password}</p>}
        </div>

        <div>
          <label htmlFor="confirm_password" className="block text-sm font-medium text-gray-700 mb-1.5">Confirm Password</label>
          <div className="relative">
            <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              id="confirm_password"
              type={showConfirm ? 'text' : 'password'}
              value={form.confirm_password}
              onChange={(e) => setForm({ ...form, confirm_password: e.target.value })}
              placeholder="Repeat your password"
              className={`w-full pl-10 pr-10 py-2.5 border rounded-lg text-[#0B1739] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#2357D9] focus:border-[#2357D9] transition text-sm bg-white ${errors.confirm_password ? 'border-red-300' : 'border-gray-200'}`}
            />
            <button
              type="button"
              onClick={() => setShowConfirm(!showConfirm)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {errors.confirm_password && <p className="text-red-600 text-xs mt-1">{errors.confirm_password}</p>}
        </div>

        <label className="flex items-start gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={acceptTerms}
            onChange={(e) => setAcceptTerms(e.target.checked)}
            className="mt-0.5 rounded border-gray-300 text-[#2357D9] focus:ring-[#2357D9] focus:ring-2 h-4 w-4"
          />
          <span className="text-sm text-gray-500">
            I accept the{' '}
            <span className="text-[#2357D9] hover:text-[#1a45b0] font-medium">Terms of Service</span>
            {' '}and{' '}
            <span className="text-[#2357D9] hover:text-[#1a45b0] font-medium">Privacy Policy</span>
          </span>
        </label>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">{error}</div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2.5 bg-[#2357D9] hover:bg-[#1a45b0] disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg transition text-sm flex items-center justify-center gap-2"
        >
          {loading ? <><Loader2 size={16} className="animate-spin" /> Creating account...</> : 'Create account'}
        </button>
      </form>

      <p className="text-center text-gray-500 text-sm mt-8">
        Already have an account?{' '}
        <Link to="/login" className="text-[#2357D9] hover:text-[#1a45b0] font-medium">Log in</Link>
      </p>
    </div>
  );
}
