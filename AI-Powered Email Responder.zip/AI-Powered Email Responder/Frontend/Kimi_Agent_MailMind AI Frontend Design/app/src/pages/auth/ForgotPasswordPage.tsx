import { useState } from 'react';
import { Link } from 'react-router';
import { Mail, Loader2, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { authService } from '@/services/authService';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setLoading(true);
    setError('');
    try {
      await authService.forgotPassword(email);
      setSent(true);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to send reset link');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {sent ? (
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle2 size={24} className="text-green-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-[#0B1739] mb-2">Check Your Email</h1>
          <p className="text-gray-500 text-sm mb-6">
            We&apos;ve sent a password reset link to <span className="font-medium text-[#0B1739]">{email}</span>
          </p>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <p className="text-green-700 text-sm">Check your email for the reset link</p>
          </div>
          <Link
            to="/login"
            className="inline-flex items-center gap-1.5 text-sm text-[#2357D9] hover:text-[#1a45b0] font-medium"
          >
            <ArrowLeft size={14} />
            Back to Login
          </Link>
        </div>
      ) : (
        <>
          <h1 className="text-2xl font-bold text-[#0B1739] mb-1">Reset Password</h1>
          <p className="text-gray-500 text-sm mb-8">Enter your email to receive a reset link</p>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1.5">Email</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg text-[#0B1739] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#2357D9] focus:border-[#2357D9] transition text-sm bg-white"
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">{error}</div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-[#2357D9] hover:bg-[#1a45b0] disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg transition text-sm flex items-center justify-center gap-2"
            >
              {loading ? <><Loader2 size={16} className="animate-spin" /> Sending...</> : 'Send reset link'}
            </button>
          </form>

          <p className="text-center mt-8">
            <Link to="/login" className="inline-flex items-center gap-1.5 text-sm text-[#2357D9] hover:text-[#1a45b0] font-medium">
              <ArrowLeft size={14} />
              Back to Login
            </Link>
          </p>
        </>
      )}
    </div>
  );
}
