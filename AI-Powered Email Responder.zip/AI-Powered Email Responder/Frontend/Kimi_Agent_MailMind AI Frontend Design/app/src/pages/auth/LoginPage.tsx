import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Mail, Lock, Eye, EyeOff, Loader2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, error, clearError, loading } = useAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [remember, setRemember] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    if (!form.email || !form.password) return;
    try {
      await login(form.email, form.password);
      navigate('/dashboard');
    } catch {
      // error handled by context
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-[#0B1739] mb-1">Welcome Back</h1>
      <p className="text-gray-500 text-sm mb-8">Sign in to your MailMind AI account</p>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1.5">Email</label>
          <div className="relative">
            <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              id="email"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="you@example.com"
              className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg text-[#0B1739] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#2357D9] focus:border-[#2357D9] transition text-sm bg-white"
            />
          </div>
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
          <div className="relative">
            <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              id="password"
              type={showPassword ? 'text' : 'password'}
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              placeholder="Enter your password"
              className="w-full pl-10 pr-10 py-2.5 border border-gray-200 rounded-lg text-[#0B1739] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#2357D9] focus:border-[#2357D9] transition text-sm bg-white"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="rounded border-gray-300 text-[#2357D9] focus:ring-[#2357D9] focus:ring-2 h-4 w-4"
            />
            <span className="text-sm text-gray-600">Remember me</span>
          </label>
          <Link to="/forgot-password" className="text-sm text-[#2357D9] hover:text-[#1a45b0] font-medium">
            Forgot password?
          </Link>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">{error}</div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2.5 bg-[#2357D9] hover:bg-[#1a45b0] disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg transition text-sm flex items-center justify-center gap-2"
        >
          {loading ? <><Loader2 size={16} className="animate-spin" /> Signing in...</> : 'Log in'}
        </button>
      </form>

      <p className="text-center text-gray-500 text-sm mt-8">
        Don&apos;t have an account?{' '}
        <Link to="/signup" className="text-[#2357D9] hover:text-[#1a45b0] font-medium">Sign up</Link>
      </p>
    </div>
  );
}
