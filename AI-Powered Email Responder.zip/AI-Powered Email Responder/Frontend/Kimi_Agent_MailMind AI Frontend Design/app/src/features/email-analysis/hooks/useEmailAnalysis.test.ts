import { describe, it, expect, vi, beforeEach } from "vitest"
import { renderHook, act } from "@testing-library/react"
import { useEmailAnalysis } from "./useEmailAnalysis"
import * as api from "@/features/email-analysis/api"
import { toast } from "sonner"
import type { AnalysisResult } from "@/types"

vi.mock("@/features/email-analysis/api", () => ({
  analyzeEmail: vi.fn(),
}))

vi.mock("sonner", () => ({
  toast: {
    success: vi.fn(),
    error: vi.fn(),
  },
}))

const mockResult: AnalysisResult = {
  email_id: 1,
  intent: "Complaint",
  urgency: "High",
  summary: "Customer wants a refund",
  suggested_subject: "Response Regarding Your Refund",
  reply: "Dear Customer, we apologize...",
}

beforeEach(() => {
  vi.clearAllMocks()
})

describe("useEmailAnalysis", () => {
  it("should start with default state", () => {
    const { result } = renderHook(() => useEmailAnalysis())
    expect(result.current.result).toBeNull()
    expect(result.current.loading).toBe(false)
    expect(result.current.error).toBeNull()
  })

  it("should set loading and result on successful analyze", async () => {
    vi.mocked(api.analyzeEmail).mockResolvedValue(mockResult)

    const { result } = renderHook(() => useEmailAnalysis())

    await act(async () => {
      await result.current.analyze({
        sender: "a@b.com",
        subject: "Refund",
        email_body: "I want a refund",
        tone: "Professional",
      })
    })

    expect(result.current.loading).toBe(false)
    expect(result.current.result).toEqual(mockResult)
    expect(result.current.error).toBeNull()
    expect(toast.success).toHaveBeenCalledWith("AI reply generated successfully!", expect.any(Object))
  })

  it("should set error on failure", async () => {
    const errMsg = "Network error"
    vi.mocked(api.analyzeEmail).mockRejectedValue(new Error(errMsg))

    const { result } = renderHook(() => useEmailAnalysis())

    await act(async () => {
      await result.current.analyze({
        sender: "a@b.com",
        subject: "Refund",
        email_body: "I want a refund",
        tone: "Professional",
      })
    })

    expect(result.current.loading).toBe(false)
    expect(result.current.result).toBeNull()
    expect(result.current.error).toBe(errMsg)
    expect(toast.error).toHaveBeenCalledWith("Failed to generate reply", expect.objectContaining({ description: errMsg }))
  })

  it("should use default error message for non-Error throws", async () => {
    vi.mocked(api.analyzeEmail).mockRejectedValue("string error")

    const { result } = renderHook(() => useEmailAnalysis())

    await act(async () => {
      await result.current.analyze({
        sender: "a@b.com",
        subject: "Refund",
        email_body: "I want a refund",
        tone: "Professional",
      })
    })

    expect(result.current.error).toBe(
      "Failed to connect to the AI service. Please make sure the backend server is running on localhost:8000"
    )
  })

  it("should reset state", async () => {
    vi.mocked(api.analyzeEmail).mockResolvedValue(mockResult)

    const { result } = renderHook(() => useEmailAnalysis())

    await act(async () => {
      await result.current.analyze({
        sender: "a@b.com",
        subject: "Refund",
        email_body: "I want a refund",
        tone: "Professional",
      })
    })
    expect(result.current.result).not.toBeNull()

    act(() => {
      result.current.reset()
    })
    expect(result.current.result).toBeNull()
    expect(result.current.error).toBeNull()
  })
})
