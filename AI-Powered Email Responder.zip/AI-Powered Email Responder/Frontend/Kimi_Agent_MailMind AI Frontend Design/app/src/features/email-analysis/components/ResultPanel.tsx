import { Target, Zap, FileText, Mail, MessageSquare, Copy, Check, Sparkles, TrendingUp, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { URGENCY_COLORS } from '@/lib/constants';
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';
import type { AnalysisResult } from '@/types';

interface ResultPanelProps {
  result: AnalysisResult | null;
  loading: boolean;
}

function getUrgencyColor(urgency: string) {
  const u = urgency.toLowerCase();
  if (u.includes('high')) return URGENCY_COLORS.high;
  if (u.includes('medium')) return URGENCY_COLORS.medium;
  return URGENCY_COLORS.low;
}

function getUrgencyIcon(urgency: string) {
  const u = urgency.toLowerCase();
  if (u.includes('high')) return <AlertCircle size={14} className="text-red-500" />;
  if (u.includes('medium')) return <TrendingUp size={14} className="text-amber-500" />;
  return <Zap size={14} className="text-emerald-500" />;
}

function LoadingState() {
  return (
    <div className="bg-white rounded-xl border border-[hsl(220,13%,88%)] shadow-sm p-6 space-y-6">
      <div className="flex items-center gap-2 text-[hsl(220,60%,28%)]">
        <Sparkles size={20} className="animate-pulse" />
        <h3 className="text-lg font-bold">AI Analysis</h3>
      </div>
      <div className="space-y-4">
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="space-y-2">
            <div className="h-4 w-24 bg-[hsl(220,14%,93%)] rounded animate-pulse" />
            <div className="h-16 w-full bg-[hsl(220,14%,93%)] rounded-lg animate-pulse" />
          </div>
        ))}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="bg-white rounded-xl border border-[hsl(220,13%,88%)] shadow-sm p-6">
      <div className="flex items-center gap-2 text-[hsl(220,60%,28%)] mb-4">
        <Sparkles size={20} />
        <h3 className="text-lg font-bold">AI Analysis</h3>
      </div>
      <div className="text-center py-12 text-[hsl(220,9%,46%)]">
        <div className="w-16 h-16 rounded-full bg-[hsl(220,14%,93%)] flex items-center justify-center mx-auto mb-4">
          <Sparkles size={28} className="text-[hsl(220,9%,46%)]" />
        </div>
        <p className="text-sm font-medium">Enter an email and click Generate Reply</p>
        <p className="text-xs mt-1 opacity-70">AI will analyze intent, urgency, and generate a response</p>
      </div>
    </div>
  );
}

export default function ResultPanel({ result, loading }: ResultPanelProps) {
  const { copied, copy } = useCopyToClipboard();

  if (loading) return <LoadingState />;
  if (!result) return <EmptyState />;

  const sections = [
    { icon: <Target size={16} className="text-[hsl(210,100%,50%)]" />, label: 'Intent Category', value: result.intent, badge: true },
    { icon: <Zap size={16} className="text-[hsl(210,100%,50%)]" />, label: 'Urgency Level', value: result.urgency, badge: true, customBadge: true },
    { icon: <FileText size={16} className="text-[hsl(210,100%,50%)]" />, label: 'Summary', value: result.summary },
    { icon: <Mail size={16} className="text-[hsl(210,100%,50%)]" />, label: 'Suggested Subject', value: result.suggested_subject, highlight: true },
  ];

  return (
    <div className="bg-white rounded-xl border border-[hsl(220,13%,88%)] shadow-sm overflow-hidden">
      <div className="px-6 py-4 border-b border-[hsl(220,13%,88%)] flex items-center gap-2 bg-gradient-to-r from-[hsl(220,60%,28%)]/5 to-transparent">
        <Sparkles size={20} className="text-[hsl(220,60%,28%)]" />
        <h3 className="text-lg font-bold text-[hsl(222,47%,18%)]">AI Analysis</h3>
      </div>
      <div className="p-6 space-y-5">
        {sections.map((section, idx) => (
          <div key={idx} className="space-y-1.5">
            <div className="flex items-center gap-1.5">
              {section.icon}
              <span className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)]">{section.label}</span>
            </div>
            <div className={cn('rounded-lg p-3', section.highlight ? 'bg-[hsl(210,100%,50%)]/5 border border-[hsl(210,100%,50%)]/15' : 'bg-[hsl(220,20%,97%)]')}>
              {section.badge ? (
                section.customBadge ? (
                  <span className={cn('inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border', getUrgencyColor(section.value))}>
                    {getUrgencyIcon(section.value)}{section.value}
                  </span>
                ) : (
                  <Badge variant="secondary" className="bg-[hsl(220,60%,28%)]/10 text-[hsl(220,60%,28%)] hover:bg-[hsl(220,60%,28%)]/15 font-semibold">{section.value}</Badge>
                )
              ) : (
                <p className="text-sm text-[hsl(222,47%,18%)] leading-relaxed">{section.value}</p>
              )}
            </div>
          </div>
        ))}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <MessageSquare size={16} className="text-[hsl(210,100%,50%)]" />
              <span className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)]">Generated Reply</span>
            </div>
            <button onClick={() => copy(result.reply)}
              className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200',
                copied ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-[hsl(220,60%,28%)]/10 text-[hsl(220,60%,28%)] hover:bg-[hsl(220,60%,28%)]/20 border border-transparent')}>
              {copied ? <><Check size={14} />Copied</> : <><Copy size={14} />Copy Reply</>}
            </button>
          </div>
          <div className="bg-[hsl(220,20%,97%)] rounded-lg p-4 border border-[hsl(220,13%,88%)]">
            <p className="text-sm text-[hsl(222,47%,18%)] leading-relaxed whitespace-pre-wrap">{result.reply}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
