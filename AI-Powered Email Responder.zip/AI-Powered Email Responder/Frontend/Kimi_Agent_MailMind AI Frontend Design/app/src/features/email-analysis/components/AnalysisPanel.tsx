import { useState } from 'react';
import { Target, Zap, FileText, Mail, MessageSquare, Copy, Check, Sparkles, Save, RefreshCw } from 'lucide-react';
import { useMailbox } from '@/context/MailboxContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { URGENCY_COLORS } from '@/lib/constants';
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';
import LoadingSkeleton from '@/components/shared/LoadingSkeleton';

function getUrgencyColor(urgency: string) {
  const u = urgency.toLowerCase();
  if (u.includes('high')) return URGENCY_COLORS.high;
  if (u.includes('medium')) return URGENCY_COLORS.medium;
  return URGENCY_COLORS.low;
}

export default function AnalysisPanel() {
  const { analysisResult, loadingAnalysis, emailForm, saveDraft, analyzeEmail, clearAnalysis } = useMailbox();
  const { copied, copy } = useCopyToClipboard();
  const [savingDraft, setSavingDraft] = useState(false);

  const handleSaveDraft = async () => {
    if (!analysisResult?.reply) return;
    setSavingDraft(true);
    try {
      await saveDraft(
        emailForm.sender,
        analysisResult.suggested_subject || `Re: ${emailForm.subject}`,
        analysisResult.reply,
        emailForm.tone,
      );
    } finally {
      setSavingDraft(false);
    }
  };

  const handleRegenerate = async () => {
    await analyzeEmail(emailForm);
  };

  if (loadingAnalysis) {
    return (
      <div className="bg-white rounded-xl border border-[hsl(220,13%,88%)] shadow-sm p-6">
        <div className="flex items-center gap-2 text-[hsl(220,60%,28%)] mb-4">
          <Sparkles size={20} className="animate-pulse" />
          <h3 className="text-lg font-bold">AI Analysis</h3>
        </div>
        <LoadingSkeleton lines={4} />
      </div>
    );
  }

  if (!analysisResult) {
    return (
      <div className="bg-white rounded-xl border border-[hsl(220,13%,88%)] shadow-sm p-6">
        <div className="flex items-center gap-2 text-[hsl(220,60%,28%)] mb-4">
          <Sparkles size={20} />
          <h3 className="text-lg font-bold">AI Analysis</h3>
        </div>
        <div className="text-center py-12 text-[hsl(220,9%,46%)]">
          <div className="w-16 h-16 rounded-full bg-[hsl(220,14%,93%)] flex items-center justify-center mx-auto mb-4">
            <Sparkles size={28} className="text-[hsl(220,9%,46%)]" />
          </div>
          <p className="text-sm font-medium">Enter or select an email to generate AI analysis.</p>
          <p className="text-xs mt-1 opacity-70">AI will analyze intent, urgency, and generate a response</p>
        </div>
      </div>
    );
  }

  const sections = [
    { icon: <Target size={16} />, label: 'Intent Category', value: analysisResult.intent, badge: true },
    {
      icon: <Zap size={16} />,
      label: 'Urgency Level',
      value: analysisResult.urgency,
      badge: true,
      customBadge: true,
    },
    { icon: <FileText size={16} />, label: 'Summary', value: analysisResult.summary },
    { icon: <Mail size={16} />, label: 'Suggested Subject', value: analysisResult.suggested_subject, highlight: true },
  ];

  return (
    <div className="bg-white rounded-xl border border-[hsl(220,13%,88%)] shadow-sm overflow-hidden">
      <div className="px-6 py-4 border-b border-[hsl(220,13%,88%)] flex items-center justify-between bg-gradient-to-r from-[hsl(220,60%,28%)]/5 to-transparent">
        <div className="flex items-center gap-2">
          <Sparkles size={20} className="text-[hsl(220,60%,28%)]" />
          <h3 className="text-lg font-bold text-[hsl(222,47%,18%)]">AI Analysis</h3>
        </div>
        <button
          onClick={clearAnalysis}
          className="text-xs text-[hsl(220,9%,46%)] hover:text-[hsl(222,47%,18%)] transition-colors"
        >
          Clear
        </button>
      </div>
      <div className="p-6 space-y-5">
        {sections.map((section, idx) => (
          <div key={idx} className="space-y-1.5">
            <div className="flex items-center gap-1.5">
              <span className="text-[hsl(210,100%,50%)]">{section.icon}</span>
              <span className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)]">
                {section.label}
              </span>
            </div>
            <div
              className={cn(
                'rounded-lg p-3',
                section.highlight
                  ? 'bg-[hsl(210,100%,50%)]/5 border border-[hsl(210,100%,50%)]/15'
                  : 'bg-[hsl(220,20%,97%)]',
              )}
            >
              {section.badge ? (
                section.customBadge ? (
                  <span
                    className={cn(
                      'inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border',
                      getUrgencyColor(section.value),
                    )}
                  >
                    {section.value}
                  </span>
                ) : (
                  <Badge variant="secondary" className="bg-[hsl(220,60%,28%)]/10 text-[hsl(220,60%,28%)] font-semibold">
                    {section.value}
                  </Badge>
                )
              ) : (
                <p className="text-sm text-[hsl(222,47%,18%)] leading-relaxed">{section.value}</p>
              )}
            </div>
          </div>
        ))}

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <MessageSquare size={16} className="text-[hsl(210,100%,50%)]" />
              <span className="text-xs font-semibold uppercase tracking-wider text-[hsl(220,9%,46%)]">
                Generated Reply
              </span>
            </div>
          </div>
          <div className="bg-[hsl(220,20%,97%)] rounded-lg p-4 border border-[hsl(220,13%,88%)]">
            <p className="text-sm text-[hsl(222,47%,18%)] leading-relaxed whitespace-pre-wrap">
              {analysisResult.reply || 'No reply generated.'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 pt-2">
          <button
            onClick={() => copy(analysisResult.reply)}
            className={cn(
              'flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all duration-200',
              copied
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : 'bg-[hsl(220,60%,28%)]/10 text-[hsl(220,60%,28%)] hover:bg-[hsl(220,60%,28%)]/20 border border-transparent',
            )}
          >
            {copied ? <Check size={14} /> : <Copy size={14} />}
            {copied ? 'Copied' : 'Copy Reply'}
          </button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleSaveDraft}
            disabled={savingDraft || !analysisResult.reply}
            className="text-xs"
          >
            <Save size={14} className="mr-1" />
            {savingDraft ? 'Saving...' : 'Save Draft'}
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleRegenerate}
            disabled={loadingAnalysis}
            className="text-xs"
          >
            <RefreshCw size={14} className="mr-1" />
            Regenerate Reply
          </Button>
        </div>
      </div>
    </div>
  );
}
