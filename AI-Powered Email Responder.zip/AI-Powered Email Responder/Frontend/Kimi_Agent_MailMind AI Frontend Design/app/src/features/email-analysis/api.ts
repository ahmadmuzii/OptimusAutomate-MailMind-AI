import api from '@/services/api';
import { ENDPOINTS } from '@/services/endpoints';
import type { EmailFormData, AnalysisResult } from '@/types';

export async function analyzeEmail(data: EmailFormData): Promise<AnalysisResult> {
  const response = await api.post<AnalysisResult>(ENDPOINTS.analyzeEmail, data);
  return response.data;
}
