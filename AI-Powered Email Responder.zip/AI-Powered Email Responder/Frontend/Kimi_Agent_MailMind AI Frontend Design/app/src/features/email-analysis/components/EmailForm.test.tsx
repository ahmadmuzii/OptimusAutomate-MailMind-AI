import { describe, it, expect, vi, beforeEach } from "vitest"
import { render, screen, fireEvent } from "@testing-library/react"
import userEvent from "@testing-library/user-event"
import EmailForm from "./EmailForm"

vi.mock("@/components/ui/button", () => ({
  Button: ({ children, ...props }: React.ComponentPropsWithoutRef<"button"> & { variant?: string }) => (
    <button {...props}>{children}</button>
  ),
}))

vi.mock("@/components/ui/input", () => ({
  Input: ({ type: _type, ...props }: React.ComponentPropsWithoutRef<"input">) => <input {...props} />,
}))

vi.mock("@/components/ui/textarea", () => ({
  Textarea: (props: React.ComponentPropsWithoutRef<"textarea">) => <textarea {...props} />,
}))

vi.mock("@/components/ui/label", () => ({
  Label: ({ children, ...props }: React.ComponentPropsWithoutRef<"label">) => <label {...props}>{children}</label>,
}))

const onSubmit = vi.fn()

beforeEach(() => {
  vi.clearAllMocks()
})

describe("EmailForm", () => {
  it("should render all fields and buttons", () => {
    render(<EmailForm onSubmit={onSubmit} loading={false} />)

    expect(screen.getByLabelText(/sender email/i)).toBeInTheDocument()
    expect(screen.getByLabelText(/subject/i)).toBeInTheDocument()
    expect(screen.getByLabelText(/email body/i)).toBeInTheDocument()
    expect(screen.getByRole("button", { name: /generate reply/i })).toBeInTheDocument()
    expect(screen.getByRole("button", { name: /clear/i })).toBeInTheDocument()
  })

  it("should show validation errors when submitting empty form", async () => {
    render(<EmailForm onSubmit={onSubmit} loading={false} />)

    await userEvent.click(screen.getByRole("button", { name: /generate reply/i }))

    expect(screen.getByText(/sender email is required/i)).toBeInTheDocument()
    expect(screen.getByText(/subject is required/i)).toBeInTheDocument()
    expect(screen.getByText(/email body is required/i)).toBeInTheDocument()
    expect(onSubmit).not.toHaveBeenCalled()
  })

  it("should validate sender email format", async () => {
    render(<EmailForm onSubmit={onSubmit} loading={false} />)

    await userEvent.type(screen.getByLabelText(/subject/i), "Test subject")
    await userEvent.type(screen.getByLabelText(/email body/i), "Test body content")

    fireEvent.change(screen.getByLabelText(/sender email/i), { target: { value: "not-an-email" } })

    await userEvent.click(screen.getByRole("button", { name: /generate reply/i }))

    expect(screen.getByText(/please enter a valid email/i)).toBeInTheDocument()
    expect(onSubmit).not.toHaveBeenCalled()
  })

  it("should call onSubmit with valid form data", async () => {
    render(<EmailForm onSubmit={onSubmit} loading={false} />)

    await userEvent.type(screen.getByLabelText(/sender email/i), "user@example.com")
    await userEvent.type(screen.getByLabelText(/subject/i), "Test subject")
    await userEvent.type(screen.getByLabelText(/email body/i), "Test body content")

    await userEvent.click(screen.getByRole("button", { name: /generate reply/i }))

    expect(onSubmit).toHaveBeenCalledTimes(1)
    expect(onSubmit).toHaveBeenCalledWith({
      sender: "user@example.com",
      subject: "Test subject",
      email_body: "Test body content",
      tone: "Professional",
    })
  })

  it("should clear all fields when clear button is clicked", async () => {
    render(<EmailForm onSubmit={onSubmit} loading={false} />)

    await userEvent.type(screen.getByLabelText(/sender email/i), "user@example.com")
    await userEvent.type(screen.getByLabelText(/subject/i), "Test subject")
    await userEvent.type(screen.getByLabelText(/email body/i), "Test body content")

    await userEvent.click(screen.getByRole("button", { name: /clear/i }))

    expect(screen.getByLabelText(/sender email/i)).toHaveValue("")
    expect(screen.getByLabelText(/subject/i)).toHaveValue("")
    expect(screen.getByLabelText(/email body/i)).toHaveValue("")
  })

  it("should show loading state on submit button", () => {
    render(<EmailForm onSubmit={onSubmit} loading={true} />)

    expect(screen.getByRole("button", { name: /analyzing/i })).toBeDisabled()
    expect(screen.getByRole("button", { name: /analyzing/i })).toBeInTheDocument()
  })

  it("should select a tone option", async () => {
    render(<EmailForm onSubmit={onSubmit} loading={false} />)

    const apologeticBtn = screen.getByRole("button", { name: "Apologetic" })
    await userEvent.click(apologeticBtn)

    await userEvent.type(screen.getByLabelText(/sender email/i), "user@example.com")
    await userEvent.type(screen.getByLabelText(/subject/i), "Test")
    await userEvent.type(screen.getByLabelText(/email body/i), "Body")
    await userEvent.click(screen.getByRole("button", { name: /generate reply/i }))

    expect(onSubmit).toHaveBeenCalledWith(
      expect.objectContaining({ tone: "Apologetic" })
    )
  })

  it("should clear validation errors when field is edited", async () => {
    render(<EmailForm onSubmit={onSubmit} loading={false} />)

    await userEvent.click(screen.getByRole("button", { name: /generate reply/i }))
    expect(screen.getByText(/sender email is required/i)).toBeInTheDocument()

    await userEvent.type(screen.getByLabelText(/sender email/i), "a")
    expect(screen.queryByText(/sender email is required/i)).not.toBeInTheDocument()
  })
})
