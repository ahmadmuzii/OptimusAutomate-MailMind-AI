import { useState, useCallback } from 'react';
import { toast } from 'sonner';
import { analyzeEmail } from '@/features/email-analysis/api';
import type { EmailFormData, AnalysisResult } from '@/types';

export function useEmailAnalysis() {
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const analyze = useCallback(async (data: EmailFormData) => {
    setLoading(true);
    setError(null);
    try {
      const analysisResult = await analyzeEmail(data);
      setResult(analysisResult);
      toast.success('AI reply generated successfully!', {
        description: 'Your email analysis is complete.',
      });
    } catch (err) {
      const message = err instanceof Error
        ? err.message
        : 'Failed to connect to the AI service. Please make sure the backend server is running on localhost:8000';
      setError(message);
      toast.error('Failed to generate reply', { description: message });
    } finally {
      setLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
  }, []);

  return { result, loading, error, analyze, reset };
}
