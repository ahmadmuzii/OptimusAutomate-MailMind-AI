import type { EmailFormData, AnalysisResult } from '@/types';

export interface UseEmailAnalysisReturn {
  result: AnalysisResult | null;
  loading: boolean;
  error: string | null;
  analyze: (data: EmailFormData) => Promise<void>;
  reset: () => void;
}
