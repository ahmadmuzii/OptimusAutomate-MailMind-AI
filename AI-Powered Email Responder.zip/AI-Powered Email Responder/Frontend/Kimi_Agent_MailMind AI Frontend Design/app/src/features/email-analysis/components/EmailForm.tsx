import { useState } from 'react';
import { RotateCcw, Sparkles, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { TONE_OPTIONS, EMAIL_REGEX } from '@/lib/constants';
import type { EmailFormData } from '@/types';

interface EmailFormProps {
  onSubmit: (data: EmailFormData) => void;
  loading: boolean;
}

export default function EmailForm({ onSubmit, loading }: EmailFormProps) {
  const [formData, setFormData] = useState<EmailFormData>({
    sender: '',
    subject: '',
    email_body: '',
    tone: 'Professional',
  });
  const [errors, setErrors] = useState<Partial<Record<keyof EmailFormData, string>>>({});

  const validate = (): boolean => {
    const newErrors: Partial<Record<keyof EmailFormData, string>> = {};
    if (!formData.sender.trim()) {
      newErrors.sender = 'Sender email is required';
    } else if (!EMAIL_REGEX.test(formData.sender)) {
      newErrors.sender = 'Please enter a valid email address';
    }
    if (!formData.subject.trim()) newErrors.subject = 'Subject is required';
    if (!formData.email_body.trim()) newErrors.email_body = 'Email body is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) onSubmit(formData);
  };

  const handleClear = () => {
    setFormData({ sender: '', subject: '', email_body: '', tone: 'Professional' });
    setErrors({});
  };

  const updateField = (field: keyof EmailFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const inputClass = (hasError?: string) =>
    cn(
      'h-11 bg-white border-[hsl(220,13%,88%)] focus:border-[hsl(220,60%,28%)] focus:ring-[hsl(220,60%,28%)]/20 rounded-lg transition-all',
      hasError && 'border-red-400 focus:border-red-400 focus:ring-red-400/20',
    );

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="space-y-1.5">
        <Label htmlFor="sender" className="text-sm font-semibold text-[hsl(222,47%,18%)]">Sender Email</Label>
        <Input id="sender" type="email" placeholder="sender@example.com" value={formData.sender}
          onChange={(e) => updateField('sender', e.target.value)} className={inputClass(errors.sender)} />
        {errors.sender && <p className="text-xs text-red-500 mt-1">{errors.sender}</p>}
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="subject" className="text-sm font-semibold text-[hsl(222,47%,18%)]">Subject</Label>
        <Input id="subject" placeholder="Email subject line..." value={formData.subject}
          onChange={(e) => updateField('subject', e.target.value)} className={inputClass(errors.subject)} />
        {errors.subject && <p className="text-xs text-red-500 mt-1">{errors.subject}</p>}
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="email_body" className="text-sm font-semibold text-[hsl(222,47%,18%)]">Email Body</Label>
        <Textarea id="email_body" placeholder="Paste the email content here..." value={formData.email_body}
          onChange={(e) => updateField('email_body', e.target.value)} rows={8}
          className={cn('bg-white border-[hsl(220,13%,88%)] focus:border-[hsl(220,60%,28%)] focus:ring-[hsl(220,60%,28%)]/20 rounded-lg resize-none transition-all leading-relaxed',
            errors.email_body && 'border-red-400 focus:border-red-400 focus:ring-red-400/20')} />
        {errors.email_body && <p className="text-xs text-red-500 mt-1">{errors.email_body}</p>}
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm font-semibold text-[hsl(222,47%,18%)]">Reply Tone</Label>
        <div className="flex flex-wrap gap-2">
          {TONE_OPTIONS.map((tone) => (
            <button key={tone.value} type="button" onClick={() => updateField('tone', tone.value)}
              className={cn(
                'px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 border',
                formData.tone === tone.value
                  ? 'bg-[hsl(220,60%,28%)] text-white border-[hsl(220,60%,28%)] shadow-sm'
                  : 'bg-white text-[hsl(222,47%,18%)] border-[hsl(220,13%,88%)] hover:border-[hsl(220,60%,28%)]/40 hover:bg-[hsl(220,60%,28%)]/5',
              )}>
              {tone.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-wrap gap-3 pt-2">
        <Button type="submit" disabled={loading}
          className="h-11 px-6 bg-[hsl(220,60%,28%)] hover:bg-[hsl(220,60%,23%)] text-white rounded-lg font-semibold shadow-sm hover:shadow transition-all disabled:opacity-60">
          {loading ? (
            <><Loader2 size={18} className="mr-2 animate-spin" />Analyzing...</>
          ) : (
            <><Sparkles size={18} className="mr-2" />Generate Reply</>
          )}
        </Button>
        <Button type="button" variant="outline" onClick={handleClear} disabled={loading}
          className="h-11 px-6 border-[hsl(220,13%,88%)] text-[hsl(222,47%,18%)] hover:bg-[hsl(220,14%,93%)] rounded-lg font-medium transition-all">
          <RotateCcw size={18} className="mr-2" />Clear
        </Button>
      </div>
    </form>
  );
}
