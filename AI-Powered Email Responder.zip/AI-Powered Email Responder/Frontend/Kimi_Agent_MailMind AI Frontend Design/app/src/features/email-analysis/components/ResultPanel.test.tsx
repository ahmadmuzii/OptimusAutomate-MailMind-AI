import { describe, it, expect, vi } from "vitest"
import { render, screen } from "@testing-library/react"
import userEvent from "@testing-library/user-event"
import ResultPanel from "./ResultPanel"
import type { AnalysisResult } from "@/types"

vi.mock("@/components/ui/badge", () => ({
  Badge: ({ children, ...props }: React.ComponentPropsWithoutRef<"span"> & { variant?: string }) => (
    <span {...props}>{children}</span>
  ),
}))

const mockResult: AnalysisResult = {
  email_id: 1,
  intent: "Complaint",
  urgency: "High",
  summary: "Customer received damaged product and wants a refund",
  suggested_subject: "Response Regarding Your Refund Request",
  reply: "Dear Customer,\n\nWe sincerely apologize for the inconvenience.\n\nBest regards,\nSupport Team",
}

describe("ResultPanel", () => {
  it("should render EmptyState when no result and not loading", () => {
    render(<ResultPanel result={null} loading={false} />)

    expect(screen.getByText(/enter an email and click generate reply/i)).toBeInTheDocument()
  })

  it("should render LoadingState when loading", () => {
    const { container } = render(<ResultPanel result={null} loading={true} />)

    expect(screen.getByText(/ai analysis/i)).toBeInTheDocument()
    const skeletonDivs = container.querySelectorAll(".animate-pulse")
    expect(skeletonDivs.length).toBeGreaterThan(0)
  })

  it("should render result sections when result is provided", () => {
    render(<ResultPanel result={mockResult} loading={false} />)

    expect(screen.getByText("Complaint")).toBeInTheDocument()
    expect(screen.getByText("High")).toBeInTheDocument()
    expect(screen.getByText(/customer received damaged product/i)).toBeInTheDocument()
    expect(screen.getByText(/response regarding your refund request/i)).toBeInTheDocument()
    expect(screen.getByText(/dear customer/i)).toBeInTheDocument()
  })

  it("should display generated reply text", () => {
    render(<ResultPanel result={mockResult} loading={false} />)

    expect(screen.getByText(/dear customer/i)).toBeInTheDocument()
    expect(screen.getByText(/support team/i)).toBeInTheDocument()
  })

  it("should show copy button and copy reply on click", async () => {
    Object.assign(navigator, {
      clipboard: { writeText: vi.fn().mockResolvedValue(undefined) },
    })

    render(<ResultPanel result={mockResult} loading={false} />)

    const copyBtn = screen.getByRole("button", { name: /copy reply/i })
    expect(copyBtn).toBeInTheDocument()

    await userEvent.click(copyBtn)
    expect(navigator.clipboard.writeText).toHaveBeenCalledWith(mockResult.reply)
  })
})
