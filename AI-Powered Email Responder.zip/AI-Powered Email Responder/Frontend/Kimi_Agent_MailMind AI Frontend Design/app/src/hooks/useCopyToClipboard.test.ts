import { describe, it, expect, vi, beforeEach, afterEach } from "vitest"
import { useCopyToClipboard } from "./useCopyToClipboard"
import { renderHook, act } from "@testing-library/react"

beforeEach(() => {
  vi.useFakeTimers()
})

afterEach(() => {
  vi.useRealTimers()
  vi.restoreAllMocks()
})

describe("useCopyToClipboard", () => {
  it("should start with copied=false", () => {
    const { result } = renderHook(() => useCopyToClipboard())
    expect(result.current.copied).toBe(false)
  })

  it("should set copied=true after copy succeeds", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined)
    Object.assign(navigator, {
      clipboard: { writeText },
    })

    const { result } = renderHook(() => useCopyToClipboard())
    await act(async () => {
      await result.current.copy("hello world")
    })

    expect(writeText).toHaveBeenCalledWith("hello world")
    expect(result.current.copied).toBe(true)
  })

  it("should fallback to execCommand when clipboard API fails", async () => {
    Object.assign(navigator, {
      clipboard: { writeText: vi.fn().mockRejectedValue(new Error("denied")) },
    })

    document.execCommand = vi.fn().mockReturnValue(true)

    const { result } = renderHook(() => useCopyToClipboard())
    await act(async () => {
      await result.current.copy("fallback text")
    })

    expect(document.execCommand).toHaveBeenCalledWith("copy")
    expect(result.current.copied).toBe(true)
  })

  it("should reset copied after resetMs", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined)
    Object.assign(navigator, {
      clipboard: { writeText },
    })

    const { result } = renderHook(() => useCopyToClipboard(1000))
    await act(async () => {
      await result.current.copy("test")
    })
    expect(result.current.copied).toBe(true)

    act(() => {
      vi.advanceTimersByTime(1000)
    })
    expect(result.current.copied).toBe(false)
  })

  it("should use default resetMs of 2000", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined)
    Object.assign(navigator, {
      clipboard: { writeText },
    })

    const { result } = renderHook(() => useCopyToClipboard())
    await act(async () => {
      await result.current.copy("test")
    })
    expect(result.current.copied).toBe(true)

    act(() => {
      vi.advanceTimersByTime(1999)
    })
    expect(result.current.copied).toBe(true)

    act(() => {
      vi.advanceTimersByTime(1)
    })
    expect(result.current.copied).toBe(false)
  })
})
